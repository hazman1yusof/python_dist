-- MySQL dump 10.13  Distrib 5.7.24, for Win64 (x86_64)
--
-- Host: localhost    Database: debtor
-- ------------------------------------------------------
-- Server version	5.7.24

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `bdebt`
--

DROP TABLE IF EXISTS `bdebt`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `bdebt` (
  `compcode` varchar(2) DEFAULT NULL,
  `source` varchar(2) DEFAULT NULL,
  `trantype` varchar(2) DEFAULT NULL,
  `auditno` int(11) DEFAULT NULL,
  `lineno_` int(11) DEFAULT NULL,
  `docsource` varchar(2) DEFAULT NULL,
  `doctrantype` varchar(2) DEFAULT NULL,
  `docauditno` int(11) DEFAULT NULL,
  `refsource` varchar(2) DEFAULT NULL,
  `reftrantype` varchar(2) DEFAULT NULL,
  `refauditno` int(11) DEFAULT NULL,
  `refamount` decimal(8,2) DEFAULT NULL,
  `reflineno` int(11) DEFAULT NULL,
  `recptno` varchar(17) DEFAULT NULL,
  `mrn` int(11) DEFAULT NULL,
  `episno` int(11) DEFAULT NULL,
  `allocsts` varchar(1) DEFAULT NULL,
  `amount` decimal(9,2) DEFAULT NULL,
  `outamt` decimal(12,2) DEFAULT NULL,
  `tillcode` varchar(30) DEFAULT NULL,
  `debtortype` varchar(30) DEFAULT NULL,
  `debtorcode` varchar(17) DEFAULT NULL,
  `payercode` varchar(17) DEFAULT NULL,
  `paymode` varchar(30) NOT NULL,
  `allocdate` datetime DEFAULT NULL,
  `remark` varchar(40) DEFAULT NULL,
  `upddate` datetime DEFAULT NULL,
  `upduser` varchar(30) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `bdebt`
--

LOCK TABLES `bdebt` WRITE;
/*!40000 ALTER TABLE `bdebt` DISABLE KEYS */;
/*!40000 ALTER TABLE `bdebt` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `bdebtall`
--

DROP TABLE IF EXISTS `bdebtall`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `bdebtall` (
  `compcode` varchar(2) DEFAULT NULL,
  `source` varchar(2) DEFAULT NULL,
  `trantype` varchar(2) DEFAULT NULL,
  `auditno` int(11) DEFAULT NULL,
  `lineno_` int(11) DEFAULT NULL,
  `docsource` varchar(2) DEFAULT NULL,
  `doctrantype` varchar(2) DEFAULT NULL,
  `docauditno` int(11) DEFAULT NULL,
  `refsource` varchar(2) DEFAULT NULL,
  `reftrantype` varchar(2) DEFAULT NULL,
  `refauditno` int(11) DEFAULT NULL,
  `refamount` decimal(8,2) DEFAULT NULL,
  `reflineno` int(11) DEFAULT NULL,
  `recptno` varchar(17) DEFAULT NULL,
  `mrn` int(11) DEFAULT NULL,
  `episno` int(11) DEFAULT NULL,
  `allocsts` varchar(1) DEFAULT NULL,
  `amount` decimal(9,2) DEFAULT NULL,
  `tillcode` varchar(30) DEFAULT NULL,
  `debtortype` varchar(30) DEFAULT NULL,
  `debtorcode` varchar(17) DEFAULT NULL,
  `payercode` varchar(17) DEFAULT NULL,
  `paymode` varchar(30) NOT NULL,
  `allocdate` datetime DEFAULT NULL,
  `remark` varchar(40) DEFAULT NULL,
  `upddate` datetime DEFAULT NULL,
  `upduser` varchar(30) DEFAULT NULL,
  `debtsrc` varchar(30) DEFAULT NULL,
  `debttype` varchar(30) DEFAULT NULL,
  `debtauditno` int(11) DEFAULT NULL,
  `debtlineno` int(11) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `bdebtall`
--

LOCK TABLES `bdebtall` WRITE;
/*!40000 ALTER TABLE `bdebtall` DISABLE KEYS */;
/*!40000 ALTER TABLE `bdebtall` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `billsum`
--

DROP TABLE IF EXISTS `billsum`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `billsum` (
  `idno` int(11) DEFAULT NULL,
  `compcode` varchar(2) DEFAULT NULL,
  `source` varchar(2) DEFAULT NULL,
  `trantype` varchar(2) DEFAULT NULL,
  `auditno` int(11) DEFAULT NULL,
  `description` varchar(40) DEFAULT NULL,
  `quantity` decimal(7,2) DEFAULT NULL,
  `amount` decimal(9,2) DEFAULT NULL,
  `outamt` decimal(9,2) DEFAULT NULL,
  `taxamt` decimal(11,4) DEFAULT NULL,
  `mrn` int(11) DEFAULT '0',
  `episno` int(11) DEFAULT '0',
  `paymode` varchar(30) DEFAULT NULL,
  `cardno` varchar(20) DEFAULT NULL,
  `debtortype` varchar(30) DEFAULT NULL,
  `debtorcode` varchar(30) DEFAULT NULL,
  `invno` int(11) DEFAULT NULL COMMENT '= billno',
  `billno` int(11) DEFAULT NULL,
  `lineno_` int(11) DEFAULT NULL,
  `billtype` varchar(1) DEFAULT NULL,
  `chgclass` varchar(1) DEFAULT NULL,
  `classlevel` int(11) DEFAULT NULL,
  `chggroup` varchar(12) DEFAULT NULL,
  `lastuser` varchar(30) DEFAULT NULL,
  `lastupdate` datetime DEFAULT NULL,
  `invcode` varchar(12) DEFAULT NULL,
  `seqno` int(11) DEFAULT NULL,
  `discamt` decimal(7,2) DEFAULT NULL,
  `docref` varchar(30) DEFAULT NULL,
  `uom` varchar(30) DEFAULT NULL,
  `recstatus` varchar(30) DEFAULT NULL,
  `unitprice` decimal(12,2) DEFAULT NULL,
  `taxcode` varchar(15) DEFAULT NULL,
  `billtypeperct` decimal(12,2) DEFAULT NULL,
  `billtypeamt` decimal(12,2) DEFAULT NULL,
  `id` int(11) NOT NULL AUTO_INCREMENT,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=7 DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `billsum`
--

LOCK TABLES `billsum` WRITE;
/*!40000 ALTER TABLE `billsum` DISABLE KEYS */;
INSERT INTO `billsum` VALUES (NULL,'9A','PB','IN',12,NULL,4.00,6.00,NULL,0.0000,NULL,NULL,NULL,NULL,NULL,NULL,NULL,9,1,NULL,NULL,NULL,'101000901','farid2','2022-02-14 15:34:27',NULL,NULL,0.00,NULL,'1\'S','OPEN',1.50,'ES',100.00,0.00,1),(NULL,'9A','PB','IN',13,NULL,10.00,100.00,NULL,0.0000,9,NULL,NULL,NULL,NULL,NULL,NULL,10,1,NULL,NULL,NULL,'101000901','farid2','2022-02-23 15:17:03',NULL,NULL,0.00,NULL,'1\'S','OPEN',0.50,'ES',0.00,100.00,2),(NULL,'9A','PB','IN',16,NULL,4.00,100.00,NULL,0.0000,9,NULL,NULL,NULL,NULL,NULL,NULL,10,1,NULL,NULL,NULL,'101000901','farid2','2022-02-23 15:18:38',NULL,NULL,0.00,NULL,'1\'S','OPEN',0.50,'ES',0.00,100.00,5),(NULL,'9A','PB','IN',17,NULL,1.00,12.00,NULL,0.0000,23,1,NULL,NULL,NULL,NULL,NULL,11,1,NULL,NULL,NULL,'102000412','farid2','2022-02-24 14:46:06',NULL,NULL,0.00,NULL,'EA','OPEN',12.00,'ZRE',100.00,0.00,6);
/*!40000 ALTER TABLE `billsum` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `billtrack`
--

DROP TABLE IF EXISTS `billtrack`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `billtrack` (
  `compcode` varchar(30) DEFAULT NULL,
  `source` varchar(30) DEFAULT NULL,
  `trantype` varchar(30) DEFAULT NULL,
  `auditno` int(11) DEFAULT NULL,
  `lineno_` int(11) DEFAULT NULL,
  `trxno` int(11) DEFAULT NULL,
  `trxcode` varchar(30) DEFAULT NULL,
  `trxdate` datetime DEFAULT NULL,
  `level_` int(11) DEFAULT NULL,
  `comment_` varchar(40) DEFAULT NULL,
  `adduser` varchar(30) DEFAULT NULL,
  `recstatus` varchar(30) DEFAULT NULL,
  `upduser` varchar(30) DEFAULT NULL,
  `upddate` datetime DEFAULT NULL,
  `adddate` datetime DEFAULT NULL,
  `patientname` varchar(40) DEFAULT NULL,
  `staffname` varchar(40) DEFAULT NULL,
  `staffno` varchar(20) DEFAULT NULL,
  `pharmacy` decimal(7,2) DEFAULT NULL,
  `doctorfee` decimal(7,2) DEFAULT NULL,
  `injection` decimal(7,2) DEFAULT NULL,
  `otherfee` decimal(7,2) DEFAULT NULL,
  `phardesc` varchar(255) DEFAULT NULL,
  `injdesc` varchar(255) DEFAULT NULL,
  `doctordesc` varchar(255) DEFAULT NULL,
  `otherdesc` varchar(255) DEFAULT NULL,
  `diagnosis` varchar(255) DEFAULT NULL,
  `mcno` int(11) DEFAULT NULL,
  `mcdate` datetime DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `billtrack`
--

LOCK TABLES `billtrack` WRITE;
/*!40000 ALTER TABLE `billtrack` DISABLE KEYS */;
/*!40000 ALTER TABLE `billtrack` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `bnkindetl`
--

DROP TABLE IF EXISTS `bnkindetl`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `bnkindetl` (
  `auditno` int(11) NOT NULL,
  `lineno_` int(11) DEFAULT NULL,
  `refsource` varchar(2) DEFAULT NULL,
  `reftrantype` varchar(2) DEFAULT NULL,
  `refauditno` int(11) DEFAULT NULL,
  `refamount` decimal(7,2) DEFAULT NULL,
  `bnkinamt` decimal(7,2) DEFAULT NULL,
  `bnksts` varchar(1) DEFAULT NULL,
  `entrydate` datetime DEFAULT NULL,
  `upddate` datetime DEFAULT NULL,
  `usrid` varchar(30) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `bnkindetl`
--

LOCK TABLES `bnkindetl` WRITE;
/*!40000 ALTER TABLE `bnkindetl` DISABLE KEYS */;
/*!40000 ALTER TABLE `bnkindetl` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `bnkinhdr`
--

DROP TABLE IF EXISTS `bnkinhdr`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `bnkinhdr` (
  `auditno` int(11) NOT NULL,
  `bankcode` varchar(30) DEFAULT NULL,
  `paymode` varchar(30) DEFAULT NULL,
  `entrydate` datetime DEFAULT NULL,
  `totamt` decimal(8,2) DEFAULT NULL,
  `bnksts` varchar(1) DEFAULT NULL,
  `upddate` datetime DEFAULT NULL,
  `usrid` varchar(30) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `bnkinhdr`
--

LOCK TABLES `bnkinhdr` WRITE;
/*!40000 ALTER TABLE `bnkinhdr` DISABLE KEYS */;
/*!40000 ALTER TABLE `bnkinhdr` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `cardrate`
--

DROP TABLE IF EXISTS `cardrate`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `cardrate` (
  `compcode` varchar(30) DEFAULT NULL,
  `paymode` varchar(30) DEFAULT NULL,
  `effectdate` datetime DEFAULT NULL,
  `rate` decimal(7,2) DEFAULT NULL,
  `adduser` varchar(30) DEFAULT NULL,
  `adddate` datetime DEFAULT NULL,
  `upduser` varchar(30) DEFAULT NULL,
  `upddate` datetime DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `cardrate`
--

LOCK TABLES `cardrate` WRITE;
/*!40000 ALTER TABLE `cardrate` DISABLE KEYS */;
/*!40000 ALTER TABLE `cardrate` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `chgdebtorhis`
--

DROP TABLE IF EXISTS `chgdebtorhis`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `chgdebtorhis` (
  `compcode` varchar(2) DEFAULT NULL,
  `mrn` int(11) DEFAULT NULL,
  `episno` int(11) DEFAULT NULL,
  `source` varchar(2) DEFAULT NULL,
  `trantype` varchar(2) DEFAULT NULL,
  `auditno` int(11) NOT NULL,
  `pvdebtype` varchar(30) DEFAULT NULL,
  `pvdebcode` varchar(12) DEFAULT NULL,
  `crdebtype` varchar(30) DEFAULT NULL,
  `crdebcode` varchar(12) DEFAULT NULL,
  `upddate` datetime DEFAULT NULL,
  `usrid` varchar(30) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `chgdebtorhis`
--

LOCK TABLES `chgdebtorhis` WRITE;
/*!40000 ALTER TABLE `chgdebtorhis` DISABLE KEYS */;
/*!40000 ALTER TABLE `chgdebtorhis` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `dbactdtl`
--

DROP TABLE IF EXISTS `dbactdtl`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `dbactdtl` (
  `idno` int(11) NOT NULL AUTO_INCREMENT,
  `compcode` varchar(2) DEFAULT NULL,
  `source` varchar(2) DEFAULT NULL,
  `trantype` varchar(2) DEFAULT NULL,
  `auditno` int(11) DEFAULT NULL,
  `lineno_` int(11) DEFAULT NULL,
  `entrydate` datetime DEFAULT NULL,
  `document` varchar(50) DEFAULT NULL,
  `reference` varchar(50) DEFAULT NULL,
  `amount` decimal(12,2) DEFAULT NULL,
  `stat` varchar(1) DEFAULT NULL,
  `mrn` int(11) DEFAULT NULL,
  `episno` int(11) DEFAULT NULL,
  `billno` int(11) DEFAULT NULL,
  `paymode` varchar(30) DEFAULT NULL,
  `allocauditno` int(11) DEFAULT NULL,
  `alloclineno` int(11) DEFAULT NULL,
  `alloctnauditno` int(11) DEFAULT NULL,
  `alloctnlineno` int(11) DEFAULT NULL,
  `lastuser` varchar(30) DEFAULT NULL,
  `lastupdate` datetime DEFAULT NULL,
  `grnno` varchar(50) DEFAULT NULL,
  `dorecno` int(11) DEFAULT NULL,
  `category` varchar(30) DEFAULT NULL,
  `deptcode` varchar(30) DEFAULT NULL,
  `adduser` varchar(12) DEFAULT NULL,
  `adddate` datetime DEFAULT NULL,
  `recstatus` varchar(20) DEFAULT NULL,
  `upduser` varchar(15) DEFAULT NULL,
  `upddate` datetime DEFAULT NULL,
  `deluser` varchar(15) DEFAULT NULL,
  `deldate` datetime DEFAULT NULL,
  `GSTCode` varchar(15) DEFAULT NULL,
  `AmtB4GST` decimal(15,2) DEFAULT NULL,
  `unit` varchar(10) DEFAULT NULL,
  `tot_gst` decimal(15,2) DEFAULT NULL COMMENT 'amtslstax',
  PRIMARY KEY (`idno`),
  UNIQUE KEY `apactdtl_srcttaudln_idx` (`compcode`,`source`,`trantype`,`auditno`,`lineno_`),
  KEY `apactdtl_mrnepis` (`mrn`,`episno`),
  KEY `apactdtl_paymode` (`paymode`,`entrydate`)
) ENGINE=InnoDB AUTO_INCREMENT=7 DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `dbactdtl`
--

LOCK TABLES `dbactdtl` WRITE;
/*!40000 ALTER TABLE `dbactdtl` DISABLE KEYS */;
INSERT INTO `dbactdtl` VALUES (1,'9A','PB','CN',NULL,1,'2022-04-26 12:32:30','FSG',NULL,0.00,NULL,NULL,NULL,NULL,'',NULL,NULL,NULL,NULL,'farid2','2022-04-26 12:32:30','',NULL,'20060107','4FL','farid2','2022-04-26 12:32:30','OPEN',NULL,NULL,NULL,NULL,'ER',34.00,'',0.00),(2,'9A','PB','CN',1,1,'2022-04-26 12:59:16','21212',NULL,121212.00,NULL,NULL,NULL,NULL,'',NULL,NULL,NULL,NULL,'farid2','2022-04-26 12:59:16','',NULL,'20060107','4FL','farid2','2022-04-26 12:59:16','OPEN',NULL,NULL,NULL,NULL,'ER',0.00,'',0.00),(3,'9A','PB','CN',NULL,2,'2022-04-28 16:16:41','FAFAAF',NULL,600.00,NULL,NULL,NULL,NULL,'',NULL,NULL,NULL,NULL,'farid2','2022-04-28 16:16:41','',NULL,'20060107','A&E','farid2','2022-04-28 16:16:41','OPEN',NULL,NULL,NULL,NULL,'ER',0.00,'',0.00),(4,'9A','PB','CN',NULL,3,'2022-04-28 16:17:17','765',NULL,5800.00,NULL,NULL,NULL,NULL,'',NULL,NULL,NULL,NULL,'farid2','2022-04-28 16:17:17','',NULL,'20060107','ADM','farid2','2022-04-28 16:17:17','OPEN',NULL,NULL,NULL,NULL,'SR',0.00,'',0.00),(5,'9A','PB','CN',2,1,'2022-04-28 16:18:45','RUT',NULL,3450.00,NULL,NULL,NULL,NULL,'',NULL,NULL,NULL,NULL,'farid2','2022-04-28 16:18:45','',NULL,'20060107','2FL','farid2','2022-04-28 16:18:45','OPEN',NULL,NULL,NULL,NULL,'SR',0.00,'',0.00),(6,'9A','PB','CN',2,2,'2022-04-28 16:19:24','TYU',NULL,980.00,NULL,NULL,NULL,NULL,'',NULL,NULL,NULL,NULL,'farid2','2022-04-28 16:19:24','',NULL,'20060107','A&E','farid2','2022-04-28 16:19:24','OPEN',NULL,NULL,NULL,NULL,'ER',0.00,'',0.00);
/*!40000 ALTER TABLE `dbactdtl` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `dbacthdr`
--

DROP TABLE IF EXISTS `dbacthdr`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `dbacthdr` (
  `idno` int(11) NOT NULL AUTO_INCREMENT,
  `compcode` varchar(2) DEFAULT NULL,
  `source` varchar(2) NOT NULL,
  `trantype` varchar(2) NOT NULL,
  `auditno` int(11) NOT NULL,
  `lineno_` int(11) DEFAULT '1',
  `amount` decimal(9,2) DEFAULT NULL,
  `outamount` decimal(9,2) DEFAULT NULL,
  `recstatus` varchar(10) DEFAULT NULL,
  `entrydate` date DEFAULT NULL,
  `entrytime` time DEFAULT NULL COMMENT 'currenttime',
  `entryuser` varchar(30) DEFAULT NULL,
  `reference` varchar(40) DEFAULT NULL,
  `recptno` varchar(25) DEFAULT NULL COMMENT 'tillcode + recptno',
  `paymode` varchar(30) DEFAULT NULL,
  `tillcode` varchar(30) DEFAULT NULL,
  `tillno` int(11) DEFAULT NULL,
  `debtortype` varchar(30) DEFAULT NULL,
  `debtorcode` varchar(17) DEFAULT NULL,
  `payercode` varchar(17) DEFAULT NULL,
  `billdebtor` varchar(17) DEFAULT NULL,
  `remark` text,
  `mrn` varchar(11) DEFAULT '0',
  `episno` varchar(11) DEFAULT '0',
  `authno` varchar(10) DEFAULT NULL,
  `expdate` date DEFAULT NULL,
  `adddate` date DEFAULT NULL,
  `adduser` varchar(30) DEFAULT NULL,
  `upddate` datetime DEFAULT NULL,
  `upduser` varchar(30) DEFAULT NULL,
  `deldate` date DEFAULT NULL,
  `deluser` varchar(30) DEFAULT NULL,
  `epistype` varchar(2) DEFAULT NULL,
  `cbflag` tinyint(4) DEFAULT '0',
  `conversion` tinyint(4) DEFAULT '0',
  `payername` varchar(100) DEFAULT NULL,
  `hdrtype` varchar(30) DEFAULT NULL COMMENT 'sales ambil dari billtype, deposit ambil dari deposit type',
  `currency` varchar(30) DEFAULT NULL,
  `rate` decimal(9,4) DEFAULT NULL,
  `unit` varchar(30) DEFAULT NULL,
  `invno` varchar(30) DEFAULT NULL,
  `paytype` varchar(30) DEFAULT NULL COMMENT '/addded',
  `bankcharges` decimal(15,2) DEFAULT NULL,
  `RCCASHbalance` decimal(15,2) DEFAULT NULL,
  `RCOSbalance` decimal(15,2) DEFAULT NULL,
  `RCFinalbalance` decimal(15,2) DEFAULT NULL,
  `PymtDescription` varchar(100) DEFAULT NULL COMMENT 'descrption sysparam',
  `orderno` varchar(30) DEFAULT NULL,
  `ponum` varchar(30) DEFAULT NULL,
  `podate` date DEFAULT NULL,
  `termdays` int(10) DEFAULT NULL,
  `termmode` varchar(30) DEFAULT NULL,
  `deptcode` varchar(50) DEFAULT NULL,
  `posteddate` date DEFAULT NULL,
  `approvedby` varchar(200) DEFAULT NULL,
  `approveddate` date DEFAULT NULL,
  PRIMARY KEY (`idno`),
  UNIQUE KEY `compcode` (`compcode`,`source`,`trantype`,`auditno`,`lineno_`),
  KEY `tillno` (`compcode`,`tillno`),
  KEY `payercode` (`compcode`,`payercode`,`entrydate`,`source`,`trantype`),
  KEY `paymode` (`compcode`,`paymode`,`entrydate`)
) ENGINE=InnoDB AUTO_INCREMENT=9 DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `dbacthdr`
--

LOCK TABLES `dbacthdr` WRITE;
/*!40000 ALTER TABLE `dbacthdr` DISABLE KEYS */;
INSERT INTO `dbacthdr` VALUES (1,'9A','PB','IN',9,1,6.00,NULL,'POSTED','2022-02-14','15:28:24',NULL,NULL,NULL,NULL,NULL,NULL,NULL,'KLINIKSA','KLINIKSA',NULL,'SALES ORDER','',NULL,NULL,NULL,'2022-02-14','farid2',NULL,NULL,NULL,NULL,NULL,0,0,NULL,'STD',NULL,NULL,'PHAR','3',NULL,NULL,NULL,NULL,NULL,NULL,'','','2022-02-14',30,'DAYS','PHAR','2022-02-14','',NULL),(2,'9A','PB','IN',10,1,200.00,NULL,'POSTED','2022-02-23','15:16:27',NULL,NULL,NULL,NULL,NULL,NULL,NULL,'10024','10024',NULL,'','9','0',NULL,NULL,'2022-02-23','farid2',NULL,NULL,NULL,NULL,NULL,0,0,NULL,'YES',NULL,NULL,'PHAR','4',NULL,NULL,NULL,NULL,NULL,NULL,'','','2022-02-23',30,'DAYS','PHAR','2022-02-23','',NULL),(3,'9A','PB','IN',11,1,12.00,NULL,'POSTED','2022-02-24','14:45:50',NULL,NULL,NULL,NULL,NULL,NULL,NULL,'10024','10024',NULL,'','23','1',NULL,NULL,'2022-02-24','farid2',NULL,NULL,NULL,NULL,NULL,0,0,NULL,'BCN',NULL,NULL,'PHST','5',NULL,NULL,NULL,NULL,NULL,NULL,'','','2022-02-24',30,'DAYS','PHST','2022-02-24',NULL,NULL),(4,'9A','PB','RC',28,1,NULL,NULL,'ACTIVE',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'PT',NULL,'608141873',NULL,NULL,'0','0',NULL,NULL,'2022-03-22','farid2',NULL,NULL,NULL,NULL,NULL,0,0,'MUHAMMAD HAKIMI IKRAM BIN MOHD IRWAN',NULL,'RM',NULL,'NORTHA',NULL,'#F_TAB-CASH',NULL,NULL,NULL,NULL,'RECEIPT',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL),(5,'9A','PB','RC',29,1,NULL,NULL,'ACTIVE',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'CAMEX',NULL,'(N138861)',NULL,NULL,'0','0',NULL,NULL,'2022-03-23','farid2',NULL,NULL,NULL,NULL,NULL,0,0,'GANESAN RAMALIN',NULL,'RM',NULL,'NORTHA',NULL,'#F_TAB-CASH',NULL,NULL,NULL,NULL,'RECEIPT',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL),(6,'9A','PB','CN',0,1,NULL,NULL,'OPEN','2022-04-26','12:23:10',NULL,NULL,NULL,NULL,NULL,NULL,NULL,'(TNB)PM CARE','(TNB)PM CARE',NULL,'SGDGD','0',NULL,NULL,NULL,'2022-04-26','farid2',NULL,NULL,NULL,NULL,NULL,0,0,NULL,'',NULL,NULL,'',NULL,NULL,NULL,NULL,NULL,NULL,NULL,'','',NULL,NULL,'','',NULL,NULL,'2022-04-26'),(7,'9A','PB','CN',1,1,121212.00,NULL,'OPEN','2022-04-26','12:33:33',NULL,NULL,NULL,NULL,NULL,NULL,NULL,'1386783','1386783',NULL,'','',NULL,NULL,NULL,'2022-04-26','farid2',NULL,NULL,NULL,NULL,NULL,0,0,NULL,'',NULL,NULL,'',NULL,NULL,NULL,NULL,NULL,NULL,NULL,'','',NULL,NULL,'','',NULL,NULL,'2022-04-26'),(8,'9A','PB','CN',2,1,4430.00,NULL,'OPEN','2022-04-28','16:16:27',NULL,NULL,NULL,NULL,NULL,NULL,NULL,'(N138861)','(N138861)',NULL,'DAFAF','',NULL,NULL,NULL,'2022-04-28','farid2',NULL,NULL,NULL,NULL,NULL,0,0,NULL,'',NULL,NULL,'',NULL,NULL,NULL,NULL,NULL,NULL,NULL,'','',NULL,NULL,'','',NULL,NULL,'2022-04-28');
/*!40000 ALTER TABLE `dbacthdr` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `dbacthdr_12`
--

DROP TABLE IF EXISTS `dbacthdr_12`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `dbacthdr_12` (
  `compcode` varchar(2) DEFAULT NULL,
  `source` varchar(2) NOT NULL,
  `trantype` varchar(2) NOT NULL,
  `auditno` int(11) NOT NULL,
  `lineno_` int(11) DEFAULT NULL,
  `amount` decimal(9,2) DEFAULT NULL,
  `outamount` decimal(9,2) DEFAULT NULL,
  `hdrsts` varchar(1) DEFAULT NULL,
  `entrydate` datetime DEFAULT NULL,
  `entrytime` varchar(5) DEFAULT NULL,
  `entryuser` varchar(30) DEFAULT NULL,
  `reference` varchar(40) DEFAULT NULL,
  `recptno` varchar(17) DEFAULT NULL,
  `paymode` varchar(30) DEFAULT NULL,
  `tillcode` varchar(30) DEFAULT NULL,
  `tillno` int(11) DEFAULT NULL,
  `debtortype` varchar(30) DEFAULT NULL,
  `debtorcode` varchar(17) DEFAULT NULL,
  `payercode` varchar(17) DEFAULT NULL,
  `billdebtor` varchar(17) DEFAULT NULL,
  `remark` varchar(40) DEFAULT NULL,
  `mrn` int(11) DEFAULT NULL,
  `episno` int(11) DEFAULT NULL,
  `authno` varchar(10) DEFAULT NULL,
  `expdate` datetime DEFAULT NULL,
  `upddate` datetime DEFAULT NULL,
  `upduser` varchar(10) DEFAULT NULL,
  `epistype` varchar(2) DEFAULT NULL,
  `cbflag` tinyint(4) DEFAULT NULL,
  `conversion` tinyint(4) DEFAULT NULL,
  `payername` varchar(40) DEFAULT NULL,
  `hdrtype` varchar(30) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `dbacthdr_12`
--

LOCK TABLES `dbacthdr_12` WRITE;
/*!40000 ALTER TABLE `dbacthdr_12` DISABLE KEYS */;
/*!40000 ALTER TABLE `dbacthdr_12` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `dballoc`
--

DROP TABLE IF EXISTS `dballoc`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `dballoc` (
  `compcode` varchar(2) DEFAULT NULL,
  `source` varchar(2) DEFAULT NULL,
  `trantype` varchar(2) DEFAULT NULL,
  `auditno` int(11) DEFAULT NULL,
  `lineno_` int(11) DEFAULT NULL,
  `docsource` varchar(2) DEFAULT NULL,
  `doctrantype` varchar(2) DEFAULT NULL,
  `docauditno` int(11) DEFAULT NULL,
  `refsource` varchar(2) DEFAULT NULL,
  `reftrantype` varchar(2) DEFAULT NULL,
  `refauditno` int(11) DEFAULT NULL,
  `refamount` decimal(8,2) DEFAULT NULL,
  `reflineno` int(11) DEFAULT NULL,
  `recptno` varchar(17) DEFAULT NULL,
  `mrn` int(11) DEFAULT NULL,
  `episno` int(11) DEFAULT NULL,
  `allocsts` varchar(1) DEFAULT NULL,
  `amount` decimal(9,2) DEFAULT NULL,
  `tillcode` varchar(30) DEFAULT NULL,
  `debtortype` varchar(30) DEFAULT NULL,
  `debtorcode` varchar(17) DEFAULT NULL,
  `payercode` varchar(17) DEFAULT NULL,
  `paymode` varchar(30) NOT NULL,
  `allocdate` datetime DEFAULT NULL,
  `remark` varchar(40) DEFAULT NULL,
  `upddate` datetime DEFAULT NULL,
  `upduser` varchar(30) DEFAULT NULL,
  `balance` decimal(7,2) DEFAULT NULL,
  `adddate` datetime DEFAULT NULL,
  `adduser` varchar(33) DEFAULT NULL,
  `recstatus` varchar(5) DEFAULT NULL,
  `idno` int(11) NOT NULL AUTO_INCREMENT,
  PRIMARY KEY (`idno`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `dballoc`
--

LOCK TABLES `dballoc` WRITE;
/*!40000 ALTER TABLE `dballoc` DISABLE KEYS */;
/*!40000 ALTER TABLE `dballoc` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `dballoc_12`
--

DROP TABLE IF EXISTS `dballoc_12`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `dballoc_12` (
  `compcode` varchar(2) DEFAULT NULL,
  `source` varchar(2) DEFAULT NULL,
  `trantype` varchar(2) DEFAULT NULL,
  `auditno` int(11) DEFAULT NULL,
  `lineno_` int(11) DEFAULT NULL,
  `docsource` varchar(2) DEFAULT NULL,
  `doctrantype` varchar(2) DEFAULT NULL,
  `docauditno` int(11) DEFAULT NULL,
  `refsource` varchar(2) DEFAULT NULL,
  `reftrantype` varchar(2) DEFAULT NULL,
  `refauditno` int(11) DEFAULT NULL,
  `refamount` decimal(8,2) DEFAULT NULL,
  `reflineno` int(11) DEFAULT NULL,
  `recptno` varchar(17) DEFAULT NULL,
  `mrn` int(11) DEFAULT NULL,
  `episno` int(11) DEFAULT NULL,
  `allocsts` varchar(1) DEFAULT NULL,
  `amount` decimal(9,2) DEFAULT NULL,
  `tillcode` varchar(30) DEFAULT NULL,
  `debtortype` varchar(30) DEFAULT NULL,
  `debtorcode` varchar(17) DEFAULT NULL,
  `payercode` varchar(17) DEFAULT NULL,
  `paymode` varchar(30) NOT NULL,
  `allocdate` datetime DEFAULT NULL,
  `remark` varchar(40) DEFAULT NULL,
  `upddate` datetime DEFAULT NULL,
  `upduser` varchar(30) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `dballoc_12`
--

LOCK TABLES `dballoc_12` WRITE;
/*!40000 ALTER TABLE `dballoc_12` DISABLE KEYS */;
/*!40000 ALTER TABLE `dballoc_12` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `dballocsum`
--

DROP TABLE IF EXISTS `dballocsum`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `dballocsum` (
  `compcode` varchar(2) DEFAULT NULL,
  `source` varchar(2) DEFAULT NULL,
  `trantype` varchar(2) DEFAULT NULL,
  `auditno` int(11) DEFAULT NULL,
  `lineno_` int(11) DEFAULT NULL,
  `chggroup` varchar(4) DEFAULT NULL,
  `chgclass` varchar(2) DEFAULT NULL,
  `docsource` varchar(2) DEFAULT NULL,
  `doctrantype` varchar(2) DEFAULT NULL,
  `docauditno` int(11) DEFAULT NULL,
  `refsource` varchar(2) DEFAULT NULL,
  `reftrantype` varchar(2) DEFAULT NULL,
  `refauditno` int(11) DEFAULT NULL,
  `refamount` decimal(8,2) DEFAULT NULL,
  `reflineno` int(11) DEFAULT NULL,
  `recptno` varchar(17) DEFAULT NULL,
  `mrn` int(11) DEFAULT NULL,
  `episno` int(11) DEFAULT NULL,
  `docstat` tinyint(4) DEFAULT NULL,
  `taxstat` tinyint(4) DEFAULT NULL,
  `allocsumsts` varchar(1) DEFAULT NULL,
  `amount` decimal(9,2) DEFAULT NULL,
  `tillcode` varchar(30) DEFAULT NULL,
  `debtortype` varchar(30) DEFAULT NULL,
  `debtorcode` varchar(17) DEFAULT NULL,
  `payercode` varchar(17) DEFAULT NULL,
  `paymode` varchar(30) NOT NULL,
  `allocsumdate` datetime DEFAULT NULL,
  `remark` varchar(40) DEFAULT NULL,
  `upddate` datetime DEFAULT NULL,
  `upduser` varchar(30) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `dballocsum`
--

LOCK TABLES `dballocsum` WRITE;
/*!40000 ALTER TABLE `dballocsum` DISABLE KEYS */;
/*!40000 ALTER TABLE `dballocsum` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `dbprdhdr`
--

DROP TABLE IF EXISTS `dbprdhdr`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `dbprdhdr` (
  `compcode` varchar(2) DEFAULT NULL,
  `debtorcode` varchar(30) NOT NULL,
  `debtortype` varchar(30) NOT NULL,
  `periodyy` int(11) DEFAULT NULL,
  `periodmm` int(11) DEFAULT NULL,
  `patbalance` decimal(10,2) DEFAULT NULL,
  `mscbalance` decimal(10,2) DEFAULT NULL,
  `unbbalance` decimal(10,2) DEFAULT NULL,
  `unallbalnce` decimal(9,2) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `dbprdhdr`
--

LOCK TABLES `dbprdhdr` WRITE;
/*!40000 ALTER TABLE `dbprdhdr` DISABLE KEYS */;
/*!40000 ALTER TABLE `dbprdhdr` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `debtcomm`
--

DROP TABLE IF EXISTS `debtcomm`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `debtcomm` (
  `compcode` varchar(2) DEFAULT NULL,
  `debtorcode` varchar(17) DEFAULT NULL,
  `entrydate` datetime DEFAULT NULL,
  `comment_` varchar(256) DEFAULT NULL,
  `lastuser` varchar(30) DEFAULT NULL,
  `lastupdate` datetime DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `debtcomm`
--

LOCK TABLES `debtcomm` WRITE;
/*!40000 ALTER TABLE `debtcomm` DISABLE KEYS */;
/*!40000 ALTER TABLE `debtcomm` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `debtorcover`
--

DROP TABLE IF EXISTS `debtorcover`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `debtorcover` (
  `compcode` varchar(30) DEFAULT NULL,
  `debtorcode` varchar(17) DEFAULT NULL,
  `deptcode` varchar(30) DEFAULT NULL,
  `casecode` varchar(30) DEFAULT NULL,
  `cover` tinyint(4) DEFAULT NULL,
  `chgcode` varchar(30) DEFAULT NULL,
  `chggroup` varchar(30) DEFAULT NULL,
  `chgtype` varchar(30) DEFAULT NULL,
  `adduser` varchar(30) DEFAULT NULL,
  `adddate` datetime DEFAULT NULL,
  `upduser` varchar(30) DEFAULT NULL,
  `upddate` datetime DEFAULT NULL,
  `recstatus` varchar(30) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `debtorcover`
--

LOCK TABLES `debtorcover` WRITE;
/*!40000 ALTER TABLE `debtorcover` DISABLE KEYS */;
/*!40000 ALTER TABLE `debtorcover` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `debtordept`
--

DROP TABLE IF EXISTS `debtordept`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `debtordept` (
  `compcode` varchar(30) DEFAULT NULL,
  `debtorcode` varchar(17) DEFAULT NULL,
  `department` varchar(30) DEFAULT NULL,
  `add1` varchar(30) DEFAULT NULL,
  `add2` varchar(30) DEFAULT NULL,
  `add3` varchar(30) DEFAULT NULL,
  `add4` varchar(30) DEFAULT NULL,
  `adduser` varchar(30) DEFAULT NULL,
  `adddate` datetime DEFAULT NULL,
  `upduser` varchar(30) DEFAULT NULL,
  `upddate` datetime DEFAULT NULL,
  `recstatus` varchar(30) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `debtordept`
--

LOCK TABLES `debtordept` WRITE;
/*!40000 ALTER TABLE `debtordept` DISABLE KEYS */;
/*!40000 ALTER TABLE `debtordept` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `debtormast`
--

DROP TABLE IF EXISTS `debtormast`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `debtormast` (
  `idno` int(10) NOT NULL AUTO_INCREMENT,
  `compcode` varchar(5) NOT NULL DEFAULT '',
  `debtortype` varchar(10) DEFAULT NULL,
  `debtorcode` varchar(17) NOT NULL,
  `name` varchar(400) DEFAULT NULL,
  `address1` varchar(400) DEFAULT NULL,
  `address2` varchar(400) DEFAULT NULL,
  `address3` varchar(400) DEFAULT NULL,
  `address4` varchar(400) DEFAULT NULL,
  `postcode` int(44) DEFAULT NULL,
  `statecode` varchar(4) DEFAULT NULL,
  `countrycode` varchar(400) DEFAULT NULL,
  `contact` varchar(40) DEFAULT NULL,
  `position` varchar(20) DEFAULT NULL,
  `teloffice` varchar(30) DEFAULT NULL,
  `fax` varchar(40) DEFAULT NULL,
  `email` varchar(50) DEFAULT NULL,
  `payto` varchar(50) DEFAULT NULL,
  `billtype` varchar(5) DEFAULT NULL,
  `billtypeop` varchar(5) DEFAULT NULL,
  `recstatus` varchar(10) DEFAULT NULL,
  `outamt` decimal(9,2) DEFAULT NULL,
  `depamt` decimal(9,2) DEFAULT '0.00',
  `creditlimit` decimal(9,2) DEFAULT NULL,
  `actdebccode` varchar(10) DEFAULT NULL,
  `actdebglacc` varchar(30) DEFAULT NULL,
  `depccode` varchar(10) DEFAULT NULL,
  `depglacc` varchar(30) DEFAULT NULL,
  `otherccode` varchar(3) DEFAULT NULL,
  `otheracct` varchar(30) DEFAULT NULL,
  `debtorgroup` varchar(30) DEFAULT NULL,
  `crgroup` varchar(30) DEFAULT NULL,
  `otheraddr1` varchar(400) DEFAULT NULL,
  `otheraddr2` varchar(400) DEFAULT NULL,
  `otheraddr3` varchar(400) DEFAULT NULL,
  `otheraddr4` varchar(400) DEFAULT NULL,
  `accno` varchar(20) DEFAULT NULL,
  `othertel` varchar(30) DEFAULT NULL,
  `requestgl` varchar(30) DEFAULT NULL,
  `creditterm` int(11) DEFAULT NULL,
  `adduser` varchar(30) DEFAULT NULL,
  `adddate` datetime DEFAULT NULL,
  `coverageip` decimal(12,2) DEFAULT NULL,
  `coverageop` decimal(12,2) DEFAULT NULL,
  `upduser` varchar(30) DEFAULT NULL,
  `upddate` datetime DEFAULT NULL,
  `deluser` varchar(30) DEFAULT NULL,
  `deldate` datetime DEFAULT NULL,
  `computerid` varchar(20) DEFAULT NULL,
  `ipaddress` varchar(20) DEFAULT NULL,
  `lastcomputerid` varchar(20) DEFAULT NULL,
  `lastipaddress` varchar(20) DEFAULT NULL,
  PRIMARY KEY (`compcode`,`debtorcode`,`idno`),
  KEY `idno` (`idno`),
  KEY `debtortype` (`compcode`,`debtortype`,`name`),
  FULLTEXT KEY `name` (`compcode`,`debtortype`,`name`)
) ENGINE=InnoDB AUTO_INCREMENT=306 DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `debtormast`
--

LOCK TABLES `debtormast` WRITE;
/*!40000 ALTER TABLE `debtormast` DISABLE KEYS */;
INSERT INTO `debtormast` VALUES (298,'13A','PT','0000007','ALI BIN MAIDIN KUTTY','204-12-1 SRI SUAJAYA','SENTUL',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'IP','OP','ACTIVE',NULL,0.00,NULL,'0000','3000/000','0000','3001/207',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,999999999.99,999999999.99,'hayati','2022-10-03 15:23:26',NULL,NULL,NULL,NULL,NULL,NULL),(303,'13A','PT','0000052','MOHAMAD SUFIAN BIN KAMARUDDIN',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'IP','OP','ACTIVE',NULL,0.00,NULL,'0000','3000/000','0000','3001/207',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,999999999.99,999999999.99,'hazman','2022-10-05 14:26:39',NULL,NULL,NULL,NULL,NULL,NULL),(299,'13A','PT','0000081','RAMLAH BINTI MOHD YUSOF',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'IP','OP','ACTIVE',NULL,0.00,NULL,'0000','3000/000','0000','3001/207',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,999999999.99,999999999.99,'fadhlina','2022-10-05 08:04:30',NULL,NULL,NULL,NULL,NULL,NULL),(305,'13A','PT','0000305','SYAMRIZAL BIN GHAZALI',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'IP','OP','ACTIVE',NULL,0.00,NULL,'0000','3000/000','0000','3001/207',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,999999999.99,999999999.99,'AISYAH.MUNIRAH','2022-10-12 17:36:10',NULL,NULL,NULL,NULL,NULL,NULL),(287,'13A','PT','0025517','MUHAMMAD ARIF BIN MOHAMMAD SHUKRI','NO. 12 JALAN DESA AMAN S16/1','TAMAN DESA AMAN',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'IP','OP','ACTIVE',NULL,0.00,NULL,'0000','3000/000','0000','3001/207',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,999999999.99,999999999.99,'muhammadarif','2022-09-21 10:07:03',NULL,NULL,NULL,NULL,NULL,NULL),(286,'13A','PT','0025518','AMIRUL AMIR','PICOMS BATU MUDA',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'IP','OP','ACTIVE',NULL,0.00,NULL,'0000','3000/000','0000','3001/207',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,999999999.99,999999999.99,'AMIRUL.AMIR','2022-09-21 10:06:54',NULL,NULL,NULL,NULL,NULL,NULL),(302,'13A','PR','81','RAMLAH BINTI MD YUSOF','41-05-01','FLAT SRI PERAK','BANDAR BARU SENTUL',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'IP','OP','A',NULL,0.00,NULL,'0000','3000/000','0000','3001/207',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'hazman','2022-10-05 13:29:47',NULL,NULL,NULL,NULL,NULL,NULL),(17,'13A','BM','BAITULMAL','MAJLIS AGAMA ISLAM WILAYAH PERSEKUTUAN (BAITULMAL)\r\n','','','','',0,'','','','','','',NULL,NULL,'OP','OP','ACTIVE',0.00,0.00,0.00,'0000','3000/000','0000','3001/207','','','?','','','','','','','','',0,'','0000-00-00 00:00:00',9999999.99,9999999.99,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL),(8,'13A','JK','DBKL','DEWAN BANDARAYA KUALA LUMPUR (DBKL)','','','','',0,'','','','','','',NULL,NULL,'OP','OP','ACTIVE',0.00,0.00,0.00,'0000','3000/000','0000','3001/207','','','?','','','','','','','','',0,'','0000-00-00 00:00:00',9999999.99,9999999.99,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL),(9,'13A','JK','HUKM','UNIVERSITI KEBANGSAAN MALAYSIA (HUKM) ','','','','',0,'','','','','','',NULL,NULL,'OP','OP','ACTIVE',0.00,0.00,0.00,'0000','3000/000','0000','3001/207','','','?','','','','','','','','',0,'','0000-00-00 00:00:00',9999999.99,9999999.99,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL),(10,'13A','JK','JAN','JABATAN AUDIT NEGARA','','','','',0,'','','','','','',NULL,NULL,'OP','OP','ACTIVE',0.00,0.00,0.00,'0000','3000/000','0000','3001/207','','','?','','','','','','','','',0,'','0000-00-00 00:00:00',9999999.99,9999999.99,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL),(11,'13A','JK','JHEV','JABATAN HAL EHWAL VETERAN ATM (BAHAGIAN ','','','','',0,'','','','','','',NULL,NULL,'OP','OP','ACTIVE',0.00,0.00,0.00,'0000','3000/000','0000','3001/207','','','?','','','','','','','','',0,'','0000-00-00 00:00:00',9999999.99,9999999.99,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL),(12,'13A','JK','JKOANM','JABATAN KEMAJUAN ORANG ASLI NEGERI SEMBILAN & MELAKA \r\n','','','','',0,'','','','','','',NULL,NULL,'OP','OP','ACTIVE',0.00,0.00,0.00,'0000','3000/000','0000','3001/207','','','?','','','','','','','','',0,'','0000-00-00 00:00:00',9999999.99,9999999.99,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL),(13,'13A','JK','JKOASW','JABATAN KEMAJUAN ORANG ASLI NEGERI SELANGOR & WILAYAH PERSEKUTUAN\r\n','','','','',0,'','','','','','',NULL,NULL,'OP','OP','ACTIVE',0.00,0.00,0.00,'0000','3000/000','0000','3001/207','','','?','','','','','','','','',0,'','0000-00-00 00:00:00',9999999.99,9999999.99,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL),(14,'13A','JK','JPA','JABATAN PERKHIDMATAN AWAM MALAYSIA (KWAP)\r\n','','','','',0,'','','','','','',NULL,NULL,'OP','OP','ACTIVE',0.00,0.00,0.00,'0000','3000/000','0000','3001/207','','','?','','','','','','','','',0,'','0000-00-00 00:00:00',9999999.99,9999999.99,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL),(15,'13A','JK','KPM','KEMENTERIAN PENDIDIKAN MALAYSIA','','','','',0,'','','','','','',NULL,NULL,'OP','OP','ACTIVE',0.00,0.00,0.00,'0000','3000/000','0000','3001/207','','','?','','','','','','','','',0,'','0000-00-00 00:00:00',9999999.99,9999999.99,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL),(16,'13A','JK','KPWM','KEMENTERIAN PEMBANGUNAN WANITA KELUARGA DAN MASYARAKAT\r\n','','','','',0,'','','','','','',NULL,NULL,'OP','OP','ACTIVE',0.00,0.00,0.00,'0000','3000/000','0000','3001/207','','','?','','','','','','','','',0,'','0000-00-00 00:00:00',9999999.99,9999999.99,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL),(18,'13A','MA','MAIS','LEMBAGA ZAKAT SELANGOR, MAJLIS AGAMA ISLAM SELANGOR (MAIS)\r\n','','','','',0,'','','','','','',NULL,NULL,'OP','OP','ACTIVE',0.00,0.00,0.00,'0000','3000/000','0000','3001/207','','','?','','','','','','','','',0,'','0000-00-00 00:00:00',9999999.99,9999999.99,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL),(19,'13A','JK','MOTAC','LEMBAGA PELANCONGAN MALAYSIA (KEMENTERIAN PELANCONGAN MALAYSIA)\r\n','','','','',0,'','','','','','',NULL,NULL,'OP','OP','ACTIVE',0.00,0.00,0.00,'0000','3000/000','0000','3001/207','','','?','','','','','','','','',0,'','0000-00-00 00:00:00',9999999.99,9999999.99,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL),(20,'13A','JK','PDRM','ASP KEBAJIKAN/PERKEP (IBU PEJABAT POLIS KONTINJEN KUALA LUMPUR)\r\n','','','','',0,'','','','','','',NULL,NULL,'OP','OP','ACTIVE',0.00,0.00,0.00,'0000','3000/000','0000','3001/207','','','?','','','','','','','','',0,'','0000-00-00 00:00:00',9999999.99,9999999.99,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL),(21,'13A','PS','PERKESO','PERTUBUHAN KESELAMATAN SOSIAL (PERKESO/SOCSO)\r\n','','','','',0,'','','','','','',NULL,NULL,'OP','OP','ACTIVE',0.00,0.00,0.00,'0000','3000/000','0000','3001/207','','','?','','','','','','','','',0,'','0000-00-00 00:00:00',9999999.99,9999999.99,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL),(22,'13A','CO','PMCARE','PMCARE SDN BHD','','','','',0,'','','','','','',NULL,NULL,'OP','OP','ACTIVE',0.00,0.00,0.00,'0000','3000/000','0000','3001/207','','','?','','','','','','','','',0,'','0000-00-00 00:00:00',9999999.99,9999999.99,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL),(23,'13A','CO','POS','POS MALAYSIA ','','','','',0,'','','','','','',NULL,NULL,'OP','OP','ACTIVE',0.00,0.00,0.00,'0000','3000/000','0000','3001/207','','','?','','','','','','','','',0,'','0000-00-00 00:00:00',9999999.99,9999999.99,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL),(304,'13A','JK','RAMPAI','SMK SRI RAMPAI',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'OP','OP','ACTIVE',0.00,0.00,0.00,'0000','3000/000','0000','3001/207',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,0,NULL,NULL,9999999.99,9999999.99,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL),(24,'13A','JK','UKM','UNIVERSITI KEBANGSAAN MALAYSIA (UKM) ','','','','',0,'','','','','','',NULL,NULL,'OP','OP','ACTIVE',0.00,0.00,0.00,'0000','3000/000','0000','3001/207','','','?','','','','','','','','',0,'','0000-00-00 00:00:00',9999999.99,9999999.99,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL),(25,'13A','JK','UTM','UNIVERSITI TEKNOLOGI MARA (UiTM) SHAH ALAM: UNIT KEWANGAN \r\n','','','','',0,'','','','','','',NULL,NULL,'OP','OP','ACTIVE',0.00,0.00,0.00,'0000','3000/000','0000','3001/207','','','?','','','','','','','','',0,'','0000-00-00 00:00:00',9999999.99,9999999.99,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL),(290,'9A','PR','101','SHAHIDAN BIN SITAM',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'OP',NULL,'A',NULL,0.00,NULL,'1000','10010000','1000','10010000',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'hazman','2022-09-29 13:44:07',NULL,NULL,NULL,NULL,NULL,NULL),(289,'9A','PR','106','SITI RAHMAH BINTI AHMAD',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'OP',NULL,'A',NULL,0.00,NULL,'1000','10010000','1000','10010000',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'hazman','2022-09-29 13:26:24',NULL,NULL,NULL,NULL,NULL,NULL),(296,'9A','PR','110','YUN BINTI JANAWI',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'OP',NULL,'A',NULL,0.00,NULL,'1000','10010000','1000','10010000',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'hazman','2022-09-29 13:46:36',NULL,NULL,NULL,NULL,NULL,NULL),(295,'9A','PR','112','ZAFTIJAN BIN TAJUDDIN',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'OP',NULL,'A',NULL,0.00,NULL,'1000','10010000','1000','10010000',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'hazman','2022-09-29 13:46:19',NULL,NULL,NULL,NULL,NULL,NULL),(283,'9A','PR','25447','MD NASIR,ALI HASSAN','UNIT A03-02-05 BLOK A3','JALAN SAMUDRA TIMUR 7','TAMAN SAMUDRA,BATU CAVES',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'OP',NULL,'A',NULL,0.00,NULL,'1000','10010000','1000','10010000',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'farid2','2022-09-10 15:05:09',NULL,NULL,NULL,NULL,NULL,NULL),(284,'9A','PR','25456','EVA,PHUA ZHI LING','36 JALAN PERDANA 2/10','TAMAN PANDAN PERDANA','',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'OP',NULL,'A',NULL,0.00,NULL,'1000','10010000','1000','10010000',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'farid2','2022-09-11 11:01:46',NULL,NULL,NULL,NULL,NULL,NULL),(285,'9A','PR','25496','TAJUL \'ARIFFIN BIN MAHADI @ OTHMAN','NO.23','JALAN INTAN 3/5','TAMAN PUCHONG INTAN',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'OP',NULL,'A',NULL,0.00,NULL,'1000','10010000','1000','10010000',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'farid2','2022-09-11 22:31:31',NULL,NULL,NULL,NULL,NULL,NULL),(27,'9A','PR','25514','UMMU ATHIAH BINTI SHAARI','NO 26 JALAN JAYA 4','TAMAN JAYA 4 FASA 1','JALAN MARAN',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'OP',NULL,'A',NULL,0.00,NULL,'1000','10010000','1000','10010000',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'farid2','2022-09-09 12:52:23',NULL,NULL,NULL,NULL,NULL,NULL),(297,'9A','PR','70','NG KIM HONG',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'OP',NULL,'A',NULL,0.00,NULL,'1000','10010000','1000','10010000',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'hazman','2022-09-29 13:46:58',NULL,NULL,NULL,NULL,NULL,NULL),(294,'9A','PR','87','ROHANI BINTI AHMAD',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'OP',NULL,'A',NULL,0.00,NULL,'1000','10010000','1000','10010000',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'hazman','2022-09-29 13:45:57',NULL,NULL,NULL,NULL,NULL,NULL),(293,'9A','PR','91','ROSLI BIN MOHAMMAD',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'OP',NULL,'A',NULL,0.00,NULL,'1000','10010000','1000','10010000',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'hazman','2022-09-29 13:45:01',NULL,NULL,NULL,NULL,NULL,NULL),(292,'9A','PR','97','SALLEH BIN KASSIM',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'OP',NULL,'A',NULL,0.00,NULL,'1000','10010000','1000','10010000',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'hazman','2022-09-29 13:44:41',NULL,NULL,NULL,NULL,NULL,NULL),(291,'9A','PR','98','SALMAH BINTI TAR',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'OP',NULL,'A',NULL,0.00,NULL,'1000','10010000','1000','10010000',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'hazman','2022-09-29 13:44:24',NULL,NULL,NULL,NULL,NULL,NULL),(28,'9A','CO','AKARI','AKARI SOFTWARE ASIA PACIFIC SDN BHD','OFFICE SUITE 1.1','UITM-MTDC TECHNOPRENEUR CENTRE','UNIVERSITI TEKNOLOGI MARA(UITM)','40000 SHAH ALAM, SELANGOR',40000,'','','PN YUSNITA','','03-55244941','',NULL,'IP','OP','A','0',0.00,0.00,1001.00,'615100','1001','712130','','','1/10/2019','norasikin','','','','','','','','',0,'0','0000-00-00 00:00:00',10.00,9999999.99,'9999999.99','0000-00-00 00:00:00',NULL,NULL,NULL,NULL,NULL,NULL),(29,'9A','CO','AKE','ANGER KLAKON ENTERPRISE','NO.7, JALAN CEMPAKA, SEKSYEN U19','TMN PAYA JARAS PERMAI','KG PAYA JARAS PERMAI','47000 SG BULOH, SELANGOR',47000,'','','','','019-6065903 / 019-2714599','03-6157 5640',NULL,'IP','OP','A','0',0.00,0.00,1001.00,'615100','1001','712130','','','8/05/2017','ANIS','','','','','','','','',0,'0','0000-00-00 00:00:00',4.00,9999999.99,'9999999.99','0000-00-00 00:00:00',NULL,NULL,NULL,NULL,NULL,NULL),(30,'9A','CO','ALLIANZ AAN','ALLIANZ LIFE INS (M) C/O ASIA ASST NETWORK','ASIA ASST NETWORK (M) SDN BHD','AA ONE, NO.1, BLOCK N, JAYA ONE','72A, JLN UNIVERSITI, 46200','PETALING JAYA, SELANGOR',0,'','','','','','',NULL,'IP','OP','A','68434.37',0.00,0.00,1001.00,'615100','1001','712130','','','6/12/2021','TAJUL','','','','','','','','',0,'0','0000-00-00 00:00:00',26.00,9999999.99,'9999999.99','0000-00-00 00:00:00',NULL,NULL,NULL,NULL,NULL,NULL),(31,'9A','CO','ALLIANZ GENERAL','ALLIANZ GENARAL INSURANCE COMPANY (M) BHD','ALLIANZ CUSTOMER HEALTHCARE','SUITE 6-5,6-7 & 6-8, LEVEL 6, WISMA UOA','DAMANSARA II, NO.6, CHANGKAT SEMANTAN','DAMANSARA HEIGHT, 50490 KUALA LUMPUR',50490,'','','','','1800-22-8322, 03-2011 9666','',NULL,'IP','OP','A','0',0.00,0.00,1001.00,'615100','1001','712130','','','6/12/2018','MIMI','','','','','','','','',0,'0','0000-00-00 00:00:00',6.00,9999999.99,'9999999.99','0000-00-00 00:00:00',NULL,NULL,NULL,NULL,NULL,NULL),(32,'9A','CO','ALLIANZ LIFE','ALLIANZ LIFE INSURANCE BERHAD','ALLIANZ CUSTOMER HEALTHCARE','SUITE 6-5,6-7 & 6-8, LEVEL 6, WISMA UOA','DAMANSARA II, NO.6, CHANGKAT SEMANTAN','DAMANSARA HEIGHT, 50490 KUALA LUMPUR',50490,'','','','','1800-22-8322, 03-2011 9666','',NULL,'IP','OP','A','4519.7',0.00,0.00,1001.00,'615100','1001','712130','','','23/12/2019','norasikin','','','','','','','','',0,'0','0000-00-00 00:00:00',6.00,9999999.99,'9999999.99','0000-00-00 00:00:00',NULL,NULL,NULL,NULL,NULL,NULL),(33,'9A','CO','ALLIANZ MICARE','ALLIANZ LIFE INSURANCE (M) BERHAD C/O MICARE S/B','NO.22, BLOCK A, JALAN ASTAKA U8/84','SEKSYEN U8, BUKIT JELUTONG','40150 SHAH ALAM, SELANGOR','',40150,'','','','','','',NULL,'IP','OP','A','28531.4',0.00,0.00,1001.00,'615100','1001','712130','','','13/02/2020','SHAWAL','','','','','','','','',0,'0','0000-00-00 00:00:00',6.00,9999999.99,'9999999.99','0000-00-00 00:00:00',NULL,NULL,NULL,NULL,NULL,NULL),(34,'9A','CO','AQIL STUDIO','AQIL AQILA STUDIO','','','','',0,'','','','','','',NULL,'IP','OP','A','0',0.00,0.00,1001.00,'615100','1001','712130','','','19/07/2017','MIMI','','','','','','','','',0,'0','0000-00-00 00:00:00',19.00,9999999.99,'9999999.99','0000-00-00 00:00:00',NULL,NULL,NULL,NULL,NULL,NULL),(35,'9A','CO','ARMINDER','ARMINDER & ASSOCIATES','NO.25-1, JLN RAMIN 1/KS 7','BOTANIC GATEWAY BUSSINESS CENTRE','41200 KLANG, SELANGOR','',41200,'','','','','03-33191004 / 8004','03-33192004',NULL,'IP','OP','A','0',0.00,0.00,1001.00,'615100','1001','712130','','','2/05/2019','ANIS','','','','','','','','',0,'0','0000-00-00 00:00:00',29.00,9999999.99,'9999999.99','0000-00-00 00:00:00',NULL,NULL,NULL,NULL,NULL,NULL),(36,'9A','CO','ASIA ASST','ASIA ASSISTANCE NETWORK (M) SDN BHD','AA ONE, JAYA ONE, 72A','JALAN UNIVERSITI','46200 PETALING JAYA','SELANGOR',46200,'','','NURHANAN ILHAMI','','03-7628 3888','',NULL,'IP','OP','A','363970.45',0.00,0.00,1001.00,'615100','1001','712130','','','17/02/2020','norasikin','','','','','','','','',0,'0','0000-00-00 00:00:00',6.00,9999999.99,'9999999.99','0000-00-00 00:00:00',NULL,NULL,NULL,NULL,NULL,NULL),(37,'9A','CO','ASP MEDICAL','ASP MEDICAL CLINIC SDN BHD','ATTN: INPATIENT TEAM (HELPDESK)','823-1-3, KEJORA BUSINESS POINT','JALAN PAYA TERUBONG, 11900','BAYAN LEPAS, MUKIM 13, P. PINANG',11900,'','','04-609 1611 / 04-609 1622','','03-2022 2677','',NULL,'IP','OP','A','23233.5',0.00,0.00,1001.00,'615100','1001','712130','','','31/01/2020','MIMI','','','','','','','','',0,'0','0000-00-00 00:00:00',16.00,9999999.99,'9999999.99','0000-00-00 00:00:00',NULL,NULL,NULL,NULL,NULL,NULL),(38,'9A','CO','B&A','BALDEV & ASSOCIATES','NO.25, 1ST FLOOR, JALAN HAJI SALLEH','OFF JALAN SENTUL, 51100','KUALA LUMPUR','',51100,'','','','','03-4041 5155','03-4042 5155',NULL,'IP','OP','A','0',0.00,0.00,1001.00,'615100','1001','712130','','','10/09/2019','JANNAH','','','','','','','','',0,'0','0000-00-00 00:00:00',19.00,9999999.99,'9999999.99','0000-00-00 00:00:00',NULL,NULL,NULL,NULL,NULL,NULL),(39,'9A','CO','BARAKAH','PUSAT BERSALIN BARAKAH','NO.7A, LORONG SANGGUL 1F','BANDAR PUTERI, 41200 KLANG','SELANGOR','',41200,'','','','','','',NULL,'IP','OP','A','0',0.00,0.00,1001.00,'615100','1001','712130','','','28/06/2019','norasikin','','','','','','','','',0,'0','0000-00-00 00:00:00',10.00,9999999.99,'9999999.99','0000-00-00 00:00:00',NULL,NULL,NULL,NULL,NULL,NULL),(40,'9A','CO','BCB','BERJAYA CORPORATION BERHAD','LEVEL 12, BERJAYA TIMES SQUARE','NO.1, JALAN IMBI, 55100','KUALA LUMPUR','',55100,'','','PN REENA','HR','03 - 2149 1999','',NULL,'IP','OP','A','0',0.00,0.00,1001.00,'615100','1001','712130','','','18/01/2019','nuramira','','','','','','','','',0,'0','0000-00-00 00:00:00',18.00,9999999.99,'9999999.99','0000-00-00 00:00:00',NULL,NULL,NULL,NULL,NULL,NULL),(41,'9A','CO','BCSB','BOUSTEAD CURVE SDN BHD','2ND FLOOR, NO.6, JALAN PJU 7/3','MUTIARA DAMANSARA','47810 PETALING JAYA','SELANGOR',47810,'','','PN IZYAN NADZIRA','HUMAN RESOURCE EXECU','03-7725 0277 EXT 110','03-7725 3277',NULL,'IP','OP','A','0',0.00,0.00,1001.00,'615100','1001','712130','','','9/02/2018','mimi','','','UITM PRIVATE HEALTHCARE SDN BHD','1.2038E+13','','','','',0,'0','0000-00-00 00:00:00',20.00,9999999.99,'9999999.99','0000-00-00 00:00:00',NULL,NULL,NULL,NULL,NULL,NULL),(42,'9A','CO','BHB','BOUSTEAD HOLDING BERHAD','GROUP FINANCE DEPT, 5TH FLOOR','MENARA BOUSTEAD, 69 JLN RAJA CHULAN','50200 KUALA LUMPUR','',50200,'','','','','03 - 2141 9044','',NULL,'IP','OP','A','0',0.00,0.00,1001.00,'615100','1001','712130','','','4/07/2019','NORASIKIN','','','','','','','','',0,'0','0000-00-00 00:00:00',27.00,9999999.99,'9999999.99','0000-00-00 00:00:00',NULL,NULL,NULL,NULL,NULL,NULL),(43,'9A','CO','BWC','BOUSTEAD WELD COURT SDN BHD','CHULAN TOWER MANAGEMENT OFFICE','BASEMENT 1, CHULAN TOWER, NO.3','JALAN CONLAY, 50450 KUALA LUMPUR','',50450,'','','MS EUNICE CHIN MEYYEE','','03 - 2141 9044','03 - 2143 5332',NULL,'IP','OP','A','0',0.00,0.00,1001.00,'615100','1001','712130','','','20/04/2018','NURAMIRA','','','','','','','','',0,'0','0000-00-00 00:00:00',23.00,9999999.99,'9999999.99','0000-00-00 00:00:00',NULL,NULL,NULL,NULL,NULL,NULL),(44,'9A','CO','C.SPECTRUM','SUKARNI MOHAMED SALLEH','NO.7 JALAN PERIGI NENAS 8/6','INDAH POINT PULAU INDAH','PERLABUHAN KLANG','',42920,'','','122278115','SENIOR EXECUTIVE, HU','331012020','331013030',NULL,'IP','OP','A','0',0.00,0.00,1001.00,'615100','1001','712130','','','17/04/2019','NORASIKIN','','','MBB','12101115014','','','','',0,'0','0000-00-00 00:00:00',17.00,9999999.99,'9999999.99','0000-00-00 00:00:00',NULL,NULL,NULL,NULL,NULL,NULL),(45,'9A','CO','CIGNA','CIGNA GLOBAL HEALTH BENEFITS','SCHLUMBERGER CUSTOMER CONTACT CENTRE','INTEGRATED HEALTH TEAM','1 KNOWE ROAD, GREENOCK, SCOTLAND','UK, PA15 4RJ',0,'','','','','','',NULL,'IP','OP','A','0',0.00,0.00,1001.00,'615100','1001','712130','','','1/01/2019','NURAMIRA','','','','','','','','',0,'0','0000-00-00 00:00:00',13.00,9999999.99,'9999999.99','0000-00-00 00:00:00',NULL,NULL,NULL,NULL,NULL,NULL),(46,'9A','CO','CKD','M-CKD PRECISION SDN HD','LOT NO. 6, JALAN MODAL 23/2','SEKSYEN 23, KAWASAN MIEL, FASA 8','40300 SHAH ALAM, SELANGOR','',40300,'','','MRS CHRISTINA','','03-5541 1468','',NULL,'IP','OP','A','0',0.00,0.00,1001.00,'615100','1001','712130','','','2/10/2017','mimi','','','','','','','','',0,'0','0000-00-00 00:00:00',10.00,9999999.99,'9999999.99','0000-00-00 00:00:00',NULL,NULL,NULL,NULL,NULL,NULL),(47,'9A','CO','CS','CENTRAL SPECTRUM (M) SDN BHD','NO.7, JALAN PERIGI NENAS 8/6','INDAH POINT, PULAU INDAH','42920 PORT KLANG','SELANGOR',42920,'','','PN SUKARNI MOHAMAED SALLEH','HR EXECUTIVE','03-3101 2020','03-3101 3030',NULL,'IP','OP','A','395.6',0.00,5000.00,1001.00,'615100','1001','712130','','','12/02/2020','norasikin','','','','','','','','',0,'60','0000-00-00 00:00:00',27.00,9999999.99,'9999999.99','0000-00-00 00:00:00',NULL,NULL,NULL,NULL,NULL,NULL),(48,'9A','CO','CSR','CENTRAL SUGARS REFINERY SDN BHD','BATU TIGA,','4000 SHAH ALAM,','SELANGOR.','',4000,'','','CIK NAJIHAH','HR','03-5520 7200','03-5512 7268',NULL,'IP','OP','A','0',0.00,0.00,1001.00,'615100','1001','712130','','','4/01/2019','nuramira','','','','','','','','',0,'0','0000-00-00 00:00:00',21.00,9999999.99,'9999999.99','0000-00-00 00:00:00',NULL,NULL,NULL,NULL,NULL,NULL),(49,'9A','CO','CUBEFILM','CUBE FILM SDN BHD','NO.1, JALAN SS25/34','MAYANG LIGHT INDUSTRIAL PARK','47301 PETALING JAYA','SELANGOR',47301,'','','','','','',NULL,'IP','OP','A','0',0.00,0.00,1001.00,'615100','1001','712130','','','31/05/2017','MIMI','','','','','','','','',0,'0','0000-00-00 00:00:00',31.00,9999999.99,'9999999.99','0000-00-00 00:00:00',NULL,NULL,NULL,NULL,NULL,NULL),(50,'9A','CO','DAIKIN','DAIKIN MALAYSIA SDN BHD','LOT 60334, PERSIARAN BUKIT RAHMAN PUTRA','TMN PERINDUSTRIAN BUKIT RAHMAN PUTRA','47000 SUNGAI BULOH, SELANGOR','',47000,'','','MS ELFFERRA ROZZANNA BT KHALIB','','03-6145 8600 / 8615','03-61412286',NULL,'IP','OP','A','260',0.00,0.00,1001.00,'615100','1001','712130','','','6/06/2018','nuramira','','','','','','','','',0,'0','0000-00-00 00:00:00',9.00,9999999.99,'9999999.99','0000-00-00 00:00:00',NULL,NULL,NULL,NULL,NULL,NULL),(51,'9A','JK','DBKL','DEWAN BANDARAYA KUALA LUMPUR (DBKL)','','','','',0,'','','','','','',NULL,'OP','OP','ACTIV','0',0.00,0.00,0.00,'3000/000','0','3001/207','','','?','','?','','','','','','','',0,'0','0000-00-00 00:00:00',0.00,9999999.99,'9999999.99','0000-00-00 00:00:00',NULL,NULL,NULL,NULL,NULL,NULL),(52,'9A','CO','DHIRACOMM','DHIRACOMM ENTERPRISE','NO.69, JALAN NOVA U5/76, SUBANG BESTARI','SEKSYEN U5, BANDAR PINGGIRAN SUBANG','40150 SHAH ALAM, SELANGOR','',40150,'','','RUSLI MOHD HARON','TECHNICAL MANAGER','03- 7846 1408','03- 7845 4764',NULL,'IP','OP','A','0',0.00,0.00,1001.00,'615100','1001','712130','','','30/05/2017','ANIS','','','','','','','','',0,'0','0000-00-00 00:00:00',30.00,9999999.99,'9999999.99','0000-00-00 00:00:00',NULL,NULL,NULL,NULL,NULL,NULL),(53,'9A','CO','DISITU','DISITU HOLDINGS SDN BHD','2-13A, LEVEL 2, PERDANA THE PLACE','JLN PJU 8/5G, DAMANSARA PERDANA','47820 PETALING JAYA','SELANGOR',47820,'','','NOR FAIZAH ABD AZIZ','','03-7725 0434','',NULL,'IP','OP','A','0',0.00,0.00,1001.00,'615100','1001','712130','','','16/05/2018','nuramira','','','','','','','','',0,'0','0000-00-00 00:00:00',20.00,9999999.99,'9999999.99','0000-00-00 00:00:00',NULL,NULL,NULL,NULL,NULL,NULL),(54,'9A','CO','E-MAS','EXIMUS MEDICAL ADMINISTRATION SOLUTIONS SDN BHD','(E-MAS SDN BHD) (INPATIENT CLAIMS DEPT)','BANGUNAN MMA, LEVEL -2, 124 JLN PAHANG','53000 KUALA LUMPUR','',53000,'','','','','03-4041 3627','03-4041 8627',NULL,'IP','OP','A','11713.6',0.00,0.00,1001.00,'615100','1001','712130','','','30/01/2020','JANNAH','','','','','','','','',0,'0','0000-00-00 00:00:00',17.00,9999999.99,'9999999.99','0000-00-00 00:00:00',NULL,NULL,NULL,NULL,NULL,NULL),(55,'9A','CO','EMBASSY','ROYAL EMBASSY OF SAUDI  ARABIA','LEVEL 4, WISMA CHINESE CHAMBER','258, JALAN AMPANG','50450 KUALA LUMPUR','',50450,'','','','','03-4257 9433 / 03-141 2653','',NULL,'IP','OP','A','0',0.00,0.00,1001.00,'615100','1001','712130','','','15/01/2020','norasikin','','','ASMA MUSAZAY (EXT : 207) / EN. HASSAN','','','','','',0,'0','0000-00-00 00:00:00',7.00,9999999.99,'9999999.99','0000-00-00 00:00:00',NULL,NULL,NULL,NULL,NULL,NULL),(56,'9A','CO','EPSON','EPSON PRECISION MALAYSIA SDN BHD','LOT NO.1, JLN PERSIARAN INDUSTRI','TMN PERINDUSTRIAN SRI DAMANSARA','BDR SRI DAMANSARA','52200 KUALA LUMPUR',52200,'','','MDM OOI POH THIM','SENIOR MANAGER (HR)','03-62729078 / 79','',NULL,'IP','OP','A','0',0.00,0.00,1001.00,'615100','1001','712130','','','1/08/2018','nuramira','','','','','','','','',0,'0','0000-00-00 00:00:00',10.00,9999999.99,'9999999.99','0000-00-00 00:00:00',NULL,NULL,NULL,NULL,NULL,NULL),(57,'9A','CO','ETIQA','ETIQA INSURANCE & TAKAFUL BERHAD','EMPLOYEE BENEFIT & GROUP MEDICAL','LEVEL 17, TOWER B, DATARAN MAYBANK','NO.1, JALAN MAAROF','59000 KUALA LUMPUR',59000,'','','SITI FADZILLAH ISHAK','EXECUTICE ACC MANAGE','03-22986258','03-27856226',NULL,'IP','OP','A','75084.67',0.00,0.00,1001.00,'615100','1001','712130','','','17/02/2020','norasikin','','','','','','','','',0,'0','0000-00-00 00:00:00',3.00,9999999.99,'9999999.99','0000-00-00 00:00:00',NULL,NULL,NULL,NULL,NULL,NULL),(58,'9A','CO','FEDFLOUR','FEDFLOUR MARKETING SDN BHD','PT 45125, BATU 15 1/2','SUNGAI PELONG, 47000','SUNGAI BULOH, SELANGOR','',47000,'','','MS ROSHNEE NATHAN','','03 - 6145 7888 (EXT : 7388)','03 - 6145 7998',NULL,'IP','OP','A','0',0.00,0.00,1001.00,'615100','1001','712130','','','17/01/2020','MIMI','','','','','','','','',0,'0','0000-00-00 00:00:00',17.00,9999999.99,'9999999.99','0000-00-00 00:00:00',NULL,NULL,NULL,NULL,NULL,NULL),(59,'9A','CO','FELDA','FELDA','TINGKAT 41, MENARA FELDA','PLATINUM PARK, NO.11','PERSIARAN KLCC','50088 KUALA LUMPUR',50088,'','','','','03-2191 2191','03-2191 2590',NULL,'IP','OP','A','22537.4',0.00,0.00,1001.00,'615100','1001','712130','','','12/02/2020','norasikin','','','','','','','','',0,'0','0000-00-00 00:00:00',30.00,9999999.99,'9999999.99','0000-00-00 00:00:00',NULL,NULL,NULL,NULL,NULL,NULL),(60,'9A','CO','FFM','FFM MARKETING SDN BHD','PT 45125, BATU 15 1/2','SUNGAI PELONG, P.O BOX 78','47000 SUNGAI BULOH','SELNAGOR',47000,'','',' MS. ROSHNEE NATHAN',' ADMIN & HUMAN CAPIT','03-6145 7888  (EXT 7388)',' 03 - 6145 7998',NULL,'IP','OP','A','1732.5',0.00,10000.00,1001.00,'615100','1001','712130','','','21/01/2020','NORASIKIN','','','','','','','','',0,'0','0000-00-00 00:00:00',21.00,9999999.99,'9999999.99','0000-00-00 00:00:00',NULL,NULL,NULL,NULL,NULL,NULL),(61,'9A','CO','FGV','FGV SECURITY SERVICES SDN BHD','TINGKAT 10,(EAST) WISMA FGV','JALAN RAJA LAUT','50350 KUALA LUMPUR','',50350,'','','PUAN MAHNOM &  EN REDZUAN','SENIOR EXECUTIVE,HUM','03-2789 1285 / 1287','327891290',NULL,'IP','OP','A','0',0.00,0.00,1001.00,'615100','1001','712130','','','25/04/2019','MIMI','','','','','','','','',0,'0','0000-00-00 00:00:00',25.00,9999999.99,'9999999.99','0000-00-00 00:00:00',NULL,NULL,NULL,NULL,NULL,NULL),(62,'9A','CO','FIFFCO','FELDA IFFCO SDN BHD','LOT 596, LEBUH RAJA LUMU','PANDAMARAN INDUSTRIAL ESTATE','PO BOX 204, 42009 PORT KLANG','SELANGOR',42009,'','','EN ABUL','HR MANAGER','03-3168 7601','03-3167 1980',NULL,'IP','OP','A','0',0.00,0.00,1001.00,'615100','1001','712130','','','25/03/2019','MIMI','','','','','','','','',0,'0','0000-00-00 00:00:00',12.00,9999999.99,'9999999.99','0000-00-00 00:00:00',NULL,NULL,NULL,NULL,NULL,NULL),(63,'9A','CO','FITA','FITA STUDIOS SDN BHD','LEVEL 4, BLOCK 1','INTEKMA RESORT & CONVENTION CENTRE','PERSIARAN RAJA MUDA, SEKSYEN 7','40000 SHAH ALAM, SELANGOR',40000,'','','','','03 - 5522 5053','',NULL,'IP','OP','A','0',0.00,0.00,1001.00,'615100','1001','712130','','','25/05/2018','nuramira','','','','','','','','',0,'0','0000-00-00 00:00:00',10.00,9999999.99,'9999999.99','0000-00-00 00:00:00',NULL,NULL,NULL,NULL,NULL,NULL),(64,'9A','CO','FSSB','FILMMECCA STUDIO SDN BHD','NO 2-14-3, PRECINT ALAMI','PUSAT PERNIAGAAN WORLWIDE','PERSIARAN AKUATIK, SEKSYEN 13','40100 SHAH ALAM, SELANGOR',40100,'','','','','03 - 5523 0433','03 - 8922 0666',NULL,'IP','OP','A','0',0.00,0.00,1001.00,'615100','1001','712130','','','23/11/2017','fauziana','','','','','','','','',0,'0','0000-00-00 00:00:00',23.00,9999999.99,'9999999.99','0000-00-00 00:00:00',NULL,NULL,NULL,NULL,NULL,NULL),(65,'9A','CO','FTSB','FELDA TECHNOPLANT SDN BHD','BHG PEMBANGUNAN SUMBER MANUSIA','TINGKAT 28, MENARA FELDA,','PLATINUM PARK NO.11, PERSIARAN KLCC,','50088 KUALA LUMPUR',50088,'','','','','03-21912800','03-21912940/ 21912943',NULL,'IP','OP','A','0',0.00,0.00,1001.00,'615100','1001','712130','','','6/09/2018','MIMI','','','','','','','','',0,'0','0000-00-00 00:00:00',30.00,9999999.99,'9999999.99','0000-00-00 00:00:00',NULL,NULL,NULL,NULL,NULL,NULL),(66,'9A','CO','G DORAI','G.DORAI & CO','NO.7, JALAN MAWAR 1','TAMAN MAWAR','48000 RAWANG','SELANGOR',48000,'','','','','03 - 6093 6890, 6891','03 - 6093 3677',NULL,'IP','OP','A','0',0.00,0.00,1001.00,'615100','1001','712130','','','7/11/2019','m.faris','','','','','','','','',0,'0','0000-00-00 00:00:00',28.00,9999999.99,'9999999.99','0000-00-00 00:00:00',NULL,NULL,NULL,NULL,NULL,NULL),(67,'9A','CO','GA','GALAXY AEROSPACE (M) SDN BHD','SUITE 11-14, MRO CENTRE, MALAYSIA','INTERNATIONAL AEROSPACE CENTRE,','SUL.ABD AZIZ SHAH AIRPORT, 47200','SUBANG, SELANGOR',47200,'','','','','03-7734 7226','03- 7734 7526',NULL,'IP','OP','A','0',0.00,0.00,1001.00,'615100','1001','712130','','','8/07/2019','MIMI','','','','','','','','',0,'0','0000-00-00 00:00:00',2.00,9999999.99,'9999999.99','0000-00-00 00:00:00',NULL,NULL,NULL,NULL,NULL,NULL),(68,'9A','CO','GD BUILDERS','GD BUILDERS SDN BHD','SUITE 17-10, 17TH FLOOR, WISMA UOA II','NO.21, JALAN PINANG','50450 KUALA LUMPUR','',50450,'','','','','03-2166 5588','03-2166 5599',NULL,'IP','OP','A','0',0.00,0.00,1001.00,'615100','1001','712130','','','27/07/2016','HUDA','','','UITM PRIVATE HEALTHCARE SDN BHD','1.2038E+13','','','','',0,'0','0000-00-00 00:00:00',30.00,9999999.99,'9999999.99','0000-00-00 00:00:00',NULL,NULL,NULL,NULL,NULL,NULL),(69,'9A','CO','GE','GREAT EASTERN LIFE ASSURANCE (M) BERHAD','MENARA GREAT EASTERN, LEVEL 16','303, JALAN AMPANG','50450 KUALA LUMPUR','ATT : HEALTHCARE SEVICES DEPARTMENT',50450,'','','PRIMALADEVI MANIKAM','','03-4813 3517','',NULL,'IP','OP','A','1252.09',0.00,0.00,1001.00,'615100','1001','712130','','','10/01/2020','MIMI','','','','','','','','',0,'0','0000-00-00 00:00:00',22.00,9999999.99,'9999999.99','0000-00-00 00:00:00',NULL,NULL,NULL,NULL,NULL,NULL),(70,'9A','CO','GE AAN','GREAT EASTERN LIFE INSURANCE (M) BERHAD C/O ASIA ASSIST','LEVEL G, AA ONE, NO. 1, BLOCK N, JAYA ON','72A JALAN UNIVERSITI','46200 PETALING JAYA','',46200,'','','MISS PRETHIBA','','03 7628 3665','03 7629 8335',NULL,'IP','OP','A','37641.6',0.00,0.00,1001.00,'615100','1001','712130','','','18/11/2019','norasikin','','','','','','','','',0,'0','0000-00-00 00:00:00',29.00,9999999.99,'9999999.99','0000-00-00 00:00:00',NULL,NULL,NULL,NULL,NULL,NULL),(71,'9A','CO','GE MICARE','GREAT EASTERN LIFE ASS C/O MICARE SDN BHD','GREAT EASTERN LIFE ASSURANCE (M) BERHAD','MENARA GREAT EASTERN,','LEVEL16, 303 JALAN AMPANG,','50450, KUALA LUMPUR.',50450,'','','','','03-7847 9459','03-7847 4304',NULL,'IP','OP','A','129729.8',0.00,0.00,1001.00,'615100','1001','712130','','','17/02/2020','norasikin','','','','','','','','',0,'0','0000-00-00 00:00:00',22.00,9999999.99,'9999999.99','0000-00-00 00:00:00',NULL,NULL,NULL,NULL,NULL,NULL),(72,'9A','CO','GMB','GENTING MALAYSIA BERHAD','FINANCE DEPARTMENT','18TH FLOOR, WISMA GENTING','28, JALAN SULTAN ISMAIL','50250 KUALA LUMPUR',50250,'','','MS SIEW LIN','','03-6101 1118','03-6105 2140',NULL,'IP','OP','A','0',0.00,0.00,1001.00,'615100','1001','712130','','','31/07/2018','nuramira','','','','','','','','',0,'0','0000-00-00 00:00:00',20.00,9999999.99,'9999999.99','0000-00-00 00:00:00',NULL,NULL,NULL,NULL,NULL,NULL),(73,'9A','CO','GR','GEETHAN RAM ADVOCATES & SOLICITOR','SUITE NO.5, L15-05, PJX TOWER','NO.16A, PERSIARAN BARAT','46050 PETALING JAYA','SELANGOR',46050,'','','','','03-7931 5777','03-7932 1777',NULL,'IP','OP','A','0',0.00,0.00,1001.00,'615100','1001','712130','','','8/10/2018','JANNAH','','','','','','','','',0,'0','0000-00-00 00:00:00',5.00,9999999.99,'9999999.99','0000-00-00 00:00:00',NULL,NULL,NULL,NULL,NULL,NULL),(74,'9A','CO','GS','GLOBAL SCIENCE SDN BHD','(FOR PAYMENT VENDOR PROFILE)','','','',0,'','','','','','',NULL,'IP','OP','A','0',0.00,0.00,1001.00,'615100','1001','712130','','','17/07/2019','norasikin','','','','','','','','',0,'0','0000-00-00 00:00:00',27.00,9999999.99,'9999999.99','0000-00-00 00:00:00',NULL,NULL,NULL,NULL,NULL,NULL),(75,'9A','CO','HASHIM ASS','I.HASHIM & ASSOCIATES','NO.A55, 1ST FLOOR, SUSURAN BDR BARU','MERGONG, TMN BDR BARU MERGONG','05150 ALOR SETAR, KEDAH','',0,'','','','','04 - 7305 718, 7308 738','04 - 7306 728',NULL,'IP','OP','A','0',0.00,0.00,1001.00,'615100','1001','712130','','','17/02/2020','MIMI','','','','','','','','',0,'0','0000-00-00 00:00:00',9.00,9999999.99,'9999999.99','0000-00-00 00:00:00',NULL,NULL,NULL,NULL,NULL,NULL),(76,'9A','CO','HEALTH CONNECT','HEALTH CONNECT SDN BHD','F-G-6, BLOCK F','PUSAT KOMERSIAL PARKLANE','NO.21, JALAN SS7/26','47301 KELANA JAYA, SELANGOR',47301,'','','','','03-7884 1919','03- 7809 9333',NULL,'IP','OP','A','26005.85',0.00,0.00,1001.00,'615100','1001','712130','','','31/01/2020','norasikin','','','','','','','','',0,'0','0000-00-00 00:00:00',11.00,9999999.99,'9999999.99','0000-00-00 00:00:00',NULL,NULL,NULL,NULL,NULL,NULL),(77,'9A','CO','HL YAMAHA','HL YAMAHA MOTOR RESEARCH CENTRE SDN BHD','KOMPLEKS HONG LEONG YAMAHA,','LOT 57, PERSIARAN BUKIT RAHMAN PUTRA 3,','47000 SUNGAI BULOH, SELANGOR','',47000,'','','PN AZZUAH BT HARUN','','03-6157 7086','03-6157 7002',NULL,'IP','OP','A','0',0.00,0.00,1001.00,'615100','1001','712130','','','9/01/2019','NURAMIRA','','','','','','','','',0,'0','0000-00-00 00:00:00',9.00,9999999.99,'9999999.99','0000-00-00 00:00:00',NULL,NULL,NULL,NULL,NULL,NULL),(78,'9A','CO','HLY MARINE','HLY MARINE SDN BHD','KOMPLEKS HONG LEONG YAMAHA,','LOT 57, PERSIARAN BUKIT RAHMAN PUTRA 3,','47000, SUNGAI BULOH.','SUNGAI BULOH',47000,'','','PN AZZUAH BT HARUN','','03-6157 7086','03 6157 7002',NULL,'IP','OP','A','0',0.00,0.00,1001.00,'615100','1001','712130','','','10/05/2019','norasikin','','','','','','','','',0,'0','0000-00-00 00:00:00',9.00,9999999.99,'9999999.99','0000-00-00 00:00:00',NULL,NULL,NULL,NULL,NULL,NULL),(79,'9A','CO','HMETRICS','DELETE','','','','',0,'','','','','','',NULL,'IP','OP','A','0',0.00,0.00,1001.00,'615100','1001','712130','','','2/01/2020','MIMI','','','','','','','','',0,'0','0000-00-00 00:00:00',2.00,9999999.99,'9999999.99','0000-00-00 00:00:00',NULL,NULL,NULL,NULL,NULL,NULL),(80,'9A','CO','HMSB','HEALTHMETRICS SDN BHD','B-04, LEVEL 4, THE PLACE@ ONE CITY','JALAN USJ 25/1, 47650 SUBANG JAYA','SELANGOR','',47500,'','','','','03-7499 0092 / 0093','03 -5636 7706',NULL,'IP','OP','A','663.7',0.00,0.00,1001.00,'615100','1001','712130','','','2/01/2020','MIMI','','','','','','','','',0,'0','0000-00-00 00:00:00',2.00,9999999.99,'9999999.99','0000-00-00 00:00:00',NULL,NULL,NULL,NULL,NULL,NULL),(81,'9A','CO','HONG LEONG','HONG LEONG YAMAHA MOTOR SDN BHD','KOMPLEKS HONG LEONG YAMAHA,','LOT 57, PERSIARAN BUKIT RAHMAN PUTRA 3,','47000 SUNGAI BULOH, SELANGOR','',47000,'','','PN AZZUAH BT HARUN','','03-6157 7086','03-6157 7002',NULL,'IP','OP','A','31372.85',0.00,0.00,1001.00,'615100','1001','712130','','','3/02/2020','norasikin','','','','','','','','',0,'0','0000-00-00 00:00:00',9.00,9999999.99,'9999999.99','0000-00-00 00:00:00',NULL,NULL,NULL,NULL,NULL,NULL),(82,'9A','JK','HUKM','UNIVERSITI KEBANGSAAN MALAYSIA (HUKM)','','','','',0,'','','','','','',NULL,'OP','OP','ACTIV','0',0.00,0.00,0.00,'3000/000','0','3001/207','','','?','','?','','','','','','','',0,'0','0000-00-00 00:00:00',0.00,9999999.99,'9999999.99','0000-00-00 00:00:00',NULL,NULL,NULL,NULL,NULL,NULL),(83,'9A','CO','ICP','INDUSTRIAL CONCRETE PRODUCTS SDN BHD','WISMA IJM ANNEXE','JALAN YONG SHOOK LIN','46050 PETALING JAYA','SELANGOR',46050,'','','','','03-79858288 EXT : 8691','',NULL,'IP','OP','A','0',0.00,0.00,1001.00,'615100','1001','712130','','','19/07/2018','nuramira','','','','','','','','',0,'0','0000-00-00 00:00:00',26.00,9999999.99,'9999999.99','0000-00-00 00:00:00',NULL,NULL,NULL,NULL,NULL,NULL),(84,'9A','CO','IHM SDN BHD','INTEGRATED HEALTHCARE MANAGEMENT','B-04, LEVEL 4, THE PLACE @ ONE CITY','JALAN USJ 25/1, 47650 SUBANG JAYA','SELANGOR','',47650,'','','MISS LEE MING / PN AMIRAH','','03 - 8602 9288 (CALL CENTRE)','03 -8602 9218 (CALL CENTRE)',NULL,'IP','OP','A','0',0.00,0.00,1001.00,'615100','1001','712130','','','10/01/2020','MIMI','','','','','','','','',0,'0','0000-00-00 00:00:00',25.00,9999999.99,'9999999.99','0000-00-00 00:00:00',NULL,NULL,NULL,NULL,NULL,NULL),(85,'9A','CO','IHP','INTEGRATED HEALTH PLANS (M) SDN BHD','UNIT 9-8, LEVEL 9, MENARA LIVINGSTON','170 JALAN ARGYLL, 10050 GEORGETOWN','PULAU PINANG','ATTN : CLAIMS DEPARTMENT',10050,'','','','','1 300 88 0100','',NULL,'IP','OP','A','0',0.00,0.00,1001.00,'615100','1001','712130','','','19/12/2019','MIMI','','','','','','','','',0,'0','0000-00-00 00:00:00',19.00,9999999.99,'9999999.99','0000-00-00 00:00:00',NULL,NULL,NULL,NULL,NULL,NULL),(86,'9A','CO','INGRESS','INGRESS TECHNOLOGIES SDN BHD','LOT 11, JALAN JASMINE 4','KAWASAN PERINDUSTRIAN BUKIT BERUNTUNG','48300 RAWANG, SELANGOR','',48300,'','','','','03-6028 3003','03-6028 3001/4',NULL,'IP','OP','A','155',0.00,0.00,1001.00,'615100','1001','712130','','','6/12/2019','norasikin','','','','','','','','',0,'0','0000-00-00 00:00:00',2.00,9999999.99,'9999999.99','0000-00-00 00:00:00',NULL,NULL,NULL,NULL,NULL,NULL),(87,'9A','CO','INOKOM','INOKOM CORPORATION SDN BHD','LOT 38, MUKIM PADANG MEHA,','09400 PADANG SERAI,','KULIM KEDAH','',9400,'','','PN IRMA HARUN','HUMAN RESOURCE','04-4031888','04-4036888',NULL,'IP','OP','A','0',0.00,0.00,1001.00,'615100','1001','712130','','','28/12/2018','nuramira','','','','','','','','',0,'0','0000-00-00 00:00:00',15.00,9999999.99,'9999999.99','0000-00-00 00:00:00',NULL,NULL,NULL,NULL,NULL,NULL),(88,'9A','CO','INTEC','INTEC EDUCATION COLLEGE','HUMAN CAPITAL OFFICE','JALAN SENANGIN SATU 17/2A','SEKSYEN 17, 40200 SHAH ALAM','SELANGOR',0,'','','EN. RAFEDE','','03-5522 7000','03-5522 7010',NULL,'IP','OP','A','4140',0.00,0.00,1001.00,'615100','1001','712130','','','7/01/2020','norasyikin','','','','','','','','',0,'0','0000-00-00 00:00:00',20.00,9999999.99,'9999999.99','0000-00-00 00:00:00',NULL,NULL,NULL,NULL,NULL,NULL),(89,'9A','CO','ISIS','INSTITUT KAJIAN STRATEGIK DAN ANTARABANGSA','NO.1, PERSIARAN SULTAN SALAHUDDIN','P.O BOX 12424, 50778 KUALA LUMPUR','','',50778,'','','PN SUHAILI','','03 - 26939 366','03 - 26915 435',NULL,'IP','OP','A','1742.3',0.00,0.00,1001.00,'615100','1001','712130','','','11/11/2019','norasikin','','','','','','','','',0,'0','0000-00-00 00:00:00',18.00,9999999.99,'9999999.99','0000-00-00 00:00:00',NULL,NULL,NULL,NULL,NULL,NULL),(90,'9A','CO','ITALIAN','THE ITALIAN BAKER SDN BHD','PT 45125, BATU 15 1/2','SUNGAI PELONG, 47000','SUNGAI BULOH, SELANGOR','',47000,'','','MS ROSHNEE NATHAN','','03 - 6145 7888 (EXT: 7388)','03 - 6145 7998',NULL,'IP','OP','A','0',0.00,25000.00,1001.00,'615100','1001','712130','','','21/01/2020','NORASIKIN','','','','','','','','',0,'0','0000-00-00 00:00:00',17.00,9999999.99,'9999999.99','0000-00-00 00:00:00',NULL,NULL,NULL,NULL,NULL,NULL),(91,'9A','CO','JELAS PURI','JELAS PURI SDN BHD','MALL MANAGEMENT OFFICE, LEVEL 2','PARADIGM MALL,NO.1, JLN SS7/26A','KELANA JAYA, 47301, PETALING JAYA','SELANGOR',47301,'','','LEE PEI YING','HUMAN RESOURCE','03-7801 1000','',NULL,'IP','OP','A','0',0.00,0.00,1001.00,'615100','1001','712130','','','7/04/2017','mimi','','','','','','','','',0,'0','0000-00-00 00:00:00',18.00,9999999.99,'9999999.99','0000-00-00 00:00:00',NULL,NULL,NULL,NULL,NULL,NULL),(92,'9A','CO','KJM','KJM ALUMINIUM CAN SDN BHD','LOT 6, JLN PERUSAHAAN SATU','68100 BATU CAVES','SELANGOR','',68100,'','','PN MAZNAH ZABRI','','03-6189 3699','03-6187 9272',NULL,'IP','OP','A','0',0.00,0.00,1001.00,'615100','1001','712130','','','18/08/2016','mimi','','','UITM PRIVATE HEALTHCARE SDN BHD','1.2038E+13','','','','',0,'0','0000-00-00 00:00:00',16.00,9999999.99,'9999999.99','0000-00-00 00:00:00',NULL,NULL,NULL,NULL,NULL,NULL),(93,'9A','CO','KOWAMAS','KOPERASI WAWASAN MALAYSIA BERHAD (KOWAMAS)','C-1301,13TH FLOOR, BLOCK C','KELANA JAYA BUSINESS CENTRE, JLN SS7/2','KELANA JAYA, 47301 PETALING JAYA','SELANGOR',47301,'','','PUAN NORSUZIANI ISMAIL','SENIOR EXECUTIVE HUM','03-7804 9349 (EXT: 801)','',NULL,'IP','OP','A','1749.1',0.00,0.00,1001.00,'615100','1001','712130','','','1/11/2019','norasikin','','','','','','','','',0,'0','0000-00-00 00:00:00',26.00,9999999.99,'9999999.99','0000-00-00 00:00:00',NULL,NULL,NULL,NULL,NULL,NULL),(94,'9A','CO','KSAMSUDIN','KLINIK DR. SHAMSUDDIN','2399, JALAN 1A/3','BDR BARU SUNGAI BULOH','47000 SUNGAI BULOH','SELANGOR',47000,'','','','','','',NULL,'IP','OP','A','0',0.00,0.00,1001.00,'615100','1001','712130','','','15/01/2020','norasikin','','','','','','','','',0,'0','0000-00-00 00:00:00',9.00,9999999.99,'9999999.99','0000-00-00 00:00:00',NULL,NULL,NULL,NULL,NULL,NULL),(95,'9A','CO','KUB','KUB-BERJAYA ENVIRO SDN BHD','09-03 & 09-05, LEVEL 9, EAST,','BERJAYA TIME SQUARE','NO. 1, JALAN IMBI','55100 KUALA LUMPUR',55100,'','','','','03-2688 6333 / 03-2149 1999','03-2688 6332',NULL,'IP','OP','A','0',0.00,0.00,1001.00,'615100','1001','712130','','','10/08/2018','NURAMIRA','','','','','','','','',0,'0','0000-00-00 00:00:00',25.00,9999999.99,'9999999.99','0000-00-00 00:00:00',NULL,NULL,NULL,NULL,NULL,NULL),(96,'9A','CO','KULDIP','KULDIP & COMPANY','D-10 & 19, 1ST FLOOR, BLOCK D','PLAZA PEKELILING, NO.2,','JALAN TUN RAZAK, 50400','KUALA LUMPUR',50400,'','','','','03 - 4043 5788','03 -4044 7607',NULL,'IP','OP','A','0',0.00,0.00,1001.00,'615100','1001','712130','','','4/02/2020','SHAWAL','','','','','','','','',0,'0','0000-00-00 00:00:00',9.00,9999999.99,'9999999.99','0000-00-00 00:00:00',NULL,NULL,NULL,NULL,NULL,NULL),(97,'9A','CO','KWSP','KUMPULAN WANG SIMPANAN PEKERJA (KWSP)','TKT G,1&2, CORPORATE  IDCC TOWER','SHAH ALAM, JLN PAHAT L 15/L, SEKSYEN 15','40200 SELANGOR','',40200,'','','','','','',NULL,'IP','OP','A','10305.5',0.00,0.00,1001.00,'615100','1001','712130','','','23/08/2019','norasikin','','','','','','','','',0,'0','0000-00-00 00:00:00',30.00,9999999.99,'9999999.99','0000-00-00 00:00:00',NULL,NULL,NULL,NULL,NULL,NULL),(98,'9A','CO','LEONG HUP','LEONG HUP POULTRY FARM SDN BHD','201-203, JALAN ABDULLAH,','84000 MUAR, JOHOR','','',84000,'','','MR ONG THIAN KEA','HR MANAGER','06-9519992','',NULL,'IP','OP','A','0',0.00,0.00,1001.00,'615100','1001','712130','','','10/07/2018','NURAMIRA','','','','','','','','',0,'0','0000-00-00 00:00:00',10.00,9999999.99,'9999999.99','0000-00-00 00:00:00',NULL,NULL,NULL,NULL,NULL,NULL),(99,'9A','CO','LJH','LIEW.JULIA TUN.HARI','ADVOCATES & SOLICITORS','UNIT 2-3-10, MENARA KLH','JALAN KASIPILLAY','51200 KUALA LUMPUR',51200,'','','','','03-2300 4551','03-2300 4552',NULL,'IP','OP','A','0',0.00,0.00,1001.00,'615100','1001','712130','','','9/12/2016','mimi','','','','','','','','',0,'0','0000-00-00 00:00:00',29.00,9999999.99,'9999999.99','0000-00-00 00:00:00',NULL,NULL,NULL,NULL,NULL,NULL),(100,'9A','CO','LLA','LACHAMAN LALCHAND & ASSOCIATES','NO.5-1, JALAN 26/70A','DESA SRI HARTAMAS','50480 KUALA LUMPUR','',50480,'','','','','03-6201 2663','03-6201 2618',NULL,'IP','OP','A','0',0.00,0.00,1001.00,'615100','1001','712130','','','28/04/2017','HUDA','','','','','','','','',0,'0','0000-00-00 00:00:00',29.00,9999999.99,'9999999.99','0000-00-00 00:00:00',NULL,NULL,NULL,NULL,NULL,NULL),(101,'9A','CO','MADP','MESSRS ADEL D\'CRUZ & PARTNERS','A-17-10, PINNACLE PETALING JAYA','LORONG UTARA C, OFF JLN UTARA','46200 PETALING JAYA, SELANGOR','',46200,'','','','','03 - 7611 9469','03 - 7611 9470',NULL,'IP','OP','A','250',0.00,0.00,1001.00,'615100','1001','712130','','','28/08/2019','JANNAH','','','','','','','','',0,'0','0000-00-00 00:00:00',19.00,9999999.99,'9999999.99','0000-00-00 00:00:00',NULL,NULL,NULL,NULL,NULL,NULL),(102,'9A','CO','MAH','MALAYSIAN ASSOCIATION OF HOTELS','C5-3, ISMA MAH, JALAN AMPANG UTAM 1/1','ONE AMPANG AVENUE','68000 AMPANG, SELANGOR','',68000,'','','CIK FADHILAH ARIFFIN (012-913 5434)','ADMIN MANAGER','03-4251 8477, 012-913 5434','',NULL,'IP','OP','A','0',0.00,0.00,1001.00,'615100','1001','712130','','','3/02/2020','NORASIKIN','','','','','','','','',0,'0','0000-00-00 00:00:00',13.00,9999999.99,'9999999.99','0000-00-00 00:00:00',NULL,NULL,NULL,NULL,NULL,NULL),(103,'9A','BM','MAIJ','MAJLIS AGAMA ISLAM WILAYAH PERSEKUTUAN (BAITULMAL)','','','','',0,'','','','','','',NULL,'OP','OP','ACTIV','0',0.00,0.00,0.00,'3000/000','0','3001/207','','','?','','?','','','','','','','',0,'0','0000-00-00 00:00:00',0.00,9999999.99,'9999999.99','0000-00-00 00:00:00',NULL,NULL,NULL,NULL,NULL,NULL),(104,'9A','CO','MAIWP','HARTA SUCI SDN BHD / PUSAT PUNGUTAN ZAKAT','WISMA PPZ, 68-1-6, DATARAN SHAMELIN','JALAN 4/91, TAMAN SHAMELIN PERKASA,','56100 KUALA LUMPUR.','',56100,'','','PN. MUHSINI BTE SIDEK','SENIOR MANAGER HUMAN','03 - 9289 5757','',NULL,'IP','OP','A','134',0.00,0.00,1001.00,'615100','1001','712130','','','1/03/2018','NURAMIRA','','','','','','','','',0,'0','0000-00-00 00:00:00',1.00,9999999.99,'9999999.99','0000-00-00 00:00:00',NULL,NULL,NULL,NULL,NULL,NULL),(105,'9A','CO','MAKNA','MAJLIS KANSER NASIONAL','BG03A & 05, GROUND FLOOR','MEGAN AMBASSY, 225 JLN AMPANG','50450 KUALA LUMPUR','',50450,'','','CIK KAMARULAINI / PN AZLINA','','03-2162 9178 EXT : 110/102','03-2162 9203',NULL,'IP','OP','A','522.5',0.00,0.00,1001.00,'615100','1001','712130','','','2/04/2021','TAJUL','','','','','','','','',0,'0','0000-00-00 00:00:00',19.00,9999999.99,'9999999.99','0000-00-00 00:00:00',NULL,NULL,NULL,NULL,NULL,NULL),(106,'9A','CO','MANULIFE IHP','MANULIFE INS. BHD C/O INTEGRATED HEALTH PLANS','INTEGRATED HEALTH PLANS (M) SDN BHD','UNIT 9-8, LEVEL 9, MENARA LIVINGSTON','170 JALAN ARGYLL, 10050 GEORETOWN','ATTN: CLAIMS DEPARTMENT',0,'','','','','1-3000 88 0100','',NULL,'IP','OP','A','0',0.00,0.00,1001.00,'615100','1001','712130','','','19/12/2019','MIMI','','','','','','','','',0,'0','0000-00-00 00:00:00',19.00,9999999.99,'9999999.99','0000-00-00 00:00:00',NULL,NULL,NULL,NULL,NULL,NULL),(107,'9A','CO','MCNS','MCNS POLYURETHANES MALAYSIA SDN BHD','SUITE E-06-16, PLAZA MONT\' KIARA','NO.2, JALAN KIARA, MONT\' KIARA','50480 KUALA LUMPUR','',50480,'','','','','03-6203 3223','03-6203 1223',NULL,'IP','OP','A','0',0.00,0.00,1001.00,'615100','1001','712130','','','13/06/2016','ANIS','','','UITM PRIVATE HEALTHCARE SDN BHD','1.2038E+13','','','','',0,'0','0000-00-00 00:00:00',8.00,9999999.99,'9999999.99','0000-00-00 00:00:00',NULL,NULL,NULL,NULL,NULL,NULL),(108,'9A','CO','MCO','MED SAVE ASSISTANCE SDN BHD','NO.28B, JALAN 2/16','BANDAR BARU SELAYANG','68100 BATU CAVES, SELANGOR','',68100,'','','','','1-7000 81 8003/ 03-6126 7888','03-2050 2776',NULL,'IP','OP','A','102730.53',0.00,0.00,1001.00,'615100','1001','712130','','','21/05/2020','tajul','','','','','','','','',0,'0','0000-00-00 00:00:00',5.00,9999999.99,'9999999.99','0000-00-00 00:00:00',NULL,NULL,NULL,NULL,NULL,NULL),(109,'9A','CO','MEDAN PRESTASI','MEDAN PRESTASI SDN BHD','NO.19, JALAN PJU 8/5H,','PERDANA BUSINESS CENTRE,','BANDAR DAMANSARA PERDANA,','47820 PETALING JAYA, SELANGOR.',47820,'','','PN SERIAH','HUMAN RESOURCE','03-7726 8866','03-7728 7416',NULL,'IP','OP','A','0',0.00,0.00,1001.00,'615100','1001','712130','','','13/02/2019','NURAMIRA','','','','','','','','',0,'0','0000-00-00 00:00:00',13.00,9999999.99,'9999999.99','0000-00-00 00:00:00',NULL,NULL,NULL,NULL,NULL,NULL),(110,'9A','CO','MEDICLINIC','MEDICLINIC @ ASIA ASSISTANCE NETWORK (M) SDN BHD','LEVEL G, AA ONE, NO.1, BLOCK N','JAYA ONE, 72A, JALAN UNIVERSITI','46200 PETALING JAYA','SELANGOR',46200,'','','MUHAMMAD FAIZ','','03-7628 3665','',NULL,'IP','OP','A','10273.05',0.00,0.00,1001.00,'615100','1001','712130','','','10/02/2020','najihah','','','','','','','','',0,'0','0000-00-00 00:00:00',17.00,9999999.99,'9999999.99','0000-00-00 00:00:00',NULL,NULL,NULL,NULL,NULL,NULL),(111,'9A','CO','MEDIEXPRESS','MEDIEXPRESS (MALAYSIA) SDN BHD','F-G-7, BLOCK F','PARKLANE COMMERCIAL HUB','NO.21, JALAN SS7/26','47301 KELANA JAYA, SELANGOR',47301,'','','','','03-7884 1818','03-7809 9222',NULL,'IP','OP','A','440161.8',0.00,0.00,1001.00,'615100','1001','712130','','','29/01/2020','norasikin','','','','','','','','',0,'0','0000-00-00 00:00:00',9.00,9999999.99,'9999999.99','0000-00-00 00:00:00',NULL,NULL,NULL,NULL,NULL,NULL),(112,'9A','CO','MEDILINK','MEDILINKGLOBAL (M) SDN BHD','SUITE C-16-3, LEVEL 16, TOWER C','WISMA GOSHEN, PLAZA PANTAI, NO.5','PERSIARAN PNATAI BARU, OFF JLN PANTAI','BARU,59200 KUALA LUMPUR',59200,'','','','','03- 2296 3188','03-2026 1196',NULL,'IP','OP','A','626.35',0.00,0.00,1001.00,'615100','1001','712130','','','9/01/2020','MIMI','','','','','','','','',0,'0','0000-00-00 00:00:00',9.00,9999999.99,'9999999.99','0000-00-00 00:00:00',NULL,NULL,NULL,NULL,NULL,NULL),(113,'9A','CO','MEDISCREEN','MEDISCREEN SDN BHD','WISMA MEDISCREEN, NO 71-G,','JALAN PJU 1A/41B, PUSAT DAGANGAN NZX,','ARA JAYA PJU 1A,','47301 PETALING JAYA',47301,'','','','','03-7885 0933','',NULL,'IP','OP','A','20467.9',0.00,0.00,1001.00,'615100','1001','712130','','','2/07/2019','norasikin','','','','','','','','',0,'0','0000-00-00 00:00:00',9.00,9999999.99,'9999999.99','0000-00-00 00:00:00',NULL,NULL,NULL,NULL,NULL,NULL),(114,'9A','CO','MERCATOR','MERCATOR SHIP SOLUTIONS SDN BHD','K-02-05, KUCHAI BUSINESS PARK','NO.2, JALAN 1/127, OFF JALAN KUCHAI LAMA','58200 KUALA LUMPUR','',58200,'','','MS. FATIHAH','HR DEPARTMENT','03-7982 7600','03-7982 7602',NULL,'IP','OP','A','0',0.00,0.00,1001.00,'615100','1001','712130','','','24/01/2018','nuramira','','','','','','','','',0,'0','0000-00-00 00:00:00',12.00,9999999.99,'9999999.99','0000-00-00 00:00:00',NULL,NULL,NULL,NULL,NULL,NULL),(115,'9A','CO','MFSB','MULTIMODAL FREIGHT SDN BHD','NO.40, JALAN PENGACARA U1/48','TEMASYA INDUSTRIAL PARK, SEKSYEN U1','40150 GLENMARIE, SHAH ALAM','(ATTN: HR & ADMIN DEPATRMENT)',40150,'','','PN UNGKU FARIDAH','','03-5561 8100','',NULL,'IP','OP','A','0',0.00,0.00,1001.00,'615100','1001','712130','','','16/07/2018','nuramira','','','','','','','','',0,'0','0000-00-00 00:00:00',15.00,9999999.99,'9999999.99','0000-00-00 00:00:00',NULL,NULL,NULL,NULL,NULL,NULL),(116,'9A','CO','MICARE','MICARE SDN BHD','NO.22, BLOCK A, JALAN ASTAKA U8/84','SEKSYEN U8, BUKIT JELUTONG','40150 SHAH ALAM. SELANGOR','(ATT: CLAIMS DEPARTMENT)',40150,'','','EN FAIQ HAKIM','','03-78397256 / 295','',NULL,'IP','OP','A','112348.65',0.00,0.00,1001.00,'615100','1001','712130','','','29/01/2020','norasikin','','','','','','','','',0,'0','0000-00-00 00:00:00',7.00,9999999.99,'9999999.99','0000-00-00 00:00:00',NULL,NULL,NULL,NULL,NULL,NULL),(117,'9A','CO','MICARE ABM','ALLIANCE BANK (M) BHD C/O MICARE SDN BHD','NO.22, BLOCK A, JALAN ASTAKA U8/84','SEKSYEN U8 BUKIT JELUTONG','40150 SHAH ALAM, SELANGOR','',0,'','','','','','',NULL,'IP','OP','A','161',0.00,0.00,1001.00,'615100','1001','712130','','','1/09/2019','norasikin','','','','','','','','',0,'0','0000-00-00 00:00:00',15.00,9999999.99,'9999999.99','0000-00-00 00:00:00',NULL,NULL,NULL,NULL,NULL,NULL),(118,'9A','CO','MICARE AEON','AEON CREDIT SERVICE (M) BHD C/O MICARE S/B','NO.22, BLOCK A, JALAN ASTAKA U8/84','SEKSYEN U8, BUKIT JELUTONG','40150 SHAH ALAM, SELANGOR','',40150,'','','','','','',NULL,'IP','OP','A','600.4',0.00,0.00,1001.00,'615100','1001','712130','','','20/12/2019','MIMI','','','','','','','','',0,'0','0000-00-00 00:00:00',20.00,9999999.99,'9999999.99','0000-00-00 00:00:00',NULL,NULL,NULL,NULL,NULL,NULL),(119,'9A','CO','MICARE AM','AMMETLIFE INSURANCE BHD C/O MICARE SDN BHD','NO.22, BLOCK A, JALAN ASTAKA U8/84','SEKSYEN U8, BUKIT JELUTONG','40150 SHAH ALAM, SELANGOR','',40150,'','','','','','',NULL,'IP','OP','A','46771.7',0.00,0.00,1001.00,'615100','1001','712130','','','14/02/2020','MIMI','','','','','','','','',0,'0','0000-00-00 00:00:00',18.00,9999999.99,'9999999.99','0000-00-00 00:00:00',NULL,NULL,NULL,NULL,NULL,NULL),(120,'9A','CO','MICARE AMBANK','AMBANK (M) BHD (O/P) C/O MICARE SDN BHD','NO.22, BLOCK A, JALAN ASTAKA U8/84','SEKSYEN U8, BUKIT JELUTONG','40150 SHAH ALAM, SELANGOR','',40150,'','','','','','',NULL,'IP','OP','A','1494',0.00,0.00,1001.00,'615100','1001','712130','','','29/01/2020','norasikin','','','','','','','','',0,'0','0000-00-00 00:00:00',11.00,9999999.99,'9999999.99','0000-00-00 00:00:00',NULL,NULL,NULL,NULL,NULL,NULL),(121,'9A','CO','MICARE AMINVEST','AMINVESTMENT BANK BHD (OUTPATIENT) C/O MICARE S/B','NO.22, BLOCK A, JALAN ASTAKA U8/84','SEKSYEN U8, BUKIT JELUTONG','40150 SHAH ALAM, SELANGOR','',40150,'','','','','','',NULL,'IP','OP','A','630',0.00,0.00,1001.00,'615100','1001','712130','','','29/01/2020','norasikin','','','','','','','','',0,'0','0000-00-00 00:00:00',25.00,9999999.99,'9999999.99','0000-00-00 00:00:00',NULL,NULL,NULL,NULL,NULL,NULL),(122,'9A','CO','MICARE AXA','AXA AFFIN GENERAL INS. BHD C/O MICARE SDN BHD','NO.22, BLOCK A, JALAN ASTAKA U8/84','SEKSYEN U8, BUKIT JELUTONG','40150 SHAH ALAM SELANGOR','',40150,'','','','','','',NULL,'IP','OP','A','8176.53',0.00,0.00,1001.00,'615100','1001','712130','','','29/01/2020','shawal','','','','','','','','',0,'0','0000-00-00 00:00:00',22.00,9999999.99,'9999999.99','0000-00-00 00:00:00',NULL,NULL,NULL,NULL,NULL,NULL),(123,'9A','CO','MICARE BPMB','BANK PEMBANGUNAN (M) BHD C/O MICARE SDN BHD','NO.22, BLOCK A, JALAN ASTAKA U8/84','SEKSYEN U8, BUKIT JELUTONG','40150, SHAH ALAM, SELANGOR','',40150,'','','','','','',NULL,'IP','OP','A','1283.4',0.00,0.00,1001.00,'615100','1001','712130','','','29/04/2020','tajul','','','','','','','','',0,'0','0000-00-00 00:00:00',19.00,9999999.99,'9999999.99','0000-00-00 00:00:00',NULL,NULL,NULL,NULL,NULL,NULL),(124,'9A','CO','MICARE BURSA','BURSA (M) BERHAD C/O MICARE SDN BHD','NO.22, BLOCK A, JALAN ASTAKA U8/84','SEKSYEN U8, BUKIT JELUTONG','40150 SHAH ALAM, SELANGOR','',40150,'','','','','','',NULL,'IP','OP','A','10701.6',0.00,0.00,1001.00,'615100','1001','712130','','','14/02/2020','MIMI','','','','','','','','',0,'0','0000-00-00 00:00:00',26.00,9999999.99,'9999999.99','0000-00-00 00:00:00',NULL,NULL,NULL,NULL,NULL,NULL),(125,'9A','CO','MICARE BUS','RAPID BUS S/B (ASO) C/O MICARE SDN BHD','NO.22, BLOCK A, JALAN ASTAKA U8/84','SEKSYEN U8, BUKIT JELUTONG','40150, SHAH ALAM, SELANGOR','',40150,'','','','','','',NULL,'IP','OP','A','2527.8',0.00,0.00,1001.00,'615100','1001','712130','','','23/12/2019','norasikin','','','','','','','','',0,'0','0000-00-00 00:00:00',16.00,9999999.99,'9999999.99','0000-00-00 00:00:00',NULL,NULL,NULL,NULL,NULL,NULL),(126,'9A','CO','MICARE DAIKIN','DAIKIN (M) SALES & SERVICES S/B C/O MICARE S/B','NO.22, BLOCK A, JALAN ASTAKA U8/84','SEKSYEN U8, BUKIT JELUTONG','40150 SHAH ALAM SELANGOR','',40150,'','','','','','',NULL,'IP','OP','A','1554',0.00,0.00,1001.00,'615100','1001','712130','','','23/12/2019','norasikin','','','','','','','','',0,'0','0000-00-00 00:00:00',19.00,9999999.99,'9999999.99','0000-00-00 00:00:00',NULL,NULL,NULL,NULL,NULL,NULL),(127,'9A','CO','MICARE DAIKIN ASO','DAIKIN (M) SDN BHD (ASO) C/O MICARE SDN BHD','NO.22, BLOCK A, JALAN ASTAKA U8/84','SEKSYEN U8, BUKIT JELUTONG','40150 SHAH ALAM, SELANGOR','',40150,'','','','','','',NULL,'IP','OP','A','35746.05',0.00,0.00,1001.00,'615100','1001','712130','','','29/01/2020','norasikin','','','','','','','','',0,'0','0000-00-00 00:00:00',15.00,9999999.99,'9999999.99','0000-00-00 00:00:00',NULL,NULL,NULL,NULL,NULL,NULL),(128,'9A','CO','MICARE DIGITAL','SAPURA DIGITAL SOLUTIONS SDN BHD','C/O MICARE SDN BHD','NO.22, BLOCK A, JALAN ASTAKA U8/84','SEKSYEN U8, BUKIT JELUTONG','40150 SHAH ALAM, SELANGOR',40150,'','','','','','',NULL,'IP','OP','A','160',0.00,0.00,1001.00,'615100','1001','712130','','','3/12/2019','MIMI','','','','','','','','',0,'0','0000-00-00 00:00:00',26.00,9999999.99,'9999999.99','0000-00-00 00:00:00',NULL,NULL,NULL,NULL,NULL,NULL),(129,'9A','CO','MICARE EDGENTA','EDGENTA PROPEL BERHAD (ASO) C/O MICARE SDN BHD','NO.22, BLOCK A, JLN ASTAKA U8/84','SEKSYEN U8, BUKIT JELUTONG','40150 SHAH ALAM, SELANGOR','',40150,'','','','','','',NULL,'IP','OP','A','512.75',0.00,0.00,1001.00,'615100','1001','712130','','','7/01/2020','MIMI','','','','','','','','',0,'0','0000-00-00 00:00:00',7.00,9999999.99,'9999999.99','0000-00-00 00:00:00',NULL,NULL,NULL,NULL,NULL,NULL),(130,'9A','CO','MICARE ENERGY','SAPURA ENERGY BERHAD C/O MICARE SDN BHD','NO.22, BLOCK A, JALAN ASTAKA U8/84','SEKSYEN U8, BUKIT JELUTONG','40150 SHAH ALAM, SELANGOR','',40150,'','','','','','',NULL,'IP','OP','A','1071',0.00,0.00,1001.00,'615100','1001','712130','','','23/12/2019','norasikin','','','','','','','','',0,'0','0000-00-00 00:00:00',17.00,9999999.99,'9999999.99','0000-00-00 00:00:00',NULL,NULL,NULL,NULL,NULL,NULL),(131,'9A','CO','MICARE ETIQA','ETIQA INSURANCE C/O MICARE SDN BHD','NO.22, BLOCK A, JALAN ASTAKA U8/84','SEKSYEN U8, BUKIT JELUTONG','40150 SHAH ALAM, SELANGOR','',40150,'','','','','','',NULL,'IP','OP','A','10304.4',0.00,0.00,1001.00,'615100','1001','712130','','','30/01/2020','JANNAH','','','','','','','','',0,'0','0000-00-00 00:00:00',20.00,9999999.99,'9999999.99','0000-00-00 00:00:00',NULL,NULL,NULL,NULL,NULL,NULL),(132,'9A','CO','MICARE HLA','MICARE SDN BHD C/O HONG LEONG ASSURANCE BERHAD','NO.22, BLOCK A, JALAN ASTAKA U8/84,','SEKSYEN U8, BUKIT JELUTONG,','40150 SHAH ALAM, SELANGOR.','(CLAIMS DEPARTMENT)',40150,'','','EN. FAIQ HAKIM','','03-7843 9459','03-7847 4304',NULL,'IP','OP','A','70443.8',0.00,0.00,1001.00,'615100','1001','712130','','','12/02/2020','MIMI','','','','','','','','',0,'0','0000-00-00 00:00:00',25.00,9999999.99,'9999999.99','0000-00-00 00:00:00',NULL,NULL,NULL,NULL,NULL,NULL),(133,'9A','CO','MICARE KELUARGA','SYKT TAKAFUL (M) KELUARGA BHD C/O MICARE S/B','NO.22, BLOCK A, JALAN ASTAKA U8/84','SEKSYEN U8, BUKIT JELUTONG','40150 SHAH ALAM, SELANGOR','',40150,'','','','','','',NULL,'IP','OP','A','31279.85',0.00,0.00,1001.00,'615100','1001','712130','','','6/02/2020','MIMI','','','','','','','','',0,'0','0000-00-00 00:00:00',6.00,9999999.99,'9999999.99','0000-00-00 00:00:00',NULL,NULL,NULL,NULL,NULL,NULL),(134,'9A','CO','MICARE KENANGA','KENANGA INV. BANK BERHAD (O/P) C/O MICARE S/B','NO.22, BLOCK A, JALAN ASTAKA U8/84','SEKSYEN U8, BUKIT JELUTONG','40150 SHAH ALAM, SELANGOR','',40150,'','','','','','',NULL,'IP','OP','A','2346.5',0.00,0.00,1001.00,'615100','1001','712130','','','22/11/2019','norasikin','','','','','','','','',0,'0','0000-00-00 00:00:00',29.00,9999999.99,'9999999.99','0000-00-00 00:00:00',NULL,NULL,NULL,NULL,NULL,NULL),(135,'9A','CO','MICARE KPMG','KPMG MGMT & RISK CONSULTING SDN BHD','NO.22, BLOCK A, JALAN ASTAKA U8/84','SEKSYEN U8, BUKIT JELUTONG','40150 SHAH ALAM, SELANGOR','',40150,'','','','','','',NULL,'IP','OP','A','1495',0.00,0.00,1001.00,'615100','1001','712130','','','14/02/2020','SHAWAL','','','','','','','','',0,'0','0000-00-00 00:00:00',31.00,9999999.99,'9999999.99','0000-00-00 00:00:00',NULL,NULL,NULL,NULL,NULL,NULL),(136,'9A','CO','MICARE KUARI','KUARI PATI SDN BHD (ASO) C/O MICARE SDN BHD','NO.22, BLOCK A, JALAN ASTAKA U8/84','SEKSYEN U8, JALAN JELUTONG','40150 SHAH ALAM, SELANGOR','',40150,'','','','','','',NULL,'IP','OP','A','1349',0.00,0.00,1001.00,'615100','1001','712130','','','23/12/2019','norasikin','','','','','','','','',0,'0','0000-00-00 00:00:00',9.00,9999999.99,'9999999.99','0000-00-00 00:00:00',NULL,NULL,NULL,NULL,NULL,NULL),(137,'9A','CO','MICARE LPT','LEBUHRAYA PANTAI TIMUR 2 S/B (ASO) C/O MICARE S/B','NO.22, BLOCK A, JALAN ASTAKA U8/84','SEKSYEN U8, BUKIT JELUTONG','40150 SHAH ALAM, SELANGOR','',40150,'','','','','','',NULL,'IP','OP','A','0',0.00,0.00,1001.00,'615100','1001','712130','','','29/01/2020','norasikin','','','','','','','','',0,'0','0000-00-00 00:00:00',26.00,9999999.99,'9999999.99','0000-00-00 00:00:00',NULL,NULL,NULL,NULL,NULL,NULL),(138,'9A','CO','MICARE MCIS','MCIS INSURANCE BERHAD C/O MICARE SDN BHD','NO.22, BLOCK A, JALAN ASTAKA U8/84,','SEKSYEN U8, BUKIT JELUTONG,','40150 SHAH ALAM,SELANGOR.','',40150,'','','','','03-7843 9459','03-7847 4304',NULL,'IP','OP','A','49798.4',0.00,0.00,1001.00,'615100','1001','712130','','','8/01/2020','MIMI','','','','','','','','',0,'0','0000-00-00 00:00:00',29.00,9999999.99,'9999999.99','0000-00-00 00:00:00',NULL,NULL,NULL,NULL,NULL,NULL),(139,'9A','CO','MICARE MCMC','SURUHANJAYA KOMUNIKASI & MULTIMEDIA M\'SIA (MCMC)','C/O MICARE SDN BHD','NO.22, BLOCK A, JALAN ASTAKA U8/84','SEKSYEN U8, BUKIT JELUTONG','40150 SHAH ALAM, SELANGOR',40150,'','','','','','',NULL,'IP','OP','A','363.5',0.00,0.00,1001.00,'615100','1001','712130','','','23/12/2019','norasikin','','','','','','','','',0,'0','0000-00-00 00:00:00',20.00,9999999.99,'9999999.99','0000-00-00 00:00:00',NULL,NULL,NULL,NULL,NULL,NULL),(140,'9A','CO','MICARE MESISERVE','EDGENTA MEDISERVE S/B (ASO) C/O MICARE S/B','NO.22, BLOCK A, JALAN ASTAKA U8/84','SEKSYEN U8, BUKIT JELUTONG','40150 SHAH ALAM, SELANGOR','',40150,'','','','','','',NULL,'IP','OP','A','200',0.00,0.00,1001.00,'615100','1001','712130','','','6/02/2020','MIMI','','','','','','','','',0,'0','0000-00-00 00:00:00',6.00,9999999.99,'9999999.99','0000-00-00 00:00:00',NULL,NULL,NULL,NULL,NULL,NULL),(141,'9A','CO','MICARE MIMOS','MIMOS BERHAD (ASO) C/O MICARE SDN BHD','NO.22, BLOCK A, JALAN ASTAKA U8/84','SEKSYEN U8, BUKIT JELUTONG','40150 SHAH ALAM, SELANGOR','',40150,'','','','','','',NULL,'IP','OP','A','692',0.00,0.00,1001.00,'615100','1001','712130','','','21/10/2019','norasikin','','','','','','','','',0,'0','0000-00-00 00:00:00',15.00,9999999.99,'9999999.99','0000-00-00 00:00:00',NULL,NULL,NULL,NULL,NULL,NULL),(142,'9A','CO','MICARE MITSUBISHI','MITSUBISHI MOTORS (M) O/PATIENT C/O MICARE S/B','NO.22, BLOCK A, JALAN ASTAKA U8/84','SEKSYEN U8, BUKIT JELUTONG','40150 SHAH ALAM, SELANGOR','',0,'','','','','','',NULL,'IP','OP','A','2367.7',0.00,0.00,1001.00,'615100','1001','712130','','','26/09/2019','norasikin','','','','','','','','',0,'0','0000-00-00 00:00:00',20.00,9999999.99,'9999999.99','0000-00-00 00:00:00',NULL,NULL,NULL,NULL,NULL,NULL),(143,'9A','CO','MICARE MIYAZU','MIYAZU (M) SDN BHD (MMSB) - C/O MICARE S/B','NO.22, BLOCK A, JALAN ASTAKA U8/84','SEKSYEN U8, BUKIT JELUTONG','40150 SHAH ALAM, SELANGOR','',40150,'','','','','','',NULL,'IP','OP','A','3832.35',0.00,0.00,1001.00,'615100','1001','712130','','','23/12/2019','norasikin','','','','','','','','',0,'0','0000-00-00 00:00:00',18.00,9999999.99,'9999999.99','0000-00-00 00:00:00',NULL,NULL,NULL,NULL,NULL,NULL),(144,'9A','CO','MICARE MSIG','MSIG C/O MICARE SDN BHD','NO.22, BLOCK A, JALAN ASTAKA U8/84','SEKSYEN U8, BUKIT JELUTONG','40150 SHAH ALAM, SELANGOR','',40150,'','','','','','',NULL,'IP','OP','A','1189.5',0.00,0.00,1001.00,'615100','1001','712130','','','20/12/2019','norasyikin','','','','','','','','',0,'0','0000-00-00 00:00:00',24.00,9999999.99,'9999999.99','0000-00-00 00:00:00',NULL,NULL,NULL,NULL,NULL,NULL),(145,'9A','CO','MICARE NAZA','NAZA AUTO SDN BHD C/O MICARE SDN BHD','NO.22, BLOCK A, JALAN ASTAKA U8/84','SEKSYEN U8, BUKIT JELUTONG','40150 SHAH ALAM, SELANGOR','',40150,'','','','','','',NULL,'IP','OP','A','0',0.00,0.00,1001.00,'615100','1001','712130','','','17/01/2020','MIMI','','','','','','','','',0,'0','0000-00-00 00:00:00',17.00,9999999.99,'9999999.99','0000-00-00 00:00:00',NULL,NULL,NULL,NULL,NULL,NULL),(146,'9A','CO','MICARE OPUS','OPUS MGMT S/B (ASO) C/O MICARE SDN BHD','NO.22, BLOCK A, JALAN ASTAKA U8/84','SEKSYEN U8, BUKIT JELUTONG','40150 SHAH ALAM, SELANGOR','',40150,'','','','','','',NULL,'IP','OP','A','0',0.00,0.00,1001.00,'615100','1001','712130','','','29/08/2019','norasikin','','','','','','','','',0,'0','0000-00-00 00:00:00',26.00,9999999.99,'9999999.99','0000-00-00 00:00:00',NULL,NULL,NULL,NULL,NULL,NULL),(147,'9A','CO','MICARE PE','PROTON EDAR -SELF INSURED C/O MICARE SDN BHD','NO.22, BLOCK A, JALAN ASTAKA U8/84','SEKSYEN U8, BUKIT JELUTONG','40150 SHAH ALAM, SELANGOR','',40150,'','','','','','',NULL,'IP','OP','A','260',0.00,0.00,1001.00,'615100','1001','712130','','','29/01/2020','norasikin','','','','','','','','',0,'0','0000-00-00 00:00:00',11.00,9999999.99,'9999999.99','0000-00-00 00:00:00',NULL,NULL,NULL,NULL,NULL,NULL),(148,'9A','CO','MICARE PERMIER','PREMIER ENT. CORP (ASO-UZM4) C/O MICARE S/B','NO.22, BLOCK A, JALAN ASTAKA U8/84','SEKSYEN U8, BUKIT JELUTONG','40150 SHAH ALAM, SELANGOR','',40150,'','','','','','',NULL,'IP','OP','A','0',0.00,0.00,1001.00,'615100','1001','712130','','','5/08/2019','norasikin','','','','','','','','',0,'0','0000-00-00 00:00:00',23.00,9999999.99,'9999999.99','0000-00-00 00:00:00',NULL,NULL,NULL,NULL,NULL,NULL),(149,'9A','CO','MICARE PKNS','PKNS C/O MICARE SDN BHD','NO.22, BLOCK A, JALAN ASTAKA U8/84','SEKSYEN U8, BUKIT JELUTONG','40150 SHAH ALAM, SELANGOR','',40150,'','','','','','',NULL,'IP','OP','A','0',0.00,0.00,1001.00,'615100','1001','712130','','','21/10/2019','norasikin','','','','','','','','',0,'0','0000-00-00 00:00:00',28.00,9999999.99,'9999999.99','0000-00-00 00:00:00',NULL,NULL,NULL,NULL,NULL,NULL),(150,'9A','CO','MICARE PLUS','PLUS (ASO) C/O MICARE SDN BHD','NO.22, BLOCK A, JALAN ASTAKA U8/84','SEKSYEN U8, BUKIT JELUTONG','40150 SHAH ALAM, SELANGOR','',40150,'','','','','','',NULL,'IP','OP','A','4541.9',0.00,0.00,1001.00,'615100','1001','712130','','','23/12/2019','norasikin','','','','','','','','',0,'0','0000-00-00 00:00:00',22.00,9999999.99,'9999999.99','0000-00-00 00:00:00',NULL,NULL,NULL,NULL,NULL,NULL),(151,'9A','CO','MICARE PMB','PRASARANA (M) BHD (ASO) C/O MICARE SDN BHD','NO.22, BLOCK A, JALAN ASTAKA U8/84','SELSYEN U8, BUKIT JELUTONG','40150 SHAH ALAM, SELANGOR','',40150,'','','','','','',NULL,'IP','OP','A','529.1',0.00,0.00,1001.00,'615100','1001','712130','','','21/10/2019','norasikin','','','','','','','','',0,'0','0000-00-00 00:00:00',2.00,9999999.99,'9999999.99','0000-00-00 00:00:00',NULL,NULL,NULL,NULL,NULL,NULL),(152,'9A','CO','MICARE PROGRESS','PROGRESSIVE INSURANCE BHD C/O MICARE SDN BHD','NO.22, BLOCK A, JALAN ASTAKA U8/84','SEKSYEN U8, BUKIT JELUTONG','40150 SHAH ALAM, SELANGOR','',40150,'','','','','','',NULL,'IP','OP','A','1523.1',0.00,0.00,1001.00,'615100','1001','712130','','','28/11/2019','MIMI','','','','','','','','',0,'0','0000-00-00 00:00:00',28.00,9999999.99,'9999999.99','0000-00-00 00:00:00',NULL,NULL,NULL,NULL,NULL,NULL),(153,'9A','CO','MICARE PROTON','PROTON - SELF INSURED C/O MICARE SDN BHD','NO.22, BLOCK A, JALAN ASTAKA U8/84','SEKSYEN U8, BUKIT JELUTONG','40150 SHAH ALAM, SELANGOR','',40150,'','','','','','',NULL,'IP','OP','A','1246.5',0.00,0.00,1001.00,'615100','1001','712130','','','29/01/2020','norasikin','','','','','','','','',0,'0','0000-00-00 00:00:00',25.00,9999999.99,'9999999.99','0000-00-00 00:00:00',NULL,NULL,NULL,NULL,NULL,NULL),(154,'9A','CO','MICARE PTM','PROTON TANJUNG MALIM - SELF INSURED C/O MICARE','NO.22, BLOCK A, JALAN ASTAKA U8/84','SEKSYEN U8, BUKIT JELUTONG','40150 SHAH ALAM, SELANGOR','',0,'','','','','','',NULL,'IP','OP','A','979',0.00,0.00,1001.00,'615100','1001','712130','','','22/11/2019','norasikin','','','','','','','','',0,'0','0000-00-00 00:00:00',12.00,9999999.99,'9999999.99','0000-00-00 00:00:00',NULL,NULL,NULL,NULL,NULL,NULL),(155,'9A','CO','MICARE RAPID','RAPID RAIL S/B (ASO) C/O MICARE SDN BHD','NO.22, BLOCK A, JALAN ASTAKA U8/84','SEKSYEN U8, BUKIT JELUTONG','40150 SHAH ALAM , SELANGOR','',0,'','','','','','',NULL,'IP','OP','A','3160.25',0.00,0.00,1001.00,'615100','1001','712130','','','23/12/2019','norasikin','','','','','','','','',0,'0','0000-00-00 00:00:00',20.00,9999999.99,'9999999.99','0000-00-00 00:00:00',NULL,NULL,NULL,NULL,NULL,NULL),(156,'9A','CO','MICARE RENTOKIL','RENTOKIL INITIAL (M) SDN BHD C/O MICARE SDN BHD','NO.22, BLOCK A, JALAN ASTAKA U8/84','SEKSYEN U8, BUKIT JELUTONG','40150 SHAH ALAM, SELANGOR','',40150,'','','','','','',NULL,'IP','OP','A','1759.5',0.00,0.00,1001.00,'615100','1001','712130','','','22/11/2019','norasikin','','','','','','','','',0,'0','0000-00-00 00:00:00',18.00,9999999.99,'9999999.99','0000-00-00 00:00:00',NULL,NULL,NULL,NULL,NULL,NULL),(157,'9A','CO','MICARE RHB','RHB INSURANCE BHD C/O MICARE SDN BHD','NO.22, BLOCK A, JALAN ASTAKA U8/84','SEKSYEN U8, BUKIT JELUTONG','40150 SHAH ALAM, SELANGOR','',40150,'','','','','','',NULL,'IP','OP','A','1724.05',0.00,0.00,1001.00,'615100','1001','712130','','','26/09/2019','norasikin','','','','','','','','',0,'0','0000-00-00 00:00:00',7.00,9999999.99,'9999999.99','0000-00-00 00:00:00',NULL,NULL,NULL,NULL,NULL,NULL),(158,'9A','CO','MICARE SAPURA','SAPURAOMV UPSTREAM (SARAWAK) INC. C/O MICARE S/B','NO.22, BLOCK A, JALAN ASTAKA U8/84','SEKSYEN U8, BUKIT JELUTONG','40150, SHAH ALAM, SELANGOR','',40150,'','','','','','',NULL,'IP','OP','A','180',0.00,0.00,1001.00,'615100','1001','712130','','','23/12/2019','norasikin','','','','','','','','',0,'0','0000-00-00 00:00:00',14.00,9999999.99,'9999999.99','0000-00-00 00:00:00',NULL,NULL,NULL,NULL,NULL,NULL),(159,'9A','CO','MICARE SUN','SUN VICTORY SDN BHD (ASO) C/O MICARE SDN BHD','NO.22, BLOCK A, JALAN ASTAKA U8/84','SEKSYEN U8, BUKIT JELUTONG','40150 SHAH ALAM, SELANGOR','',40150,'','','','','','',NULL,'IP','OP','A','1009.2',0.00,0.00,1001.00,'615100','1001','712130','','','27/11/2019','MIMI','','','','','','','','',0,'0','0000-00-00 00:00:00',27.00,9999999.99,'9999999.99','0000-00-00 00:00:00',NULL,NULL,NULL,NULL,NULL,NULL),(160,'9A','CO','MICARE SYMPHONY','SYMPHONY HILLS SDN BHD (ASO) C/O MICARE SDN BHD','NO.22, BLOCK A, JALAN ASTAKA U8/84','SEKSYEN U8, BUKIT JELUTONG','40150 SHAH ALAM, SELANGOR','',40150,'','','','','','',NULL,'IP','OP','A','0',0.00,0.00,1001.00,'615100','1001','712130','','','5/08/2019','norasikin','','','','','','','','',0,'0','0000-00-00 00:00:00',22.00,9999999.99,'9999999.99','0000-00-00 00:00:00',NULL,NULL,NULL,NULL,NULL,NULL),(161,'9A','CO','MICARE T&G','TOUCH \'N GO SDN BHD C/O MICARE SDN BHD','NO.22, BLOCK A, JALAN ASTAKA U8/84','SEKSYEN U8, BUKIT JELUTONG','40150 SHAH ALAM, SELANGOR','',40150,'','','','','','',NULL,'IP','OP','A','8022.75',0.00,0.00,1001.00,'615100','1001','712130','','','21/10/2019','norasikin','','','','','','','','',0,'0','0000-00-00 00:00:00',28.00,9999999.99,'9999999.99','0000-00-00 00:00:00',NULL,NULL,NULL,NULL,NULL,NULL),(162,'9A','CO','MICARE TAKAFUL','SYARIKAT TAKAFUL(M) BHD C/O MICARE SDN BHD','NO.22, BLOCL A, JALAN ASTAKA U8/84','SEKSYEN U8, BUKIT JELUTONG','40150 SHAH ALAM, SELANGOR','',0,'','','','','','',NULL,'IP','OP','A','21215.1',0.00,0.00,1001.00,'615100','1001','712130','','','29/01/2020','norasikin','','','','','','','','',0,'0','0000-00-00 00:00:00',18.00,9999999.99,'9999999.99','0000-00-00 00:00:00',NULL,NULL,NULL,NULL,NULL,NULL),(163,'9A','CO','MICARE TAMCO','TAMCO SWITCHGEAR (M) S/B / C/O MICARE S/B','NO.22, BLOCK A, JALAN ASTAKA U8/84','SEKSYEN U8, BUKIT JELUTONG','40150 SHAH ALAM, SELANGOR','',40150,'','','','','','',NULL,'IP','OP','A','1890.4',0.00,0.00,1001.00,'615100','1001','712130','','','23/12/2019','norasikin','','','','','','','','',0,'0','0000-00-00 00:00:00',4.00,9999999.99,'9999999.99','0000-00-00 00:00:00',NULL,NULL,NULL,NULL,NULL,NULL),(164,'9A','CO','MICARE TM','TOKIO MARINE LIFE INS C/O MICARE SDN BHD','NO.22, BLOCK A, JALAN ASTAKA U8/84','SEKSYEN U8, BUKIT JELUTONG','40150 SHAH ALAM, SELANGOR','',40150,'','','','','','',NULL,'IP','OP','A','27037.65',0.00,0.00,1001.00,'615100','1001','712130','','','1/09/2019','norasikin','','','','','','','','',0,'0','0000-00-00 00:00:00',11.00,9999999.99,'9999999.99','0000-00-00 00:00:00',NULL,NULL,NULL,NULL,NULL,NULL),(165,'9A','CO','MICARE UNIPATI','UNIPATI CONCRETE SDN BHD (ASO) C.O MICARE S/B','NO.22, BLOCK A, JALAN ASTAKA U8/84','SEKSYEN U8, BUKIT JELUTONG','40150 SHAH ALAM, SELANGOR','',40150,'','','','','','',NULL,'IP','OP','A','140.5',0.00,0.00,1001.00,'615100','1001','712130','','','22/11/2019','norasikin','','','','','','','','',0,'0','0000-00-00 00:00:00',21.00,9999999.99,'9999999.99','0000-00-00 00:00:00',NULL,NULL,NULL,NULL,NULL,NULL),(166,'9A','CO','MICARE ZUELLIG','ZUELLIG PHARMA SDN BHD (OUTPATIENT) C/O MICARE','NO.22, BLOCK A, JALAN ASTAKA U8/84','SEKSYEN U8, BUKIT JELUTONG','40150 SHAH ALAM, SELANGOR','',40150,'','','','','','',NULL,'IP','OP','A','3920',0.00,0.00,1001.00,'615100','1001','712130','','','23/12/2019','norasikin','','','','','','','','',0,'0','0000-00-00 00:00:00',23.00,9999999.99,'9999999.99','0000-00-00 00:00:00',NULL,NULL,NULL,NULL,NULL,NULL),(167,'9A','CO','MICARE ZURICH','ZURICH GEN. INS M\'SIA BHD C/O MICARE S/B','NO.22, BLOCK A, JALAN ASTAKA U8/84','SEKSYEN U8, BUKIT JELUTONG','40150 SHAH ALAM, SELANGOR','',0,'','','','','','',NULL,'IP','OP','A','0',0.00,0.00,1001.00,'615100','1001','712130','','','5/08/2019','norasikin','','','','','','','','',0,'0','0000-00-00 00:00:00',21.00,9999999.99,'9999999.99','0000-00-00 00:00:00',NULL,NULL,NULL,NULL,NULL,NULL),(168,'9A','CO','MICARE-MAB','MICARE SDN BHD C/O MALAYSIA AIRLINES BERHAD','NO.22, BLOCK A, JALAN ASTAKA U8/84,','SEKSYEN U8, BUKIT JELUTONG,','40150 SHAH ALAM, SELANGOR.','',40150,'','','','','03-7843 9459','03-7847 4304',NULL,'IP','OP','A','1268.5',0.00,0.00,1001.00,'615100','1001','712130','','','26/12/2019','NORASIKIN','','','','','','','','',0,'0','0000-00-00 00:00:00',29.00,9999999.99,'9999999.99','0000-00-00 00:00:00',NULL,NULL,NULL,NULL,NULL,NULL),(169,'9A','CO','MK LAND','MK LAND HOLDINGS BHD','NO 19, JALAN PJU 8/5H,','PERDANA BUSINESS CENTRE,','BDR DAMANSARA PERDANA,','47820 PETALING JAYA,SELANGOR.',47820,'','','PN SERIAH BT KARJAN','HR MANAGER','03-2730 8500','',NULL,'IP','OP','A','0',0.00,0.00,1001.00,'615100','1001','712130','','','10/07/2018','NURAMIRA','','','','','','','','',0,'0','0000-00-00 00:00:00',10.00,9999999.99,'9999999.99','0000-00-00 00:00:00',NULL,NULL,NULL,NULL,NULL,NULL),(170,'9A','CO','MMKN','UNIT MAJLIS MESYUARAT KERAJAAN N.SELANGOR','TINGKAT 1, BANGUNAN ANNEX','DEWAN NEGERI SELANGOR','40680 SHAH ALAM, SELANGOR','',40680,'','','PN NURUL ISZYANA (P\'TADBIRAN) - 55447618','PN NAZRA (KEWANGAN) ','03-5544 7618 / 03-5544 7617','',NULL,'IP','OP','A','0',0.00,0.00,1001.00,'615100','1001','712130','','','2/07/2019','NORASIKIN','','','','','','','','',0,'0','0000-00-00 00:00:00',12.00,9999999.99,'9999999.99','0000-00-00 00:00:00',NULL,NULL,NULL,NULL,NULL,NULL),(171,'9A','CO','MPI','MPI GENERALI INSURANS BERHAD','8TH FLOOR, MENARA MULTI- PURPOSE','CAPITAL SQUARE,8','JALAN MUNSHI ABDULLAH','50100 KUALA LUMPUR',50100,'','','','','03-2034 9888','03-2694 5758',NULL,'IP','OP','A','0',0.00,0.00,1001.00,'615100','1001','712130','','','17/02/2020','norasikin','','','','','','','','',0,'0','0000-00-00 00:00:00',24.00,9999999.99,'9999999.99','0000-00-00 00:00:00',NULL,NULL,NULL,NULL,NULL,NULL),(172,'9A','CO','MPOB','LEMBAGA MINYAK SAWIT MALAYSIA','U/P KETUA UNIT SUMBER MANUSIA,','LEMBAGA MINYAK SAWIT MALAYSIA,','NO.6, PERSIARAN INSTITUSI,','BANDAR BARU BANGI, 43000 KAJANG SELANGOR',43000,'','','PN HAZIRAH / PN IDAYU','','03-8769 4695 / 4250','03-8925 9446',NULL,'IP','OP','A','0',0.00,0.00,1001.00,'615100','1001','712130','','','31/12/2018','nuramira','','','','','','','','',0,'0','0000-00-00 00:00:00',5.00,9999999.99,'9999999.99','0000-00-00 00:00:00',NULL,NULL,NULL,NULL,NULL,NULL),(173,'9A','CO','MRPI','MRPI PIPES SDN BHD','LOT 5, JALAN PERUSAHAAN 2','KWSN PERINDUSTRIAN BUKIT RAJA','41050 KLANG, SELANGOR','',41050,'','','PN FLORAWATI BT ICHSAN','','03-33430407','03-3343 0408 / 0400',NULL,'IP','OP','A','0',0.00,0.00,1001.00,'615100','1001','712130','','','11/09/2019','JANNAH','','','','','','','','',0,'0','0000-00-00 00:00:00',3.00,9999999.99,'9999999.99','0000-00-00 00:00:00',NULL,NULL,NULL,NULL,NULL,NULL),(174,'9A','CO','MSG','MALAYSIAN SHEET GLASS SDN BHD','KM 21, SUNGAI BULOH,','47000 SUNGAI BULOH,','SELANGOR DARUL EHSAN.','',47000,'','','EN. NAZRI BIN OMAR','MANAGER, HUMAN RESOU','03-6156 5011','',NULL,'IP','OP','A','8360.9',0.00,0.00,1001.00,'615100','1001','712130','','','12/02/2020','norasikin','','','','','','','','',0,'0','0000-00-00 00:00:00',15.00,9999999.99,'9999999.99','0000-00-00 00:00:00',NULL,NULL,NULL,NULL,NULL,NULL),(175,'9A','CO','MSN','MAJLIS SUKAN NEGARA','','','','',0,'','','','','','',NULL,'IP','OP','A','0',0.00,0.00,1001.00,'615100','1001','712130','','','29/08/2017','HUDA','','','','','','','','',0,'0','0000-00-00 00:00:00',29.00,9999999.99,'9999999.99','0000-00-00 00:00:00',NULL,NULL,NULL,NULL,NULL,NULL),(176,'9A','CO','MSU','MSU HOLDINGS SDN BHD','UNIVERSITY DRIVE, OFF PERSIARAN','OLAHRAGA, SEKSYEN 13','40100 SHAH ALAM','SELANGOR',40100,'','','','','03-5526 2888','03-5523 5932 (BILLING)',NULL,'IP','OP','A','0',0.00,0.00,1001.00,'615100','1001','712130','','','8/01/2020','norasikin','','','','','','','','',0,'0','0000-00-00 00:00:00',18.00,9999999.99,'9999999.99','0000-00-00 00:00:00',NULL,NULL,NULL,NULL,NULL,NULL),(177,'9A','CO','MTHANAJAYAN','MTHANAJAYAN CO','2-6-1, 6TH FLOOR, MENARA KLH','BUSINESS CENTRE, NO.2','JLN KASIPILLAY, 51200 KUALA LUMPUR','',51200,'','','','','03-2381 2490','',NULL,'IP','OP','A','0',0.00,0.00,1001.00,'615100','1001','712130','','','18/11/2019','JANNAH','','','','','','','','',0,'0','0000-00-00 00:00:00',30.00,9999999.99,'9999999.99','0000-00-00 00:00:00',NULL,NULL,NULL,NULL,NULL,NULL),(178,'9A','CO','MUFG','MUFG BANK (MALAYSIA) BERHAD','LEVEL 9 & 10, MENARA IMC','8, JALAN SULTAN ISMAIL','50250, KUALA LUMPUR','ATTN: HR DEPARTMENT',50250,'','','HUMAN RESOURCES DEPARTMENT','','03-2034 8000 / 8008','',NULL,'IP','OP','A','125',0.00,0.00,1001.00,'615100','1001','712130','','','3/02/2020','NORASIKIN','','','','','','','','',0,'0','0000-00-00 00:00:00',5.00,9999999.99,'9999999.99','0000-00-00 00:00:00',NULL,NULL,NULL,NULL,NULL,NULL),(179,'9A','CO','MUTIARA','MUTIARA KAYAMAS SDN BHD','','','','',0,'','','','','','',NULL,'IP','OP','A','0',0.00,0.00,1001.00,'615100','1001','712130','','','20/06/2017','ANIS','','','','','','','','',0,'0','0000-00-00 00:00:00',20.00,9999999.99,'9999999.99','0000-00-00 00:00:00',NULL,NULL,NULL,NULL,NULL,NULL),(180,'9A','CO','MYREN','MYREN NETWORK SDN BHD','LEVEL 4, BLOCK1, INTEKMA RESORT &','CONVENTION CENTRE, PERSIARAN RAJA MUDA','SECTION 7, 40000 SHAH ALAM','SELANGOR',40000,'','','','','03-55225058','',NULL,'IP','OP','A','0',0.00,0.00,1001.00,'615100','1001','712130','','','15/10/2019','norasikin','','','','','','','','',0,'0','0000-00-00 00:00:00',27.00,9999999.99,'9999999.99','0000-00-00 00:00:00',NULL,NULL,NULL,NULL,NULL,NULL),(181,'9A','CO','NADI','NATIONAL AEROSPACE & DEFENCE INDUSTRIES SDN BHD','NADI BUILDING, PT 192, JLN LAPANGAN','TERBANG SUBANG,',' 47200 SUBANG','SELANGOR',47200,'','','PN NORFAIDA ABU','SENIOR EXEC. HR','03 - 7844 7100','03- 7859 1824',NULL,'IP','OP','A','0',0.00,0.00,1001.00,'615100','1001','712130','','','30/10/2018','NURAMIRA','','','','','','','','',0,'0','0000-00-00 00:00:00',5.00,9999999.99,'9999999.99','0000-00-00 00:00:00',NULL,NULL,NULL,NULL,NULL,NULL),(182,'9A','CO','NASAM','NATIONAL STROKE ASSOCIATION OF MALAYSIA','12, JALAN 7/2','46050, PETALING JAYA','SELANGOR','',46050,'','','','','','',NULL,'IP','OP','A','0',0.00,0.00,1001.00,'615100','1001','712130','','','1/03/2017','MIMI','','','','','','','','',0,'0','0000-00-00 00:00:00',1.00,9999999.99,'9999999.99','0000-00-00 00:00:00',NULL,NULL,NULL,NULL,NULL,NULL),(183,'9A','CO','O&CO','K.S. ONG & CO','NO.424A, JALAN 5/132','TAMAN GASING INDAH','59200 KUALA LUMPUR','',59200,'','','','','03-77837399','03-77832784',NULL,'IP','OP','A','0',0.00,0.00,1001.00,'615100','1001','712130','','','4/11/2019','JANNAH','','','','','','','','',0,'0','0000-00-00 00:00:00',23.00,9999999.99,'9999999.99','0000-00-00 00:00:00',NULL,NULL,NULL,NULL,NULL,NULL),(184,'9A','CO','PANASONIC','PANASONIC INDUSTRIAL DEVICES (M) SDN BHD','NO.1, JALAN JEMUJU 16/13','SEKSYEN 16, 40200 SHAH ALAM','SELANGOR','',40200,'','','PN AZURA','','03 - 5891 2815','',NULL,'IP','OP','A','0',0.00,0.00,1001.00,'615100','1001','712130','','','5/09/2018','MIMI','','','','','','','','',0,'0','0000-00-00 00:00:00',9.00,9999999.99,'9999999.99','0000-00-00 00:00:00',NULL,NULL,NULL,NULL,NULL,NULL),(185,'9A','CO','PEM','PERODUA ENGINE MANUFACTURING SDN BHD','SUNGAI CHOH',' LOCKED BAG 226','48009 RAWANG','SELANGOR',48009,'','','','','','',NULL,'IP','OP','A','531.9',0.00,0.00,1001.00,'615100','1001','712130','','','18/12/2019','norasikin','','','','','','','','',0,'0','0000-00-00 00:00:00',17.00,9999999.99,'9999999.99','0000-00-00 00:00:00',NULL,NULL,NULL,NULL,NULL,NULL),(186,'9A','CO','PERHEBAT','PERBADANAN HAL EHWAL BEKAS ANGKATAN TENTERA','KETUA UNIT PENTADBIRAN,','BAHAGIAN KEWANGAN DAN PENTADBIRAN,','KEM SUNGAI BULOH, PETI SURAT 65','47000 SUNGAI BULOH, SELANGOR',47000,'','','PN SARIPAH NORASLIDA / PN NIETA KARDIMAN','','03-6156 9412','03-6457 0075',NULL,'IP','OP','A','0',0.00,0.00,1001.00,'615100','1001','712130','','','22/11/2019','norasikin','','','','','','','','',0,'0','0000-00-00 00:00:00',24.00,9999999.99,'9999999.99','0000-00-00 00:00:00',NULL,NULL,NULL,NULL,NULL,NULL),(187,'9A','CO','PERKESO','PERTUBUHAN KESELAMATAN SOSIAL','KETUA EKSEKUTIF, PERKESO','MENARA PERKESO, 281, JALAN AMPANG','50538 KUALA LUMPUR','U/P: UNIT KEMUDAHAN ANGGOTA - HR',50538,'','','PN NORSALINA / EN HAMZAH','','03-4263 5034 / 4264 5045','03-4256 6358',NULL,'IP','OP','A','0',0.00,0.00,1001.00,'615100','1001','712130','','','3/08/2018','nuramira','','','','','','','','',0,'0','0000-00-00 00:00:00',17.00,9999999.99,'9999999.99','0000-00-00 00:00:00',NULL,NULL,NULL,NULL,NULL,NULL),(188,'9A','CO','PERNEC','PERNEC INTEGRATED NETWORK SYSTEMS SDN BHD','NO.21, JLN SETIAWANGSA 8','TMN SETIAWANGSA','54200 KUALA LUMPUR','',54200,'','','EN ADNAN ZAMRI ABDULLAH','HEAD, HR & ADMIN','03-4259 6000','03-4259 6131',NULL,'IP','OP','A','0',0.00,0.00,1001.00,'615100','1001','712130','','','18/12/2019','norasikin','','','','','','','','',0,'0','0000-00-00 00:00:00',22.00,9999999.99,'9999999.99','0000-00-00 00:00:00',NULL,NULL,NULL,NULL,NULL,NULL),(189,'9A','CO','PERODUA','PERODUA MANUFACTURING SDN BHD','SUNGAI CHOH, LOCKED BAG 226','48009 RAWANG, SELANGOR','','',48009,'','','NOR ANITA BT MUZAFFAR','GM','0360928888 EXT-3774','',NULL,'IP','OP','A','9932.5',0.00,0.00,1001.00,'615100','1001','712130','','','12/02/2020','norasikin','','','','','','','','',0,'0','0000-00-00 00:00:00',19.00,9999999.99,'9999999.99','0000-00-00 00:00:00',NULL,NULL,NULL,NULL,NULL,NULL),(190,'9A','CO','PGM','PERODUA GLOBAL MANUFACTURING SDN BHD','SUNGAI CHOH, LOCKED BAG 224','48009 RAWANG, SELANGOR','','',48009,'','','PN SULBIAH ARIF','','03-60928888 EXT : 6019','',NULL,'IP','OP','A','13421.5',0.00,0.00,1001.00,'615100','1001','712130','','','3/02/2020','norasikin','','','','','','','','',0,'0','0000-00-00 00:00:00',10.00,9999999.99,'9999999.99','0000-00-00 00:00:00',NULL,NULL,NULL,NULL,NULL,NULL),(191,'9A','CO','PMCARE','PMCARE SDN BHD','NO 1, JALAN USJ 21/10','UEP SUBANG JAYA','47630 SUBANG JAYA','SELANGOR',0,'','','PN FAEZAH IBRAHIM','PROVIDER NETWORK','03-80266888','03-80266999',NULL,'IP','OP','A','278679.29',0.00,0.00,1001.00,'615100','1001','712130','','','25/05/2021','TAJUL','','','ABC HEALTHCARE SDN BHD','','','','','',0,'0','0000-00-00 00:00:00',6.00,9999999.99,'9999999.99','0000-00-00 00:00:00',NULL,NULL,NULL,NULL,NULL,NULL),(192,'9A','CO','PMCARE (TNB)','PMCARE SDN BHD  (TNB)','NO.1, JALAN USJ 21/10','UEP SUBANG JAYA','47630 SELANGOR','',47630,'','','','','','',NULL,'IP','OP','A','-200',0.00,0.00,1001.00,'615100','1001','712130','','','17/05/2019','NORASIKIN','','','','','','','','',0,'0','0000-00-00 00:00:00',7.00,9999999.99,'9999999.99','0000-00-00 00:00:00',NULL,NULL,NULL,NULL,NULL,NULL),(193,'9A','CO','PPP','PLAIN PAPER PAINT PRODUCTION','','','','',0,'','','','','','',NULL,'IP','OP','A','0',0.00,0.00,1001.00,'615100','1001','712130','','','23/11/2017','fauziana','','','','','','','','',0,'0','0000-00-00 00:00:00',12.00,9999999.99,'9999999.99','0000-00-00 00:00:00',NULL,NULL,NULL,NULL,NULL,NULL),(194,'9A','CO','PRUBSN','PRUBSN BSN TAKAFUL BERHAD','PRUBSN SCANNING TEAM (DMC DEPT)','LEVEL 11, MENARA PRUDENTIAL','PERSIARAN TRX BARAT, 55188','TUN RAZAK EXCHANGE, KUALA LUMPUR',55188,'','','','','03 - 2053 7188','',NULL,'IP','OP','A','146036.56',0.00,0.00,1001.00,'615100','1001','712130','','','17/02/2020','najihah','','','','','','','','',0,'0','0000-00-00 00:00:00',23.00,9999999.99,'9999999.99','0000-00-00 00:00:00',NULL,NULL,NULL,NULL,NULL,NULL),(195,'9A','CO','PS RANJAN','PS RANJAN & CO','ADVOCATES & SOLICITORS','17TH FLOOR, ISMA LEE RUBBER','NO.1, JALAN MELAKA','50100 KUALA LUMPUR',50100,'','','','','03-2078 8181','03-2078 5522',NULL,'IP','OP','A','0',0.00,0.00,1001.00,'615100','1001','712130','','','10/05/2019','norasikin','','','','','','','','',0,'0','0000-00-00 00:00:00',30.00,9999999.99,'9999999.99','0000-00-00 00:00:00',NULL,NULL,NULL,NULL,NULL,NULL),(196,'9A','CO','PSK','PEJABAT SETIAUSAHA KERAJAAN NEGERI SELANGOR','TIMBALAN PENGARAH,UNIT PERANCANGAN','EKONOMI NEGERI,SEK. PIHAK BERKUASA','TEMPATAN, TKT 4, BGN SULTAN SALAHUDDIN','ABD AZIZ SHAH, 40503 SHAH ALAM, SELANGOR',40503,'','','','','','',NULL,'IP','OP','A','100',0.00,0.00,1001.00,'615100','1001','712130','','','6/11/2019','norasikin','','','','','','','','',0,'0','0000-00-00 00:00:00',27.00,9999999.99,'9999999.99','0000-00-00 00:00:00',NULL,NULL,NULL,NULL,NULL,NULL),(197,'9A','CO','PSSB','PERODUA SALES SDN BHD','SUNGAI CHOH, LOCKED BAG 226','48009, RAWANG, SELANGOR','','',48009,'','','PN AZLINA','','03-6092888 EXT : 3774','',NULL,'IP','OP','A','1986.05',0.00,0.00,1001.00,'615100','1001','712130','','','12/02/2020','norasikin','','','','','','','','',0,'0','0000-00-00 00:00:00',10.00,9999999.99,'9999999.99','0000-00-00 00:00:00',NULL,NULL,NULL,NULL,NULL,NULL),(198,'9A','CO','PV','PAMELA VIJAYRANI & CO','ADVOCATES & SOLICITORS','NO.5, 1ST FLOOR, JLN SERI BETIK','TAMAN SERI BETIK, 14000','BUKIT MERTAJAM, P.PINANG',14000,'','','','','04-538 0231','04-538 1231',NULL,'IP','OP','A','0',0.00,0.00,1001.00,'615100','1001','712130','','','22/01/2019','MIMI','','','','','','','','',0,'0','0000-00-00 00:00:00',22.00,9999999.99,'9999999.99','0000-00-00 00:00:00',NULL,NULL,NULL,NULL,NULL,NULL),(199,'9A','CO','RAVENDRAN','M.RAVENDRAN & ASSOCIATES','NO. 52A, JALAN WAWASAN','2/3 BANDAR BARU AMPANG','68000 AMPANG, SELANGOR','',68000,'','','','','','',NULL,'IP','OP','A','0',0.00,0.00,1001.00,'615100','1001','712130','','','16/05/2019','JANNAH','','','','','','','','',0,'0','0000-00-00 00:00:00',6.00,9999999.99,'9999999.99','0000-00-00 00:00:00',NULL,NULL,NULL,NULL,NULL,NULL),(200,'9A','CO','RL','RAM & LOW','ADVOCATES & SOLICITORS','UNIT 6, LEVEL6, MENARA MBMR','NO.1, JALAN SYED PUTRA','58000 KUALA LUMPUR',58000,'','','','','03-2715 1357','03-2260 1066',NULL,'IP','OP','A','0',0.00,0.00,1001.00,'615100','1001','712130','','','5/08/2019','MIMI','','','','','','','','',0,'0','0000-00-00 00:00:00',16.00,9999999.99,'9999999.99','0000-00-00 00:00:00',NULL,NULL,NULL,NULL,NULL,NULL),(201,'9A','CO','RMOORTHI','RAVI MOORTHI, NORIZA, MALA & PARTNERS','1-G-4, PANTAI PANORAMA','JALAN 112H, BANGSAR SOUTH','59200 KUALA LUMPUR','',59200,'','','PN SHIDAH','','03-2742 7716','03- 2742 7719',NULL,'IP','OP','A','0',0.00,0.00,1001.00,'615100','1001','712130','','','25/04/2018','nuramira','','','','','','','','',0,'0','0000-00-00 00:00:00',19.00,9999999.99,'9999999.99','0000-00-00 00:00:00',NULL,NULL,NULL,NULL,NULL,NULL),(202,'9A','CO','S&C','SIVARAJA & CO','ADVOCATES & SOLICITORS','NO.32A, JALAN SRI SARAWAK 18','KAW.2, TMN SRI ANDALAS','41200 KLANG, SELANGOR',41200,'','','','','03-33247033','03-33248033',NULL,'IP','OP','A','0',0.00,0.00,1001.00,'615100','1001','712130','','','5/11/2019','MIMI','','','','','','','','',0,'0','0000-00-00 00:00:00',9.00,9999999.99,'9999999.99','0000-00-00 00:00:00',NULL,NULL,NULL,NULL,NULL,NULL),(203,'9A','CO','SAUJANA TRIANGLE','SAUJANA TRIANGLE SDN BHD','NO.19, JALAN PJU 8/5H,','PERDANA BUSINESS CENTRE,','BANDAR DAMANSARA PERDANA,','47820 PETALING JAYA, SELANGOR.',47820,'','','PN SERIAH','HUMAN RESOURCE','03-7726 8866','03-7728 7416',NULL,'IP','OP','A','0',0.00,0.00,1001.00,'615100','1001','712130','','','13/02/2019','NURAMIRA','','','','','','','','',0,'0','0000-00-00 00:00:00',13.00,9999999.99,'9999999.99','0000-00-00 00:00:00',NULL,NULL,NULL,NULL,NULL,NULL),(204,'9A','CO','SDZ','SYED DZAHIR, ZAHIRAH & CO','NO.40-1, JALAN PUTRA MAHKOTA 7/6A','PUTRA HEIGHTS, 47650, SUBANG JAYA','SELANGOR DARUL EHSAN','',47650,'','','','','03-5103 9661, 012 2700 646','03-5103 4961',NULL,'IP','OP','A','150',0.00,0.00,1001.00,'615100','1001','712130','','','26/12/2019','MIMI','','','','','','','','',0,'0','0000-00-00 00:00:00',26.00,9999999.99,'9999999.99','0000-00-00 00:00:00',NULL,NULL,NULL,NULL,NULL,NULL),(205,'9A','CO','SELCARE','SELCARE MANAGEMENT SDN BHD','NO.16-01, LEVEL 16, PLAZA AZALEA','JALAN PEMBANGUNAN 14/6, SECTION 14','40000, SHAH ALAM, SELANGOR','',40000,'','','','','03- 5525 6600','03- 5525 6900',NULL,'IP','OP','A','43385.25',0.00,0.00,1001.00,'615100','1001','712130','','','18/12/2019','norasikin','','','','','','','','',0,'0','0000-00-00 00:00:00',9.00,9999999.99,'9999999.99','0000-00-00 00:00:00',NULL,NULL,NULL,NULL,NULL,NULL),(206,'9A','CO','SERI INDAH','KLINIK SERI INDAH (SAMUDRA) SDN BHD','','','','',0,'','','','','','',NULL,'IP','OP','A','0',0.00,0.00,1001.00,'615100','1001','712130','','','18/09/2019','JANNAH','','','','','','','','',0,'0','0000-00-00 00:00:00',18.00,9999999.99,'9999999.99','0000-00-00 00:00:00',NULL,NULL,NULL,NULL,NULL,NULL),(207,'9A','CO','SIME DARBY','SIME DARBY PLANTATION BERHAD','SUNGAI BULOH ESTATE','P.O. BOX NO. 5','45700 BUKIT ROTAN','SELANGOR',45700,'','','','','03-32891016','',NULL,'IP','OP','A','0',0.00,0.00,1001.00,'615100','1001','712130','','','28/06/2019','norasikin','','','','','','','','',0,'0','0000-00-00 00:00:00',10.00,9999999.99,'9999999.99','0000-00-00 00:00:00',NULL,NULL,NULL,NULL,NULL,NULL),(208,'9A','CO','SME','SME ORDNANCE SDN BHD','LOT 5065, LOCKED BAG NO. 101','48109 BATU ARANG','SELANGOR','',48109,'','','','','03-78591820','03-78591824',NULL,'IP','OP','A','9605.4',0.00,0.00,1001.00,'615100','1001','712130','','','23/03/2018','nuramira','','','','','','','','',0,'0','0000-00-00 00:00:00',3.00,9999999.99,'9999999.99','0000-00-00 00:00:00',NULL,NULL,NULL,NULL,NULL,NULL),(209,'9A','CO','SME CORPORATION','SME CORPORATION MALAYSIA','LEVEL 6, SME 1, BLOCK B,PLATINUM SENTRAL','JLN STESEN SENTRAL 2, KL SENTRAL,','50470 KUALA LUMPUR','U/P : PN RABIATUL ADAWIYAH ABD RAHMAN',50470,'','','PN DALINAWATI','HUMAN RESOURCE','03-2775 6001','03-2775 6073',NULL,'IP','OP','A','0',0.00,0.00,1001.00,'615100','1001','712130','','','27/09/2018','NURAMIRA','','','','','','','','',0,'0','0000-00-00 00:00:00',18.00,9999999.99,'9999999.99','0000-00-00 00:00:00',NULL,NULL,NULL,NULL,NULL,NULL),(210,'9A','CO','TALENT','TALENT SYNERGY SDN BHD','LOT 11A, JALAN P/7, SEKSYEN 13','KAWASAN PERINDUSTRIAN BANGI','43650 BANDAR BARU BANGI','SELANGOR',43650,'','','','','','',NULL,'IP','OP','A','0',0.00,0.00,1001.00,'615100','1001','712130','','','8/01/2020','norasikin','','','','','','','','',0,'0','0000-00-00 00:00:00',30.00,9999999.99,'9999999.99','0000-00-00 00:00:00',NULL,NULL,NULL,NULL,NULL,NULL),(211,'9A','CO','TCSB','TASEK CONCRETE SDN BHD','LOT 1552, KG JAYA INDUSTRIAL AREA','OFF JALAN HOSPITAL, 47000  SUNGAI BULOH','SELANGOR','',47000,'','','','','03- 6156 8221','03- 6141 2008 / 2103',NULL,'IP','OP','A','0',0.00,0.00,1001.00,'615100','1001','712130','','','28/09/2016','ANIS','','','','','','','','',0,'0','0000-00-00 00:00:00',19.00,9999999.99,'9999999.99','0000-00-00 00:00:00',NULL,NULL,NULL,NULL,NULL,NULL),(212,'9A','CO','TDK','TERAS DARA KONSORTIUM SDN BHD','KOMPLEKS KHIDMAT BANDARAN','LORONG SEKOLAH KANAN 1','26700 MUADZAM SHAH','PAHANG',26700,'','','PN SITI NORMAWATI / PN YUSIDAWATI','HR','09-4525446 / 441','',NULL,'IP','OP','A','0',0.00,0.00,1001.00,'615100','1001','712130','','','27/12/2016','mimi','','','','','','','','',0,'0','0000-00-00 00:00:00',10.00,9999999.99,'9999999.99','0000-00-00 00:00:00',NULL,NULL,NULL,NULL,NULL,NULL),(213,'9A','CO','TGSB','TEROTECHNOLOGY GLOBAL SDN BHD','NO.82-1-2, JALAN 8/62A','BANDAR MANJALARA','52200 KUALA LUMPUR','',52200,'','','PN NORHAYATI BT MOHD SURI','','03-6276 4042 / 012-6654433','03-6275 5250',NULL,'IP','OP','A','2704.1',0.00,0.00,1001.00,'615100','1001','712130','','','7/09/2018','MIMI','','','','','','','','',0,'0','0000-00-00 00:00:00',7.00,9999999.99,'9999999.99','0000-00-00 00:00:00',NULL,NULL,NULL,NULL,NULL,NULL),(214,'9A','CO','THYSSENKRRUPP','THYSSENKRUPP ELEVATOR MALAYSIA SDN BHD','LEVEL 18, THE PINNACCLE,','PERSIARAN LAGOON,','BANDAR SUNWAY 46150 PETALING JAYA','',46150,'','','MS RACHEL / MS CLARISE','HUMAN RESOURCE','03-56229977','03-56229988',NULL,'IP','OP','A','0',0.00,0.00,1001.00,'615100','1001','712130','','','12/09/2019','norasikin','','','','','','','','',0,'0','0000-00-00 00:00:00',20.00,9999999.99,'9999999.99','0000-00-00 00:00:00',NULL,NULL,NULL,NULL,NULL,NULL),(215,'9A','CO','TMEH','TMEH MARKETING SDN BHD','NO.9, JALAN JASMINE 1, SEKSYEN BB 10','BANDAR BUKIT BERUNTUNG','48300 RAWANG, SELANGOR','',48300,'','','','','03-6028 5722','03- 6028 5720 / 21',NULL,'IP','OP','A','0',0.00,0.00,1001.00,'615100','1001','712130','','','6/06/2017','MIMI','','','','','','','','',0,'0','0000-00-00 00:00:00',8.00,9999999.99,'9999999.99','0000-00-00 00:00:00',NULL,NULL,NULL,NULL,NULL,NULL),(216,'9A','CO','TNB','TENAGA NASIONAL BERHAD','MEDICAL CLAIM UNIT, TNB HEALTHCARE','TENAGA NASIONAL BERHAD (200886-W)','UNIT G-1,GROUND FLOOR, WISMA CIMB','NO.11, JLN PANTAI JAYA (JLN 4/83A), KL',59200,'','','','','1300-80-5656','1300-22-5656',NULL,'IP','OP','A','54950.8',0.00,0.00,1001.00,'615100','1001','712130','','','17/02/2020','norasikin','','','','','','','','',0,'0','0000-00-00 00:00:00',8.00,9999999.99,'9999999.99','0000-00-00 00:00:00',NULL,NULL,NULL,NULL,NULL,NULL),(217,'9A','CO','TRADEWINDS','TRADEWINDS CORPORATION BERHAD','LEVEL 21, HOTEL ISTANA','KUALA LUMPUR CITY CENTRE','NO.73, JALAN RAJA CHULAN','50200 KUALA LUMPUR',50200,'','','','','03-2727 7000','03-2727 7007',NULL,'IP','OP','A','0',0.00,0.00,1001.00,'615100','1001','712130','','','22/08/2017','MIMI','','','','','','','','',0,'0','0000-00-00 00:00:00',17.00,9999999.99,'9999999.99','0000-00-00 00:00:00',NULL,NULL,NULL,NULL,NULL,NULL),(218,'9A','CO','TSSB','TENAGA SWITCHGEAR SDN BHD','LOT 3, JALAN TEKNOLOGI 3/6, SEKSYEN 3','TAMAN SAINS SELANGOR 1,','KOTA DAMANSARA, 47810 PETALING JAYA','SELANGOR',47810,'','','CIK NADIATUL','','03 -61406520 EXT : 571','019- 3075704',NULL,'IP','OP','A','2561.75',0.00,0.00,1001.00,'615100','1001','712130','','','31/01/2020','norasikin','','','','','','','','',0,'0','0000-00-00 00:00:00',19.00,9999999.99,'9999999.99','0000-00-00 00:00:00',NULL,NULL,NULL,NULL,NULL,NULL),(219,'9A','CO','UDA DAYA','UDA DAYAURUS SDN BHD','TINGKAT RG, KOMPLEKS PERTAMA','JALAN TUANKU ABDUL RAHMAN','50100 KUALA LUMPUR','',50100,'','','','','03-26970260','03-26970244',NULL,'IP','OP','A','0',0.00,0.00,1001.00,'615100','1001','712130','','','30/09/2019','norasikin','','','','','','','','',0,'0','0000-00-00 00:00:00',10.00,9999999.99,'9999999.99','0000-00-00 00:00:00',NULL,NULL,NULL,NULL,NULL,NULL),(220,'9A','CO','UDA HOLDINGS','UDA HOLDINGS BHD','TOWER BLOCK, PERTAMA COMPLEX,','JALAN TUANKU ABDUL RAHMAN,','50100 KUALA LUMPUR.','',50100,'','','PN MARDHIAH','HR','03-2730 8500 EXT 8552','',NULL,'IP','OP','A','0',0.00,0.00,1001.00,'615100','1001','712130','','','10/12/2019','norasikin','','','','','','','','',0,'0','0000-00-00 00:00:00',10.00,9999999.99,'9999999.99','0000-00-00 00:00:00',NULL,NULL,NULL,NULL,NULL,NULL),(221,'9A','CO','UHLD','UITM HOLDINGS SDN BHD','GROUP HUMAN CAPITAL, LEVEL 3, BLOCK 1','INTEKMA RESORT & CONVENTION CENTRE','PERSIARAN RAJA MUDA, SECTION 7','40000 SHAH ALAM, SELANGOR',0,'','','PN. ATTEYA / PN NOR HASNIDA','HUMAN CAPITAL EXECUT','03-55225058','03-55225059',NULL,'IP','OP','A','-2880',0.00,0.00,1001.00,'615100','1001','712130','','','1/01/2020','norasikin','','','','','','','','',0,'0','0000-00-00 00:00:00',28.00,9999999.99,'9999999.99','0000-00-00 00:00:00',NULL,NULL,NULL,NULL,NULL,NULL),(222,'9A','CO','UHMS','UITM HOSPITALITY MANAGEMENT SERVICES SDN BHD','INTEKMA RESORT & CONVENTION CENTRE','LEVEL 2 BLOK 13,','PERSIARAN RAJA MUDA, SECTION 7','40000 SHAH ALAM, SELANGOR',40000,'','','PN. SUHAILIN ZAINAL ABIDIN','GROUP HUMAN CAPITAL','03-55225000/ 5112','',NULL,'IP','OP','A','0',0.00,0.00,1001.00,'615100','1001','712130','','','17/10/2019','norasikin','','','','','','','','',0,'0','0000-00-00 00:00:00',3.00,9999999.99,'9999999.99','0000-00-00 00:00:00',NULL,NULL,NULL,NULL,NULL,NULL),(223,'9A','CO','UITM','PEJABAT BENDAHARI','ARAS 8, BGN AKADEMIK FAKULTI PERUBATAN','UITM CAWANGAN SELANGOR','KAMPUS SUNGAI BULOH, JLN HOSPITAL','47000 SUNGAI BULOH, SELANGOR',47000,'','','PN ALZURA ALANG IDRIS','','03-6126 7024','03-6126 7140',NULL,'IP','OP','A','-16002.5',0.00,0.00,1001.00,'615100','1001','712130','','','13/12/2019','norasikin','','','','','','','','',0,'0','0000-00-00 00:00:00',4.00,9999999.99,'9999999.99','0000-00-00 00:00:00',NULL,NULL,NULL,NULL,NULL,NULL),(224,'9A','CO','UITMAD','UITM ART & DESIGN SDN BHD','LOT 8, LEVEL G4, PUBLIKA SHOPPING','GALLERY SOLARIS DUTAMAS,','NO.1 JALAN DUTAMAS,','50480 KUALA LUMPUR.',50480,'','','','','03-62119440','03-62431107',NULL,'IP','OP','A','180',0.00,0.00,1001.00,'615100','1001','712130','','','16/05/2019','norasikin','','','','','','','','',0,'0','0000-00-00 00:00:00',8.00,9999999.99,'9999999.99','0000-00-00 00:00:00',NULL,NULL,NULL,NULL,NULL,NULL),(225,'9A','CO','UITMDS','UITM DOCUMENT SERVICES SDN BHD','LEVEL 2, BLOCK 1','INTEKMA RESORT & CONVENTION CENTRE','PERSIARAN RAJA MUDA , SECTION 7','40000 SHAH ALAM, SELANGOR',40000,'','','','','03-5522 5366','03-5513 8239',NULL,'IP','OP','A','0',0.00,0.00,1001.00,'615100','1001','712130','','','12/09/2018','nuramira','','','','','','','','',0,'0','0000-00-00 00:00:00',17.00,9999999.99,'9999999.99','0000-00-00 00:00:00',NULL,NULL,NULL,NULL,NULL,NULL),(226,'9A','CO','UITMPM','UITM ENERGY & FACILITIES SDN BHD','LEVEL 3, BLOCK 1, INTEKMA RESORT &','CONVENTION CENTRE, PERSIARAN RAJA','MUDA, SECTION 7, 40000 SHAH ALAM','SELANGOR',40000,'','','PN NADIAH (HR)','','03-5522 5058 / 5047','03-5522 5059',NULL,'IP','OP','A','2160',0.00,0.00,1001.00,'615100','1001','712130','','','4/01/2020','alida','','','','','','','','',0,'0','0000-00-00 00:00:00',13.00,9999999.99,'9999999.99','0000-00-00 00:00:00',NULL,NULL,NULL,NULL,NULL,NULL),(227,'9A','CO','UITMPSC','UITM PRIVATE SPECIALIST CENTRE','LEVEL 2 & 5, CLINICAL BUILDING','FACULTY OF MEDICINE, UITM SG BULOH','CAMPUS, JALAN HOSPITAL','47000 SUNGAI BULOH',47000,'','','','','','',NULL,'IP','OP','A','180',0.00,0.00,1001.00,'615100','1001','712130','','','3/02/2020','NORASIKIN','','','','','','','','',0,'0','0000-00-00 00:00:00',25.00,9999999.99,'9999999.99','0000-00-00 00:00:00',NULL,NULL,NULL,NULL,NULL,NULL),(228,'9A','CO','UITMSP','UITM SOLAR POWER','LEVEL 4, BLOCK 1, INTEKMA RESORT &','CONVENTION CENTRE, PERSIARAN RAJA','MUDA, SECTION 7, 40000 SHAH ALAM','SELANGOR',40000,'','','PN DIYANA','','03 - 5522 5058','03 - 5522 5059',NULL,'IP','OP','A','180',0.00,0.00,1001.00,'615100','1001','712130','','','29/08/2019','norasikin','','','','','','','','',0,'0','0000-00-00 00:00:00',8.00,9999999.99,'9999999.99','0000-00-00 00:00:00',NULL,NULL,NULL,NULL,NULL,NULL),(229,'9A','CO','UNIKL','UNIVERSITI KUALA LUMPUR','BRITISH MALAYSIAN INSTITUTE','BATU 8, JALAN SG. PUSU','53100 GOMBAK','SELANGOR',53100,'','','ATTN : PMTC UNIT','','03 - 6184 1000','03 - 6186 4040',NULL,'IP','OP','A','390',0.00,0.00,1001.00,'615100','1001','712130','','','25/10/2017','MIMI','','','','','','','','',0,'0','0000-00-00 00:00:00',10.00,9999999.99,'9999999.99','0000-00-00 00:00:00',NULL,NULL,NULL,NULL,NULL,NULL),(230,'9A','CO','UTM','UNIVERSITI TEKNOLOGI MALAYSIA','BAHAGIAN PENDAFTAR, UTM','JALAN SULTAN YAHYA PETRA','54100 KUALA LUMPUR','(U/P: EN HASANUDDIN OTHMAN)',54100,'','','PN NOORHAFIZA NOORDIN','','03 - 2615 4231','',NULL,'IP','OP','A','0',0.00,0.00,1001.00,'615100','1001','712130','','','13/09/2019','NORASIKIN','','','','','','','','',0,'0','0000-00-00 00:00:00',16.00,9999999.99,'9999999.99','0000-00-00 00:00:00',NULL,NULL,NULL,NULL,NULL,NULL),(231,'9A','CO','UTUSAN','UTUSAN MELAYU (MALAYSIA) BERHAD','JALAN LIMA, OFF JALAN CHAN SOW LIN','55200 KUALA LUMPUR','','',55200,'','','PN SITI/ PN NAWAL ABDULLAH','','03-92322 600 EXT : 2692/2693','',NULL,'IP','OP','A','0',0.00,0.00,1001.00,'615100','1001','712130','','','5/12/2017','MIMI','','','','','','','','',0,'0','0000-00-00 00:00:00',14.00,9999999.99,'9999999.99','0000-00-00 00:00:00',NULL,NULL,NULL,NULL,NULL,NULL),(232,'9A','CO','YHS','YONG HUP SENG AUTO PARTS (M) SDN BHD','LOT 834-B6 & B7, JALAN KUSTA','KWSN INDUSTRI KAMPUNG JAYA','47000 SUNGAI BULOH, SELANGOR','',47000,'','','MS. CHAI WEI WEI','YHS.AUTOPARTS@HOTMAI','03-6157 0000','03-6151 7667',NULL,'IP','OP','A','0',0.00,0.00,1001.00,'615100','1001','712130','','','4/02/2019','nuramira','','','','','','','','',0,'0','0000-00-00 00:00:00',13.00,9999999.99,'9999999.99','0000-00-00 00:00:00',NULL,NULL,NULL,NULL,NULL,NULL),(233,'9A','CO','ZAKAT','LEMBAGA ZAKAT SELANGOR','CAWANGAN TAMAN MELAWATI, NO.340','LORONG SARAWAK (BLOK B),MELAWATI','URBAN 1, PUSAT BANDAR MELAWATI','53100 HULU KLANG, SELANGOR',53100,'','','','','','',NULL,'IP','OP','A','5456.3',0.00,0.00,1001.00,'615100','1001','712130','','','31/05/2021','tajul','','','','','','','','',0,'0','0000-00-00 00:00:00',28.00,9999999.99,'9999999.99','0000-00-00 00:00:00',NULL,NULL,NULL,NULL,NULL,NULL),(234,'9A','CO','ZAKAT KLANG','LEMBAGA ZAKAT SELANGOR (CAW. KLANG)','NO.31-G, JALAN KS9/KU5','TAMAN KLANG SENTRAL','BUKIT RAJA, 40150, KLANG','SELANGOR',40150,'','','PN NORAZIDAH','','','',NULL,'IP','OP','A','0',0.00,0.00,1001.00,'615100','1001','712130','','','1/07/2019','norasikin','','','017-2420014 (PN NORAZIDAH)','','','','','',0,'0','0000-00-00 00:00:00',25.00,9999999.99,'9999999.99','0000-00-00 00:00:00',NULL,NULL,NULL,NULL,NULL,NULL),(235,'9A','CO','ZAMAN TELADAN','ZAMAN TELADAN SDN BHD','NO.19, JALAN PJU 8/5H,','PERDANA BUSINESS CENTRE,','BANDAR DAMANSARA PERDANA,','47820 PETALING JAYA,SELANGOR.',47820,'','','PN SERIAH','HUMAN RESOURCE','03-7726 866','03-7728 7416',NULL,'IP','OP','A','0',0.00,0.00,1001.00,'615100','1001','712130','','','13/02/2019','NURAMIRA','','','','','','','','',0,'0','0000-00-00 00:00:00',13.00,9999999.99,'9999999.99','0000-00-00 00:00:00',NULL,NULL,NULL,NULL,NULL,NULL),(288,'XX','PR','25517','MUHAMMAD ARIF BIN MOHAMMAD SHUKRI','NO. 12 JALAN DESA AMAN S16/1','TAMAN DESA AMAN',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'IP','OP','A',NULL,0.00,NULL,'0000','3000/000','0000','3001/207',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'muhammadarif','2022-09-21 11:19:28',NULL,NULL,NULL,NULL,NULL,NULL),(301,'XX','PR','81','RAMLAH BINTI MD YUSOF','41-05-01','FLAT SRI PERAK','BANDAR BARU SENTUL',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'IP','OP','A',NULL,0.00,NULL,'0000','3000/000','0000','3001/207',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'hazman','2022-10-05 13:25:01',NULL,NULL,NULL,NULL,NULL,NULL),(1,'XX','PR','AFIQ','AFIQ FAHKRI BIN ZULKEFLEE','','','','',0,'','','','','','','','','IP','OP','ACTIVE',0.00,0.00,0.00,'0000','3000/000','0000','3001/207','','','?','','','','','','','','',0,'','0000-00-00 00:00:00',9999999.99,9999999.99,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL),(2,'XX','PR','AZLINA','NORAZLINA BINTI BUANG ','','','','',0,'','','','','','','','','IP','OP','ACTIVE',0.00,0.00,0.00,'0000','3000/000','0000','3001/207','','','?','','','','','','','','',0,'','0000-00-00 00:00:00',9999999.99,9999999.99,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL),(3,'XX','PR','FAUZIAH','FAUZIAH BINTI MOHD YUSOF','','','','',0,'','','','','','','','','IP','OP','ACTIVE',0.00,0.00,0.00,'0000','3000/000','0000','3001/207','','','?','','','','','','','','',0,'','0000-00-00 00:00:00',9999999.99,9999999.99,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL),(4,'XX','PR','GOH','GOH PECK SIN','','','','',0,'','','','','','','','','IP','OP','ACTIVE',0.00,0.00,0.00,'0000','3000/000','0000','3001/207','','','?','','','','','','','','',0,'','0000-00-00 00:00:00',9999999.99,9999999.99,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL),(5,'XX','PR','HASNAH','HASNAH BINTI AHMAD','','','','',0,'','','','','','','','','IP','OP','ACTIVE',0.00,0.00,0.00,'0000','3000/000','0000','3001/207','','','?','','','','','','','','',0,'','0000-00-00 00:00:00',9999999.99,9999999.99,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL),(6,'XX','PR','ROSMA','ROSMALAWATY ','','','','',0,'','','','','','','','','IP','OP','ACTIVE',0.00,0.00,0.00,'0000','3000/000','0000','3001/207','','','?','','','','','','','','',0,'','0000-00-00 00:00:00',9999999.99,9999999.99,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL),(7,'XX','PR','SYAM','SYAMRIZAL BIN GHAZALI ','','','','',0,'','','','','','','','','IP','OP','ACTIVE',0.00,0.00,0.00,'0000','3000/000','0000','3001/207','','','?','','','','','','','','',0,'','0000-00-00 00:00:00',9999999.99,9999999.99,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL);
/*!40000 ALTER TABLE `debtormast` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `debtortype`
--

DROP TABLE IF EXISTS `debtortype`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `debtortype` (
  `idno` int(12) NOT NULL AUTO_INCREMENT,
  `compcode` varchar(5) DEFAULT NULL,
  `debtortycode` varchar(30) NOT NULL,
  `description` varchar(30) DEFAULT NULL,
  `effectdate` datetime DEFAULT NULL,
  `depccode` varchar(10) DEFAULT NULL,
  `depglacc` varchar(30) DEFAULT NULL,
  `actdebccode` varchar(10) DEFAULT NULL,
  `actdebglacc` varchar(30) DEFAULT NULL,
  `lastuser` varchar(30) DEFAULT NULL,
  `lastupdate` datetime DEFAULT NULL,
  `regfees` tinyint(4) DEFAULT NULL,
  `typegrp` varchar(30) DEFAULT NULL,
  `updpayername` tinyint(4) DEFAULT NULL,
  `updepisode` tinyint(4) DEFAULT NULL,
  `recstatus` varchar(10) DEFAULT 'ACTIVE',
  `adduser` varchar(30) DEFAULT NULL,
  `adddate` datetime DEFAULT NULL,
  `upduser` varchar(30) DEFAULT NULL,
  `upddate` datetime DEFAULT NULL,
  `deluser` varchar(30) DEFAULT NULL,
  `deldate` datetime DEFAULT NULL,
  `computerid` varchar(20) DEFAULT NULL,
  `ipaddress` varchar(20) DEFAULT NULL,
  `lastcomputerid` varchar(20) DEFAULT NULL,
  `lastipaddress` varchar(20) DEFAULT NULL,
  PRIMARY KEY (`idno`)
) ENGINE=InnoDB AUTO_INCREMENT=50 DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `debtortype`
--

LOCK TABLES `debtortype` WRITE;
/*!40000 ALTER TABLE `debtortype` DISABLE KEYS */;
INSERT INTO `debtortype` VALUES (23,'13A','BM','BAITULMAL',NULL,'0000','3001/207','0000','3000/000','tajul','0000-00-00 00:00:00',0,'TR',0,0,'ACTIVE',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL),(24,'13A','CO','COMPANY',NULL,'0000','3001/207','0000','3000/000','tajul','0000-00-00 00:00:00',0,'TR',0,0,'ACTIVE',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL),(25,'13A','JK','JABATAN KERAJAAN',NULL,'0000','3001/207','0000','3000/000','tajul','0000-00-00 00:00:00',0,'TR',0,0,'ACTIVE',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL),(26,'13A','MA','MAIS',NULL,'0000','3001/207','0000','3000/000','tajul','0000-00-00 00:00:00',0,'TR',0,0,'ACTIVE',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL),(27,'13A','PR','PERSON RESPONSIBLE',NULL,'0000','3001/207','0000','3000/000','tajul','0000-00-00 00:00:00',0,'TR',0,0,'ACTIVE',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL),(28,'13A','PS','PERKESO',NULL,'0000','3001/207','0000','3000/000','tajul','0000-00-00 00:00:00',0,'TR',0,0,'ACTIVE',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL),(29,'13A','PT','PATIENT',NULL,'0000','3001/207','0000','3000/000','tajul','0000-00-00 00:00:00',0,'TR',0,0,'ACTIVE',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL),(30,'9A','CAMEX','AMEX','0000-00-00 00:00:00','1002','10010002','1000','10010000','WRACHEL','2016-02-15 00:00:00',0,'TR',0,0,'DEACTIVE',NULL,NULL,'farid','2016-02-24 11:54:05','farid','2021-04-20 12:02:42',NULL,NULL,NULL,NULL),(31,'9A','CD','COMPANY DEBTOR','0000-00-00 00:00:00','1002','10010002','1000','10010000','tajul','2002-05-07 00:00:00',0,'TR',0,0,'ACTIVE',NULL,NULL,'farid','2016-02-26 14:34:35',NULL,NULL,NULL,NULL,NULL,NULL),(32,'9A','CDINERS','DINERS','0000-00-00 00:00:00','1002','10010001','1000','10010001','tajul','2002-05-07 00:00:00',0,'TR',0,0,'DEACTIVE',NULL,NULL,'farid','2016-02-25 14:22:50','farid','2021-04-20 12:02:35',NULL,NULL,NULL,NULL),(33,'9A','CHSBC','TRADE HSBC','0000-00-00 00:00:00','006','210008','006','160003','tajul','2002-05-07 00:00:00',0,'TR',0,0,'DEACTIVE',NULL,NULL,NULL,NULL,'farid','2021-04-20 12:02:30',NULL,NULL,NULL,NULL),(34,'9A','CLINIC','CLINIC','0000-00-00 00:00:00','111','160001','006','210008','farid','2015-12-28 14:43:37',0,'Trade',0,0,'DEACTIVE',NULL,NULL,NULL,NULL,'farid','2021-04-20 12:02:24',NULL,NULL,NULL,NULL),(35,'9A','CMBF','MBF','0000-00-00 00:00:00','006','210008','006','160009','tajul','2002-05-07 00:00:00',0,'TR',0,0,'DEACTIVE',NULL,NULL,NULL,NULL,'farid','2021-04-20 12:02:22',NULL,NULL,NULL,NULL),(36,'9A','CORP','CORPORATE DEBTOR','0000-00-00 00:00:00','006','210008','006','160001','ADMIN','2025-01-12 00:00:00',0,'TR',0,0,'ACTIVE',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL),(37,'9A','CSCB','STANDARD CHARTED','0000-00-00 00:00:00','006','210008','006','160004','tajul','2002-05-07 00:00:00',0,'TR',0,0,'DEACTIVE',NULL,NULL,NULL,NULL,'farid','2021-04-20 12:02:19',NULL,NULL,NULL,NULL),(38,'9A','DC','DOCTOR DEBTOR','0000-00-00 00:00:00','006','210008','006','160010','TAJUL','2017-05-07 00:00:00',0,'RC',0,0,'DEACTIVE',NULL,NULL,NULL,NULL,'farid','2021-04-20 12:02:59',NULL,NULL,NULL,NULL),(39,'9A','IC','INTERCO DEBTOR','0000-00-00 00:00:00','fff','ffffff','999','50050102eee','farid','2015-12-30 11:30:10',0,'Trade',0,0,'DEACTIVE',NULL,NULL,NULL,NULL,'farid','2021-04-20 12:02:16',NULL,NULL,NULL,NULL),(40,'9A','IS','INSURANCE','0000-00-00 00:00:00','006','210008','006','160001','tajul','2004-02-13 00:00:00',0,'TR',0,0,'ACTIVE',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL),(41,'2A','OD','OTHER DEBTORS','0000-00-00 00:00:00','006','210011','006','170001','tajul','2031-03-11 00:00:00',0,'TR',0,0,'DEACTIVE',NULL,NULL,NULL,NULL,'farid','2021-04-20 12:02:05',NULL,NULL,NULL,NULL),(42,'9A','OT','OTHER DEBTORS','0000-00-00 00:00:00','1003','50020406','1001','50020405','WRACHEL','2016-02-15 00:00:00',0,'RC',0,0,'DEACTIVE',NULL,NULL,'farid','2016-07-28 15:56:56','farid','2021-04-20 12:02:03',NULL,NULL,NULL,NULL),(43,'9A','PD','PRIVATE DEBTOR','0000-00-00 00:00:00','006','210008','006','160008','tajul','2002-05-07 00:00:00',0,'TR',0,0,'DEACTIVE',NULL,NULL,NULL,NULL,'farid','2021-04-20 12:02:09',NULL,NULL,NULL,NULL),(44,'9A','PT','PATIENT','0000-00-00 00:00:00','1000','10010000','1000','10010000','TAJUL','2009-07-07 00:00:00',0,'TR',0,0,'ACTIVE','','0000-00-00 00:00:00','farid','2017-07-27 16:08:10',NULL,NULL,NULL,NULL,'MIRA-PC','192.168.0.101'),(45,'9A','TM','TRADE DEBTOR-TELEMARKETING','0000-00-00 00:00:00','1001','10010002','1000','10010000','tong','2023-01-15 00:00:00',0,'TR',0,0,'DEACTIVE','','0000-00-00 00:00:00','farid','2016-10-28 14:12:10','farid','2021-04-20 12:01:56','','',NULL,NULL),(46,'9A','PR','PERSON RESPONSIBLE',NULL,'1000','50030400','1000','50020200',NULL,NULL,NULL,NULL,NULL,NULL,'ACTIVE','farid','2016-05-18 15:43:29',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL),(47,'9A','UNIV','UNIVERSITI',NULL,'1000','50030401','1000','50022000',NULL,NULL,NULL,NULL,NULL,NULL,'DEACTIVE','farid','2016-06-29 11:46:39','farid','2016-07-18 10:09:46','farid','2016-07-18 14:31:14',NULL,NULL,NULL,NULL),(48,'9A','GOV','GOVERNMENT',NULL,'1000','50030401','1000','50022000',NULL,NULL,NULL,NULL,NULL,NULL,'ACTIVE','farid','2016-07-18 14:33:23','farid','2016-08-02 15:07:47',NULL,NULL,NULL,NULL,NULL,NULL),(49,'9A','ULT','ULTMATE',NULL,'1000','50030401','1000','50020300',NULL,NULL,NULL,NULL,NULL,NULL,'ACTIVE','farid','2016-07-19 12:54:40','farid','2021-04-20 12:15:42',NULL,NULL,'KLANG','60.54.209.65','KLANG','60.54.209.65');
/*!40000 ALTER TABLE `debtortype` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `dralloc`
--

DROP TABLE IF EXISTS `dralloc`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `dralloc` (
  `compcode` varchar(2) DEFAULT NULL,
  `source` varchar(10) DEFAULT NULL,
  `trantype` varchar(30) DEFAULT NULL,
  `auditno` int(11) DEFAULT NULL,
  `lineno_` int(11) DEFAULT NULL,
  `mrn` int(11) DEFAULT NULL,
  `episno` int(11) DEFAULT NULL,
  `drtnbillno` int(11) DEFAULT NULL,
  `drtnlineno` int(11) DEFAULT NULL,
  `drtnauditno` int(11) DEFAULT NULL,
  `drcode` varchar(15) DEFAULT NULL,
  `chgcode` varchar(30) DEFAULT NULL,
  `allocdate` datetime DEFAULT NULL,
  `drallocamt` decimal(10,4) DEFAULT NULL,
  `drappamt` decimal(13,4) DEFAULT NULL,
  `drappstfamt` decimal(13,4) DEFAULT NULL,
  `cccomamt` decimal(13,4) DEFAULT NULL,
  `approcess` tinyint(4) DEFAULT NULL,
  `lastuser` varchar(13) DEFAULT NULL,
  `lastupddate` datetime DEFAULT NULL,
  `paymode` varchar(30) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `dralloc`
--

LOCK TABLES `dralloc` WRITE;
/*!40000 ALTER TABLE `dralloc` DISABLE KEYS */;
/*!40000 ALTER TABLE `dralloc` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `drceiling`
--

DROP TABLE IF EXISTS `drceiling`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `drceiling` (
  `compcode` varchar(2) DEFAULT NULL,
  `drcode` varchar(15) DEFAULT NULL,
  `effdate` datetime DEFAULT NULL,
  `ceilingamt` decimal(10,2) DEFAULT NULL,
  `ceilingprcnt` decimal(5,2) DEFAULT NULL,
  `epistype` varchar(2) DEFAULT NULL,
  `lastuser` varchar(13) DEFAULT NULL,
  `lastdate` datetime DEFAULT NULL,
  `stfprcnt` decimal(7,2) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `drceiling`
--

LOCK TABLES `drceiling` WRITE;
/*!40000 ALTER TABLE `drceiling` DISABLE KEYS */;
/*!40000 ALTER TABLE `drceiling` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `drcontrib`
--

DROP TABLE IF EXISTS `drcontrib`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `drcontrib` (
  `idno` int(11) NOT NULL AUTO_INCREMENT,
  `lineno_` int(11) DEFAULT NULL,
  `compcode` varchar(2) DEFAULT NULL,
  `drcode` varchar(15) DEFAULT NULL,
  `chgcode` varchar(12) DEFAULT NULL,
  `effdate` datetime DEFAULT NULL,
  `drprcnt` decimal(11,8) DEFAULT NULL,
  `amount` decimal(9,2) DEFAULT NULL,
  `epistype` varchar(2) DEFAULT NULL,
  `consultflag` tinyint(4) DEFAULT NULL,
  `stfamount` decimal(7,2) DEFAULT NULL,
  `stfpercent` decimal(11,8) DEFAULT NULL,
  `lastuser` varchar(13) DEFAULT NULL,
  `lastdate` datetime DEFAULT NULL,
  `corpprcnt` decimal(13,8) DEFAULT NULL,
  `corpamt` decimal(7,2) DEFAULT NULL,
  `specpercentadm` decimal(9,4) DEFAULT NULL,
  `specpercentstd` decimal(7,2) DEFAULT NULL,
  `computerid` varchar(100) DEFAULT NULL,
  `lastcomputerid` varchar(100) DEFAULT NULL,
  `ipaddress` varchar(100) DEFAULT NULL,
  `lastipaddress` varchar(100) DEFAULT NULL,
  `unit` varchar(30) DEFAULT NULL,
  `adduser` varchar(100) DEFAULT NULL,
  `adddate` datetime DEFAULT NULL,
  PRIMARY KEY (`idno`)
) ENGINE=InnoDB AUTO_INCREMENT=4 DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `drcontrib`
--

LOCK TABLES `drcontrib` WRITE;
/*!40000 ALTER TABLE `drcontrib` DISABLE KEYS */;
INSERT INTO `drcontrib` VALUES (3,1,'9A','DRAINA','02040017','2022-04-27 04:00:25',12.00000000,123123.00,'IP',NULL,12323.00,12.00000000,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'NORTHA','farid2','2022-04-26 12:00:25');
/*!40000 ALTER TABLE `drcontrib` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `drcontsetup`
--

DROP TABLE IF EXISTS `drcontsetup`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `drcontsetup` (
  `compcode` varchar(2) DEFAULT NULL,
  `category` varchar(30) DEFAULT NULL,
  `lineno_` int(11) DEFAULT NULL,
  `epistype` varchar(30) DEFAULT NULL,
  `chgcode` varchar(12) DEFAULT NULL,
  `rate` decimal(13,8) DEFAULT NULL,
  `adduser` varchar(30) DEFAULT NULL,
  `adddate` datetime DEFAULT NULL,
  `upduser` varchar(30) DEFAULT NULL,
  `upddate` datetime DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `drcontsetup`
--

LOCK TABLES `drcontsetup` WRITE;
/*!40000 ALTER TABLE `drcontsetup` DISABLE KEYS */;
/*!40000 ALTER TABLE `drcontsetup` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `drconv`
--

DROP TABLE IF EXISTS `drconv`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `drconv` (
  `compcode` varchar(2) DEFAULT NULL,
  `mrn` int(11) DEFAULT NULL,
  `episno` int(11) DEFAULT NULL,
  `billno` int(11) DEFAULT NULL,
  `billdate` datetime DEFAULT NULL,
  `drcode` varchar(30) DEFAULT NULL,
  `chgcode` varchar(30) DEFAULT NULL,
  `trxdate` datetime DEFAULT NULL,
  `chgamount` decimal(7,2) DEFAULT NULL,
  `origoutamt` decimal(7,2) DEFAULT NULL,
  `newoutamt` decimal(7,2) DEFAULT NULL,
  `epistype` varchar(3) DEFAULT NULL,
  `debtorcode` varchar(30) DEFAULT NULL,
  `billamt` decimal(9,2) DEFAULT NULL,
  `rate` decimal(5,2) DEFAULT NULL,
  `rate2` decimal(7,2) DEFAULT NULL,
  `ceiling` decimal(7,2) DEFAULT NULL,
  `drappamt` decimal(7,2) DEFAULT NULL,
  `drappoutamt` decimal(7,2) DEFAULT NULL,
  `drapppaid` decimal(7,2) DEFAULT NULL,
  `lastuser` varchar(30) DEFAULT NULL,
  `lastupdate` datetime DEFAULT NULL,
  `auditno` int(11) DEFAULT NULL,
  `trantype` varchar(30) DEFAULT NULL,
  `source` varchar(30) DEFAULT NULL,
  `lineno_` int(11) DEFAULT NULL,
  `trandate` datetime DEFAULT NULL,
  `drrefno` varchar(30) DEFAULT NULL,
  `totincome` decimal(7,2) DEFAULT NULL,
  `dramt1` decimal(7,2) DEFAULT NULL,
  `dramt2` decimal(7,2) DEFAULT NULL,
  `invsrc` varchar(30) DEFAULT NULL,
  `invtrtype` varchar(30) DEFAULT NULL,
  `invamount` decimal(7,2) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `drconv`
--

LOCK TABLES `drconv` WRITE;
/*!40000 ALTER TABLE `drconv` DISABLE KEYS */;
/*!40000 ALTER TABLE `drconv` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `drgroup`
--

DROP TABLE IF EXISTS `drgroup`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `drgroup` (
  `compcode` varchar(2) DEFAULT NULL,
  `groupcode` varchar(30) DEFAULT NULL,
  `drcode` varchar(30) DEFAULT NULL,
  `effectdate` datetime DEFAULT NULL,
  `rate` decimal(7,2) DEFAULT NULL,
  `adduser` varchar(30) DEFAULT NULL,
  `adddate` datetime DEFAULT NULL,
  `upduser` varchar(30) DEFAULT NULL,
  `upddate` datetime DEFAULT NULL,
  `name` varchar(40) DEFAULT NULL,
  `income` decimal(9,2) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `drgroup`
--

LOCK TABLES `drgroup` WRITE;
/*!40000 ALTER TABLE `drgroup` DISABLE KEYS */;
/*!40000 ALTER TABLE `drgroup` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `drgrouphdr`
--

DROP TABLE IF EXISTS `drgrouphdr`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `drgrouphdr` (
  `compcode` varchar(2) DEFAULT NULL,
  `groupcode` varchar(30) DEFAULT NULL,
  `name` varchar(40) DEFAULT NULL,
  `effectdate` datetime DEFAULT NULL,
  `adduser` varchar(30) DEFAULT NULL,
  `adddate` datetime DEFAULT NULL,
  `upduser` varchar(30) DEFAULT NULL,
  `upddate` datetime DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `drgrouphdr`
--

LOCK TABLES `drgrouphdr` WRITE;
/*!40000 ALTER TABLE `drgrouphdr` DISABLE KEYS */;
/*!40000 ALTER TABLE `drgrouphdr` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `drgroupincome`
--

DROP TABLE IF EXISTS `drgroupincome`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `drgroupincome` (
  `compcode` varchar(2) DEFAULT NULL,
  `groupcode` varchar(30) DEFAULT NULL,
  `startdate` datetime DEFAULT NULL,
  `procdate` datetime DEFAULT NULL,
  `incomeamt` decimal(7,2) DEFAULT NULL,
  `upduser` varchar(30) DEFAULT NULL,
  `upddate` decimal(7,2) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `drgroupincome`
--

LOCK TABLES `drgroupincome` WRITE;
/*!40000 ALTER TABLE `drgroupincome` DISABLE KEYS */;
/*!40000 ALTER TABLE `drgroupincome` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `drincome`
--

DROP TABLE IF EXISTS `drincome`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `drincome` (
  `compcode` varchar(2) DEFAULT NULL,
  `drcode` varchar(4) DEFAULT NULL,
  `year` int(11) DEFAULT NULL,
  `epistype` varchar(30) DEFAULT NULL,
  `totincome` decimal(7,2) DEFAULT NULL,
  `lastuser` varchar(13) DEFAULT NULL,
  `lastdate` datetime DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `drincome`
--

LOCK TABLES `drincome` WRITE;
/*!40000 ALTER TABLE `drincome` DISABLE KEYS */;
/*!40000 ALTER TABLE `drincome` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `droutdtl`
--

DROP TABLE IF EXISTS `droutdtl`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `droutdtl` (
  `compcode` varchar(2) DEFAULT NULL,
  `drcode` varchar(15) DEFAULT NULL,
  `mrn` int(11) DEFAULT NULL,
  `episno` int(11) DEFAULT NULL,
  `tnauditno` int(11) DEFAULT NULL,
  `procdate` datetime DEFAULT NULL,
  `origchgamt` decimal(7,2) DEFAULT NULL,
  `origchgoutamt` decimal(7,2) DEFAULT NULL,
  `origappros` decimal(7,2) DEFAULT NULL,
  `chgamt` decimal(7,2) DEFAULT NULL,
  `chgoutamt` decimal(7,2) DEFAULT NULL,
  `chgpaid` decimal(7,2) DEFAULT NULL,
  `apprpaid` decimal(7,2) DEFAULT NULL,
  `commamt` decimal(7,2) DEFAULT NULL,
  `appros` decimal(7,2) DEFAULT NULL,
  `lastupdate` datetime DEFAULT NULL,
  `upduser` varchar(30) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `droutdtl`
--

LOCK TABLES `droutdtl` WRITE;
/*!40000 ALTER TABLE `droutdtl` DISABLE KEYS */;
/*!40000 ALTER TABLE `droutdtl` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `drtran`
--

DROP TABLE IF EXISTS `drtran`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `drtran` (
  `compcode` varchar(2) DEFAULT NULL,
  `source` varchar(10) DEFAULT NULL,
  `trantype` varchar(30) DEFAULT NULL,
  `mrn` int(11) DEFAULT NULL,
  `episno` int(11) DEFAULT NULL,
  `billno` int(11) DEFAULT NULL,
  `lineno_` int(11) DEFAULT NULL,
  `auditno` int(11) DEFAULT NULL,
  `drcode` varchar(15) DEFAULT NULL,
  `epistype` varchar(2) DEFAULT NULL,
  `trandate` datetime DEFAULT NULL,
  `invsrc` varchar(2) DEFAULT NULL,
  `invtrtype` varchar(2) DEFAULT NULL,
  `billdate` datetime DEFAULT NULL,
  `drrefno` varchar(20) DEFAULT NULL,
  `chgcode` varchar(30) DEFAULT NULL,
  `chgtrxdate` datetime DEFAULT NULL,
  `chgamount` decimal(12,4) DEFAULT NULL,
  `chgoutamt` decimal(15,4) DEFAULT NULL,
  `invamount` decimal(14,4) DEFAULT NULL,
  `drappamt` decimal(12,4) DEFAULT NULL,
  `drappoutamt` decimal(11,4) DEFAULT NULL,
  `drapppaid` decimal(11,4) DEFAULT NULL,
  `drcontamt` decimal(7,2) DEFAULT NULL,
  `drprcnt` int(11) DEFAULT NULL,
  `lastuser` varchar(13) DEFAULT NULL,
  `lastupddate` datetime DEFAULT NULL,
  `effectdate` datetime DEFAULT NULL,
  `drstfamt` decimal(7,2) DEFAULT NULL,
  `drstfprcnt` decimal(5,2) DEFAULT NULL,
  `debtorcode` varchar(12) DEFAULT NULL,
  `consultflag` tinyint(4) DEFAULT NULL,
  `totincome` decimal(7,2) DEFAULT NULL,
  `drprcnt1` decimal(5,2) DEFAULT NULL,
  `dramt1` decimal(7,2) DEFAULT NULL,
  `drprcnt2` decimal(5,2) DEFAULT NULL,
  `dramt2` decimal(7,2) DEFAULT NULL,
  `invcode` varchar(30) DEFAULT NULL,
  `chggroup` varchar(30) DEFAULT NULL,
  `fullypaid` tinyint(4) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `drtran`
--

LOCK TABLES `drtran` WRITE;
/*!40000 ALTER TABLE `drtran` DISABLE KEYS */;
/*!40000 ALTER TABLE `drtran` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `drtranceilng`
--

DROP TABLE IF EXISTS `drtranceilng`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `drtranceilng` (
  `compcode` varchar(2) DEFAULT NULL,
  `source` varchar(10) DEFAULT NULL,
  `trantype` varchar(30) DEFAULT NULL,
  `mrn` int(11) DEFAULT NULL,
  `episno` int(11) DEFAULT NULL,
  `billno` int(11) DEFAULT NULL,
  `lineno_` int(11) DEFAULT NULL,
  `auditno` int(11) DEFAULT NULL,
  `drcode` varchar(15) DEFAULT NULL,
  `epistype` varchar(2) DEFAULT NULL,
  `trandate` datetime DEFAULT NULL,
  `invsrc` varchar(2) DEFAULT NULL,
  `invtrtype` varchar(2) DEFAULT NULL,
  `billdate` datetime DEFAULT NULL,
  `drrefno` varchar(20) DEFAULT NULL,
  `chgcode` varchar(30) DEFAULT NULL,
  `chgtrxdate` datetime DEFAULT NULL,
  `chgamount` decimal(12,4) DEFAULT NULL,
  `chgoutamt` decimal(15,4) DEFAULT NULL,
  `invamount` decimal(14,4) DEFAULT NULL,
  `drappamt` decimal(12,4) DEFAULT NULL,
  `drappoutamt` decimal(11,4) DEFAULT NULL,
  `drapppaid` decimal(11,4) DEFAULT NULL,
  `drcontamt` decimal(7,2) DEFAULT NULL,
  `drprcnt` int(11) DEFAULT NULL,
  `lastuser` varchar(13) DEFAULT NULL,
  `lastupddate` datetime DEFAULT NULL,
  `effectdate` datetime DEFAULT NULL,
  `drstfamt` decimal(7,2) DEFAULT NULL,
  `drstfprcnt` decimal(5,2) DEFAULT NULL,
  `debtorcode` varchar(12) DEFAULT NULL,
  `consultflag` tinyint(4) DEFAULT NULL,
  `totincome` decimal(7,2) DEFAULT NULL,
  `drprcnt1` decimal(5,2) DEFAULT NULL,
  `dramt1` decimal(7,2) DEFAULT NULL,
  `drprcnt2` decimal(5,2) DEFAULT NULL,
  `dramt2` decimal(7,2) DEFAULT NULL,
  `invcode` varchar(30) DEFAULT NULL,
  `chggroup` varchar(30) DEFAULT NULL,
  `fullypaid` tinyint(4) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `drtranceilng`
--

LOCK TABLES `drtranceilng` WRITE;
/*!40000 ALTER TABLE `drtranceilng` DISABLE KEYS */;
/*!40000 ALTER TABLE `drtranceilng` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `drtranold`
--

DROP TABLE IF EXISTS `drtranold`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `drtranold` (
  `doctorcode` varchar(30) DEFAULT NULL,
  `billno` varchar(30) DEFAULT NULL,
  `amount` decimal(7,2) DEFAULT NULL,
  `epistype` varchar(30) DEFAULT NULL,
  `remark` varchar(30) DEFAULT NULL,
  `csv` varchar(20) DEFAULT NULL,
  `hitsbillno` int(11) DEFAULT NULL,
  `hitslineno` int(11) DEFAULT NULL,
  `newdrcode` varchar(30) DEFAULT NULL,
  `auditno` int(11) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `drtranold`
--

LOCK TABLES `drtranold` WRITE;
/*!40000 ALTER TABLE `drtranold` DISABLE KEYS */;
/*!40000 ALTER TABLE `drtranold` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `forex`
--

DROP TABLE IF EXISTS `forex`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `forex` (
  `idno` int(22) NOT NULL AUTO_INCREMENT,
  `compcode` varchar(30) DEFAULT NULL,
  `forexcode` varchar(30) DEFAULT NULL,
  `rate` decimal(9,4) DEFAULT NULL,
  `adduser` varchar(30) DEFAULT NULL,
  `adddate` datetime DEFAULT NULL,
  `upduser` varchar(30) DEFAULT NULL,
  `upddate` datetime DEFAULT NULL,
  `deluser` varchar(30) DEFAULT NULL,
  `deldate` datetime DEFAULT NULL,
  `recstatus` varchar(10) DEFAULT NULL,
  `effdate` date DEFAULT NULL,
  PRIMARY KEY (`idno`)
) ENGINE=InnoDB AUTO_INCREMENT=4 DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `forex`
--

LOCK TABLES `forex` WRITE;
/*!40000 ALTER TABLE `forex` DISABLE KEYS */;
INSERT INTO `forex` VALUES (1,'9A','GBP',5.2900,'farid','2016-09-13 13:39:28','farid','2016-09-14 17:25:07',NULL,NULL,'ACTIVE','2016-09-01'),(2,'9A','GBP',5.4900,'farid','2016-09-13 13:39:28','farid','2016-09-14 17:14:04',NULL,NULL,'ACTIVE','2016-09-21'),(3,'9A','GBP',5.4901,'farid','2016-09-13 13:39:28','farid','2016-09-14 17:14:28',NULL,NULL,'ACTIVE','2016-10-01');
/*!40000 ALTER TABLE `forex` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `forexmaster`
--

DROP TABLE IF EXISTS `forexmaster`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `forexmaster` (
  `idno` int(11) NOT NULL AUTO_INCREMENT,
  `compcode` varchar(30) DEFAULT NULL,
  `forexcode` varchar(30) DEFAULT NULL,
  `description` varchar(40) DEFAULT NULL,
  `recstatus` varchar(10) DEFAULT NULL,
  `adduser` varchar(30) DEFAULT NULL,
  `adddate` datetime DEFAULT NULL,
  `upduser` varchar(30) DEFAULT NULL,
  `upddate` datetime DEFAULT NULL,
  `deluser` varchar(30) DEFAULT NULL,
  `deldate` datetime DEFAULT NULL,
  `costcode` varchar(30) DEFAULT NULL,
  `glaccount` varchar(30) DEFAULT NULL,
  PRIMARY KEY (`idno`)
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `forexmaster`
--

LOCK TABLES `forexmaster` WRITE;
/*!40000 ALTER TABLE `forexmaster` DISABLE KEYS */;
INSERT INTO `forexmaster` VALUES (1,'9A','GBP','BRITISH POUND STERLING','ACTIVE','farid','2016-09-13 13:35:36',NULL,NULL,NULL,NULL,'1000','50021100');
/*!40000 ALTER TABLE `forexmaster` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `forexmode`
--

DROP TABLE IF EXISTS `forexmode`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `forexmode` (
  `compcode` varchar(2) DEFAULT NULL,
  `forexcode` varchar(30) DEFAULT NULL,
  `paymode` varchar(30) DEFAULT NULL,
  `document` varchar(20) DEFAULT NULL,
  `reference` varchar(20) DEFAULT NULL,
  `remark` varchar(20) DEFAULT NULL,
  `category` varchar(20) DEFAULT NULL,
  `adduser` varchar(30) DEFAULT NULL,
  `adddate` datetime DEFAULT NULL,
  `upduser` varchar(30) DEFAULT NULL,
  `upddate` datetime DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `forexmode`
--

LOCK TABLES `forexmode` WRITE;
/*!40000 ALTER TABLE `forexmode` DISABLE KEYS */;
/*!40000 ALTER TABLE `forexmode` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `forexrate`
--

DROP TABLE IF EXISTS `forexrate`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `forexrate` (
  `compcode` varchar(30) DEFAULT NULL,
  `forexcode` varchar(30) DEFAULT NULL,
  `rate` decimal(9,4) DEFAULT NULL,
  `adduser` varchar(30) DEFAULT NULL,
  `adddate` datetime DEFAULT NULL,
  `upduser` varchar(30) DEFAULT NULL,
  `upddate` datetime DEFAULT NULL,
  `recstatus` varchar(30) DEFAULT NULL,
  `effdate` datetime DEFAULT NULL,
  `rateap` decimal(9,4) DEFAULT NULL,
  `ratebnkdr` decimal(9,4) DEFAULT NULL,
  `ratebnkcr` decimal(9,4) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `forexrate`
--

LOCK TABLES `forexrate` WRITE;
/*!40000 ALTER TABLE `forexrate` DISABLE KEYS */;
/*!40000 ALTER TABLE `forexrate` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `hdrtypmst`
--

DROP TABLE IF EXISTS `hdrtypmst`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `hdrtypmst` (
  `idno` int(11) NOT NULL AUTO_INCREMENT,
  `compcode` varchar(2) DEFAULT NULL,
  `source` varchar(2) DEFAULT NULL,
  `hdrtype` varchar(8) DEFAULT NULL,
  `trantype` varchar(2) DEFAULT NULL,
  `description` varchar(100) DEFAULT NULL,
  `depccode` varchar(5) DEFAULT NULL,
  `depglacc` varchar(30) DEFAULT NULL,
  `updpayername` tinyint(4) DEFAULT NULL,
  `updepisode` tinyint(4) DEFAULT NULL,
  `manualalloc` tinyint(4) DEFAULT NULL,
  `adduser` varchar(30) DEFAULT NULL,
  `adddate` datetime DEFAULT NULL,
  `upduser` varchar(30) DEFAULT NULL,
  `upddate` datetime DEFAULT NULL,
  `recstatus` varchar(10) DEFAULT NULL,
  `deluser` varchar(12) DEFAULT NULL,
  `deldate` datetime DEFAULT NULL,
  `computerid` varchar(20) DEFAULT NULL,
  `ipaddress` varchar(20) DEFAULT NULL,
  `lastcomputerid` varchar(20) DEFAULT NULL,
  `lastipaddress` varchar(20) DEFAULT NULL,
  PRIMARY KEY (`idno`),
  UNIQUE KEY `hdrtypmstUnique` (`compcode`,`trantype`,`idno`)
) ENGINE=InnoDB AUTO_INCREMENT=15 DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `hdrtypmst`
--

LOCK TABLES `hdrtypmst` WRITE;
/*!40000 ALTER TABLE `hdrtypmst` DISABLE KEYS */;
INSERT INTO `hdrtypmst` VALUES (0,'9A','PB','WC','RD','WHEEL CHAIR','1001','50030401',1,0,0,'','0000-00-00 00:00:00','farid','2016-12-07 16:44:28','ACTIVE','farid','2016-07-18 14:35:46','','',NULL,NULL),(11,'9A','PB','ED','RD','EQUIPMENT RENTAL DEPOSIT','1000','50020604',1,1,1,NULL,NULL,'farid','2016-07-18 10:32:15','ACTIVE',NULL,NULL,NULL,NULL,NULL,NULL),(12,'9A','PB','RD','RD','DEPOSIT RECEIVE FROM PATIENT','1003','50030401',0,0,1,'','0000-00-00 00:00:00','farid','2016-12-07 17:09:26','ACTIVE',NULL,NULL,'','',NULL,NULL),(13,'9A','PB','TS','RD','Test DT12','1000','10010000',1,1,1,'farid','2017-07-26 09:53:43','farid','2017-07-27 16:12:17','DEACTIVE','farid','2017-07-31 16:29:06','mira-PC','192.168.0.108','MIRA-PC','192.168.0.101'),(14,'9A','PB','HN','RD','HOME NURSING DEPOSIT','1000','50030401',1,1,1,'farid2','2021-10-29 15:08:20',NULL,NULL,'ACTIVE',NULL,NULL,NULL,NULL,'CHERAS','115.132.166.190');
/*!40000 ALTER TABLE `hdrtypmst` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `patsumepis`
--

DROP TABLE IF EXISTS `patsumepis`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `patsumepis` (
  `idno` int(11) NOT NULL AUTO_INCREMENT,
  `month` varchar(111) DEFAULT NULL,
  `year` varchar(111) DEFAULT NULL,
  `units` varchar(111) DEFAULT NULL,
  `patient` varchar(111) DEFAULT NULL,
  `type` varchar(111) DEFAULT NULL,
  `week1` varchar(111) DEFAULT NULL,
  `week2` varchar(111) DEFAULT NULL,
  `week3` varchar(111) DEFAULT NULL,
  `week4` varchar(111) DEFAULT NULL,
  PRIMARY KEY (`idno`),
  KEY `month` (`month`,`year`,`units`)
) ENGINE=InnoDB AUTO_INCREMENT=91 DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `patsumepis`
--

LOCK TABLES `patsumepis` WRITE;
/*!40000 ALTER TABLE `patsumepis` DISABLE KEYS */;
INSERT INTO `patsumepis` VALUES (1,'7','2021','UKMSC','IP','REV','849978.8499999997','1175415.3499999978','712753.25','891751.6499999991'),(2,'7','2021','KH','IP','REV','0','0','0','0'),(3,'7','2021','IMP','IP','REV','0','0','0','0'),(4,'7','2021','FKL','IP','REV','0','0','0','0'),(5,'7','2021','DENTAL','IP','REV','0','0','0','0'),(6,'7','2021','POLIKLINIK','IP','REV','0','0','0','0'),(7,'7','2021','UKMSC','OP','REV','292450.84999999986','303917.74999999994','240460.94999999987','434053.5000000001'),(8,'7','2021','KH','OP','REV','16398.6','18043.699999999993','13877.149999999994','26074.000000000004'),(9,'7','2021','IMP','OP','REV','26808','18019','3787','6965'),(10,'7','2021','FKL','OP','REV','8736.25','7694.599999999999','11838.900000000001','22067.499999999996'),(11,'7','2021','DENTAL','OP','REV','3095','6040','2150','8767'),(12,'7','2021','POLIKLINIK','OP','REV','5279.9','4224.75','4575.15','4980.200000000001'),(13,'7','2021','FKL','IP','epis','0','0','0','0'),(14,'7','2021','UKMSC','IP','epis','76','91','43','101'),(15,'7','2021','IMP','IP','epis','0','0','0','0'),(16,'7','2021','DENTAL','IP','epis','0','0','0','0'),(17,'7','2021','PHKL','IP','epis','0','0','0','0'),(18,'7','2021','KH','IP','epis','0','0','0','0'),(19,'7','2021','POLIKLINIK','IP','epis','0','0','0','0'),(20,'7','2021','11','IP','epis','0','0','0','0'),(21,'7','2021','GP','IP','epis','0','0','0','0'),(22,'7','2021','FKL','OP','epis','39','36','45','100'),(23,'7','2021','UKMSC','OP','epis','568','647','366','769'),(24,'7','2021','IMP','OP','epis','15','12','2','6'),(25,'7','2021','DENTAL','OP','epis','10','16','10','19'),(26,'7','2021','PHKL','OP','epis','0','0','0','0'),(27,'7','2021','KH','OP','epis','295','298','239','395'),(28,'7','2021','POLIKLINIK','OP','epis','2','1','2','4'),(29,'7','2021','11','OP','epis','0','0','0','0'),(30,'7','2021','GP','OP','epis','0','0','0','0'),(31,'6','2021','UKMSC','IP','REV','854455.5499999999','1008839.1500000001','948358.7499999998','1262781.4000000004'),(32,'6','2021','DENTAL','IP','REV','0','0','0','0'),(33,'6','2021','FKL','IP','REV','0','0','0','0'),(34,'6','2021','IMP','IP','REV','0','0','0','0'),(35,'6','2021','KH','IP','REV','0','0','0','0'),(36,'6','2021','POLIKLINIK','IP','REV','0','0','0','0'),(37,'6','2021','UKMSC','OP','REV','182544.47','340710.85000000003','335532.5','452431.2500000001'),(38,'6','2021','DENTAL','OP','REV','0','0','11862.75','11965'),(39,'6','2021','FKL','OP','REV','7634','11728.599999999999','19783.599999999995','14549.999999999993'),(40,'6','2021','IMP','OP','REV','18920','22702','36550','41016.5'),(41,'6','2021','KH','OP','REV','10344.949999999999','19812.649999999998','15541.499999999993','18054.399999999998'),(42,'6','2021','POLIKLINIK','OP','REV','5617.999999999999','5200.800000000001','7921.500000000001','0'),(43,'6','2021','11','IP','epis','0','0','0','0'),(44,'6','2021','UKMSC','IP','epis','64','89','83','85'),(45,'6','2021','DENTAL','IP','epis','0','0','0','0'),(46,'6','2021','FKL','IP','epis','0','0','0','0'),(47,'6','2021','IMP','IP','epis','0','0','0','0'),(48,'6','2021','KH','IP','epis','0','0','0','0'),(49,'6','2021','POLIKLINIK','IP','epis','0','0','0','0'),(50,'6','2021','GP','IP','epis','0','0','0','0'),(51,'6','2021','PHKL','IP','epis','0','0','0','0'),(52,'6','2021','11','OP','epis','0','0','0','0'),(53,'6','2021','UKMSC','OP','epis','370','650','663','902'),(54,'6','2021','DENTAL','OP','epis','0','0','16','27'),(55,'6','2021','FKL','OP','epis','22','39','69','70'),(56,'6','2021','IMP','OP','epis','13','18','19','18'),(57,'6','2021','KH','OP','epis','222','325','283','400'),(58,'6','2021','POLIKLINIK','OP','epis','2','2','2','2'),(59,'6','2021','GP','OP','epis','0','0','0','0'),(60,'6','2021','PHKL','OP','epis','0','0','0','0'),(61,'5','2021','UKMSC','IP','REV','1291211.7000000016','941323.6499999998','734107.4499999996','1285038.0499999998'),(62,'5','2021','DENTAL','IP','REV','0','0','0','0'),(63,'5','2021','FKL','IP','REV','0','0','0','0'),(64,'5','2021','IMP','IP','REV','0','0','0','0'),(65,'5','2021','KH','IP','REV','0','0','0','0'),(66,'5','2021','POLIKLINIK','IP','REV','0','0','0','0'),(67,'5','2021','UKMSC','OP','REV','240655.69999999984','115244.34999999996','277151.1999999999','332082.39999999997'),(68,'5','2021','DENTAL','OP','REV','7255','3799','8050','4720'),(69,'5','2021','FKL','OP','REV','16714.449999999993','2655.9','15435.999999999996','8250.85'),(70,'5','2021','IMP','OP','REV','34303.5','6651','26326.5','23934.5'),(71,'5','2021','KH','OP','REV','18393.599999999988','11435.799999999997','17890.94999999999','17276.699999999993'),(72,'5','2021','POLIKLINIK','OP','REV','6899.850000000001','2808.6499999999996','5403.2','6876.749999999999'),(73,'5','2021','11','IP','epis','0','0','0','0'),(74,'5','2021','UKMSC','IP','epis','102','51','91','84'),(75,'5','2021','DENTAL','IP','epis','0','0','0','0'),(76,'5','2021','FKL','IP','epis','0','0','0','0'),(77,'5','2021','IMP','IP','epis','0','0','0','0'),(78,'5','2021','KH','IP','epis','0','0','0','0'),(79,'5','2021','POLIKLINIK','IP','epis','0','0','0','0'),(80,'5','2021','GP','IP','epis','0','0','0','0'),(81,'5','2021','PHKL','IP','epis','0','0','0','0'),(82,'5','2021','11','OP','epis','0','0','0','0'),(83,'5','2021','UKMSC','OP','epis','626','289','546','633'),(84,'5','2021','DENTAL','OP','epis','15','11','17','13'),(85,'5','2021','FKL','OP','epis','88','24','80','40'),(86,'5','2021','IMP','OP','epis','14','1','19','10'),(87,'5','2021','KH','OP','epis','319','176','289','322'),(88,'5','2021','POLIKLINIK','OP','epis','2','1','2','3'),(89,'5','2021','GP','OP','epis','0','0','0','0'),(90,'5','2021','PHKL','OP','epis','0','0','0','0');
/*!40000 ALTER TABLE `patsumepis` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `patsumrev`
--

DROP TABLE IF EXISTS `patsumrev`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `patsumrev` (
  `idno` int(11) NOT NULL AUTO_INCREMENT,
  `month` varchar(111) DEFAULT NULL,
  `year` varchar(111) DEFAULT NULL,
  `units` varchar(111) DEFAULT NULL,
  `group` varchar(111) DEFAULT NULL,
  `ipcnt` varchar(111) DEFAULT NULL,
  `opcnt` varchar(111) DEFAULT NULL,
  `ipsum` varchar(111) DEFAULT NULL,
  `opsum` varchar(111) DEFAULT NULL,
  `totalsum` varchar(111) DEFAULT NULL,
  PRIMARY KEY (`idno`),
  KEY `month` (`month`,`year`,`units`)
) ENGINE=InnoDB AUTO_INCREMENT=577 DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `patsumrev`
--

LOCK TABLES `patsumrev` WRITE;
/*!40000 ALTER TABLE `patsumrev` DISABLE KEYS */;
INSERT INTO `patsumrev` VALUES (1,'7','2021','UKMSC','CLINIC CHARGES','202','378','34174.43999999999','108026.29000000001','142200.72999999998'),(2,'7','2021','UKMSC','DISPOSABLE','1904','808','207750.72000000026','28498.72000000001','236249.44000000026'),(3,'7','2021','UKMSC','PHARMACY','1614','1564','583558.3999999999','414640.72999999986','998199.1299999998'),(4,'7','2021','UKMSC','ROOM','152','0','161049.5','0','161049.5'),(5,'7','2021','UKMSC','RADIOLOGY','178','196','66697.2','87484.5','154181.7'),(6,'7','2021','UKMSC','OT CHARGES','117','0','155555.8','0','155555.8'),(7,'7','2021','UKMSC','IMPLANT/CONSIGNMENT','194','0','390545','0','390545'),(8,'7','2021','UKMSC','DOCTOR FEES','769','705','1191228.6400000001','303844','1495072.6400000001'),(9,'7','2021','UKMSC','OT DISPOSABLE','1960','6','206128.44999999978','47','206175.44999999978'),(10,'7','2021','UKMSC','OT HOURS','128','0','140366','0','140366'),(11,'7','2021','UKMSC','PHYSIOTHERAPHY','50','10','10330','965','11295'),(12,'7','2021','UKMSC','LABORATORY','728','759','149532.73','69528.73','219061.46000000002'),(13,'7','2021','UKMSC','WARD CHARGES','659','11','219371.6','1724','221095.6'),(14,'7','2021','UKMSC','MAC Procedure','29','126','89705','267218','356923'),(15,'7','2021','UKMSC','K HEALTH','2','0','2254','0','2254'),(16,'7','2021','UKMSC','AUDIOLOGY','18','34','1920','5820','7740'),(17,'7','2021','UKMSC','INFANT CHARGES','103','0','7465.760000000001','0','7465.760000000001'),(18,'7','2021','UKMSC','ICU DISPOSABLE','329','2','16058.769999999999','0','16058.769999999999'),(19,'7','2021','UKMSC','EQUIPMENT/INSTRUMENT','53','26','44013.4','14396','58409.4'),(20,'7','2021','UKMSC','RESPIRATORY','4','6','7644','894','8538'),(21,'7','2021','UKMSC','NEUCLEAR','6','2','16189.06','8649.08','24838.14'),(22,'7','2021','UKMSC','SPEECH THERAPY','0','0','0','0','0'),(23,'7','2021','UKMSC','OPHTHALMOLOGY','0','40','0','4352.400000000001','4352.400000000001'),(24,'7','2021','UKMSC','DERMATOLOGY','0','2','0','200','200'),(25,'7','2021','UKMSC','PHARMACY KL','0','0','0','0','0'),(26,'7','2021','UKMSC','OCCUPATIONAL THERAPY','0','3','0','195','195'),(27,'7','2021','UKMSC','POLIKLINIK','0','0','0','0','0'),(28,'7','2021','UKMSC','RADIOTERAPHY','20','19','11230','17560','28790'),(29,'7','2021','UKMSC','MAXILOFACIAL','1','0','312','0','312'),(30,'7','2021','UKMSC','GAMMA KNIFE CENTRE','69','0','94895.88','0','94895.88'),(31,'7','2021','UKMSC',NULL,'0','0','0','0','0'),(32,'7','2021','UKMSC','CELL THERAPHY','1','0','5400','0','5400'),(33,'7','2021','KH','CLINIC CHARGES','0','15','0','-0.25999999999999995','-0.25999999999999995'),(34,'7','2021','KH','DISPOSABLE','0','0','0','0','0'),(35,'7','2021','KH','PHARMACY','0','0','0','0','0'),(36,'7','2021','KH','ROOM','0','0','0','0','0'),(37,'7','2021','KH','RADIOLOGY','0','0','0','0','0'),(38,'7','2021','KH','OT CHARGES','0','0','0','0','0'),(39,'7','2021','KH','IMPLANT/CONSIGNMENT','0','0','0','0','0'),(40,'7','2021','KH','DOCTOR FEES','0','0','0','0','0'),(41,'7','2021','KH','OT DISPOSABLE','0','0','0','0','0'),(42,'7','2021','KH','OT HOURS','0','0','0','0','0'),(43,'7','2021','KH','PHYSIOTHERAPHY','0','0','0','0','0'),(44,'7','2021','KH','LABORATORY','0','0','0','0','0'),(45,'7','2021','KH','WARD CHARGES','0','0','0','0','0'),(46,'7','2021','KH','MAC Procedure','0','0','0','0','0'),(47,'7','2021','KH','K HEALTH','0','1224','0','79398.01000000005','79398.01000000005'),(48,'7','2021','KH','AUDIOLOGY','0','0','0','0','0'),(49,'7','2021','KH','INFANT CHARGES','0','0','0','0','0'),(50,'7','2021','KH','ICU DISPOSABLE','0','0','0','0','0'),(51,'7','2021','KH','EQUIPMENT/INSTRUMENT','0','0','0','0','0'),(52,'7','2021','KH','RESPIRATORY','0','0','0','0','0'),(53,'7','2021','KH','NEUCLEAR','0','0','0','0','0'),(54,'7','2021','KH','SPEECH THERAPY','0','0','0','0','0'),(55,'7','2021','KH','OPHTHALMOLOGY','0','0','0','0','0'),(56,'7','2021','KH','DERMATOLOGY','0','0','0','0','0'),(57,'7','2021','KH','PHARMACY KL','0','0','0','0','0'),(58,'7','2021','KH','OCCUPATIONAL THERAPY','0','0','0','0','0'),(59,'7','2021','KH','POLIKLINIK','0','0','0','0','0'),(60,'7','2021','KH','RADIOTERAPHY','0','0','0','0','0'),(61,'7','2021','KH','MAXILOFACIAL','0','0','0','0','0'),(62,'7','2021','KH','GAMMA KNIFE CENTRE','0','0','0','0','0'),(63,'7','2021','KH',NULL,'0','0','0','0','0'),(64,'7','2021','KH','CELL THERAPHY','0','0','0','0','0'),(65,'7','2021','IMP','CLINIC CHARGES','0','0','0','0','0'),(66,'7','2021','IMP','DISPOSABLE','0','0','0','0','0'),(67,'7','2021','IMP','PHARMACY','0','0','0','0','0'),(68,'7','2021','IMP','ROOM','0','0','0','0','0'),(69,'7','2021','IMP','RADIOLOGY','0','0','0','0','0'),(70,'7','2021','IMP','OT CHARGES','0','0','0','0','0'),(71,'7','2021','IMP','IMPLANT/CONSIGNMENT','0','92','0','57233.5','57233.5'),(72,'7','2021','IMP','DOCTOR FEES','0','0','0','0','0'),(73,'7','2021','IMP','OT DISPOSABLE','0','0','0','0','0'),(74,'7','2021','IMP','OT HOURS','0','0','0','0','0'),(75,'7','2021','IMP','PHYSIOTHERAPHY','0','0','0','0','0'),(76,'7','2021','IMP','LABORATORY','0','0','0','0','0'),(77,'7','2021','IMP','WARD CHARGES','0','0','0','0','0'),(78,'7','2021','IMP','MAC Procedure','0','0','0','0','0'),(79,'7','2021','IMP','K HEALTH','0','0','0','0','0'),(80,'7','2021','IMP','AUDIOLOGY','0','0','0','0','0'),(81,'7','2021','IMP','INFANT CHARGES','0','0','0','0','0'),(82,'7','2021','IMP','ICU DISPOSABLE','0','0','0','0','0'),(83,'7','2021','IMP','EQUIPMENT/INSTRUMENT','0','0','0','0','0'),(84,'7','2021','IMP','RESPIRATORY','0','0','0','0','0'),(85,'7','2021','IMP','NEUCLEAR','0','0','0','0','0'),(86,'7','2021','IMP','SPEECH THERAPY','0','0','0','0','0'),(87,'7','2021','IMP','OPHTHALMOLOGY','0','0','0','0','0'),(88,'7','2021','IMP','DERMATOLOGY','0','0','0','0','0'),(89,'7','2021','IMP','PHARMACY KL','0','0','0','0','0'),(90,'7','2021','IMP','OCCUPATIONAL THERAPY','0','0','0','0','0'),(91,'7','2021','IMP','POLIKLINIK','0','0','0','0','0'),(92,'7','2021','IMP','RADIOTERAPHY','0','0','0','0','0'),(93,'7','2021','IMP','MAXILOFACIAL','0','0','0','0','0'),(94,'7','2021','IMP','GAMMA KNIFE CENTRE','0','0','0','0','0'),(95,'7','2021','IMP',NULL,'0','0','0','0','0'),(96,'7','2021','IMP','CELL THERAPHY','0','0','0','0','0'),(97,'7','2021','FKL','CLINIC CHARGES','0','4','0','-0.03','-0.03'),(98,'7','2021','FKL','DISPOSABLE','0','0','0','0','0'),(99,'7','2021','FKL','PHARMACY','0','0','0','0','0'),(100,'7','2021','FKL','ROOM','0','0','0','0','0'),(101,'7','2021','FKL','RADIOLOGY','0','0','0','0','0'),(102,'7','2021','FKL','OT CHARGES','0','0','0','0','0'),(103,'7','2021','FKL','IMPLANT/CONSIGNMENT','0','0','0','0','0'),(104,'7','2021','FKL','DOCTOR FEES','0','0','0','0','0'),(105,'7','2021','FKL','OT DISPOSABLE','0','0','0','0','0'),(106,'7','2021','FKL','OT HOURS','0','0','0','0','0'),(107,'7','2021','FKL','PHYSIOTHERAPHY','0','0','0','0','0'),(108,'7','2021','FKL','LABORATORY','0','0','0','0','0'),(109,'7','2021','FKL','WARD CHARGES','0','0','0','0','0'),(110,'7','2021','FKL','MAC Procedure','0','0','0','0','0'),(111,'7','2021','FKL','K HEALTH','0','4','0','985.6999999999999','985.6999999999999'),(112,'7','2021','FKL','AUDIOLOGY','0','0','0','0','0'),(113,'7','2021','FKL','INFANT CHARGES','0','0','0','0','0'),(114,'7','2021','FKL','ICU DISPOSABLE','0','0','0','0','0'),(115,'7','2021','FKL','EQUIPMENT/INSTRUMENT','0','0','0','0','0'),(116,'7','2021','FKL','RESPIRATORY','0','0','0','0','0'),(117,'7','2021','FKL','NEUCLEAR','0','0','0','0','0'),(118,'7','2021','FKL','SPEECH THERAPY','0','0','0','0','0'),(119,'7','2021','FKL','OPHTHALMOLOGY','0','0','0','0','0'),(120,'7','2021','FKL','DERMATOLOGY','0','0','0','0','0'),(121,'7','2021','FKL','PHARMACY KL','0','249','0','51045.480000000025','51045.480000000025'),(122,'7','2021','FKL','OCCUPATIONAL THERAPY','0','0','0','0','0'),(123,'7','2021','FKL','POLIKLINIK','0','0','0','0','0'),(124,'7','2021','FKL','RADIOTERAPHY','0','0','0','0','0'),(125,'7','2021','FKL','MAXILOFACIAL','0','0','0','0','0'),(126,'7','2021','FKL','GAMMA KNIFE CENTRE','0','0','0','0','0'),(127,'7','2021','FKL',NULL,'0','0','0','0','0'),(128,'7','2021','FKL','CELL THERAPHY','0','0','0','0','0'),(129,'7','2021','DENTAL','CLINIC CHARGES','0','12','0','1180','1180'),(130,'7','2021','DENTAL','DISPOSABLE','0','0','0','0','0'),(131,'7','2021','DENTAL','PHARMACY','0','0','0','0','0'),(132,'7','2021','DENTAL','ROOM','0','0','0','0','0'),(133,'7','2021','DENTAL','RADIOLOGY','0','0','0','0','0'),(134,'7','2021','DENTAL','OT CHARGES','0','0','0','0','0'),(135,'7','2021','DENTAL','IMPLANT/CONSIGNMENT','0','0','0','0','0'),(136,'7','2021','DENTAL','DOCTOR FEES','0','26','0','21580','21580'),(137,'7','2021','DENTAL','OT DISPOSABLE','0','0','0','0','0'),(138,'7','2021','DENTAL','OT HOURS','0','0','0','0','0'),(139,'7','2021','DENTAL','PHYSIOTHERAPHY','0','0','0','0','0'),(140,'7','2021','DENTAL','LABORATORY','0','0','0','0','0'),(141,'7','2021','DENTAL','WARD CHARGES','0','0','0','0','0'),(142,'7','2021','DENTAL','MAC Procedure','0','0','0','0','0'),(143,'7','2021','DENTAL','K HEALTH','0','0','0','0','0'),(144,'7','2021','DENTAL','AUDIOLOGY','0','0','0','0','0'),(145,'7','2021','DENTAL','INFANT CHARGES','0','0','0','0','0'),(146,'7','2021','DENTAL','ICU DISPOSABLE','0','0','0','0','0'),(147,'7','2021','DENTAL','EQUIPMENT/INSTRUMENT','0','0','0','0','0'),(148,'7','2021','DENTAL','RESPIRATORY','0','0','0','0','0'),(149,'7','2021','DENTAL','NEUCLEAR','0','0','0','0','0'),(150,'7','2021','DENTAL','SPEECH THERAPY','0','0','0','0','0'),(151,'7','2021','DENTAL','OPHTHALMOLOGY','0','0','0','0','0'),(152,'7','2021','DENTAL','DERMATOLOGY','0','0','0','0','0'),(153,'7','2021','DENTAL','PHARMACY KL','0','1','0','7','7'),(154,'7','2021','DENTAL','OCCUPATIONAL THERAPY','0','0','0','0','0'),(155,'7','2021','DENTAL','POLIKLINIK','0','0','0','0','0'),(156,'7','2021','DENTAL','RADIOTERAPHY','0','0','0','0','0'),(157,'7','2021','DENTAL','MAXILOFACIAL','0','0','0','0','0'),(158,'7','2021','DENTAL','GAMMA KNIFE CENTRE','0','0','0','0','0'),(159,'7','2021','DENTAL',NULL,'0','0','0','0','0'),(160,'7','2021','DENTAL','CELL THERAPHY','0','0','0','0','0'),(161,'7','2021','POLIKLINIK','CLINIC CHARGES','0','4','0','0.02','0.02'),(162,'7','2021','POLIKLINIK','DISPOSABLE','0','20','0','755.2','755.2'),(163,'7','2021','POLIKLINIK','PHARMACY','0','123','0','10056.590000000002','10056.590000000002'),(164,'7','2021','POLIKLINIK','ROOM','0','0','0','0','0'),(165,'7','2021','POLIKLINIK','RADIOLOGY','0','0','0','0','0'),(166,'7','2021','POLIKLINIK','OT CHARGES','0','0','0','0','0'),(167,'7','2021','POLIKLINIK','IMPLANT/CONSIGNMENT','0','0','0','0','0'),(168,'7','2021','POLIKLINIK','DOCTOR FEES','0','0','0','0','0'),(169,'7','2021','POLIKLINIK','OT DISPOSABLE','0','0','0','0','0'),(170,'7','2021','POLIKLINIK','OT HOURS','0','0','0','0','0'),(171,'7','2021','POLIKLINIK','PHYSIOTHERAPHY','0','0','0','0','0'),(172,'7','2021','POLIKLINIK','LABORATORY','0','0','0','0','0'),(173,'7','2021','POLIKLINIK','WARD CHARGES','0','0','0','0','0'),(174,'7','2021','POLIKLINIK','MAC Procedure','0','0','0','0','0'),(175,'7','2021','POLIKLINIK','K HEALTH','0','0','0','0','0'),(176,'7','2021','POLIKLINIK','AUDIOLOGY','0','0','0','0','0'),(177,'7','2021','POLIKLINIK','INFANT CHARGES','0','0','0','0','0'),(178,'7','2021','POLIKLINIK','ICU DISPOSABLE','0','0','0','0','0'),(179,'7','2021','POLIKLINIK','EQUIPMENT/INSTRUMENT','0','0','0','0','0'),(180,'7','2021','POLIKLINIK','RESPIRATORY','0','0','0','0','0'),(181,'7','2021','POLIKLINIK','NEUCLEAR','0','0','0','0','0'),(182,'7','2021','POLIKLINIK','SPEECH THERAPY','0','0','0','0','0'),(183,'7','2021','POLIKLINIK','OPHTHALMOLOGY','0','0','0','0','0'),(184,'7','2021','POLIKLINIK','DERMATOLOGY','0','0','0','0','0'),(185,'7','2021','POLIKLINIK','PHARMACY KL','0','0','0','0','0'),(186,'7','2021','POLIKLINIK','OCCUPATIONAL THERAPY','0','0','0','0','0'),(187,'7','2021','POLIKLINIK','POLIKLINIK','0','60','0','8248.19','8248.19'),(188,'7','2021','POLIKLINIK','RADIOTERAPHY','0','0','0','0','0'),(189,'7','2021','POLIKLINIK','MAXILOFACIAL','0','0','0','0','0'),(190,'7','2021','POLIKLINIK','GAMMA KNIFE CENTRE','0','0','0','0','0'),(191,'7','2021','POLIKLINIK',NULL,'0','0','0','0','0'),(192,'7','2021','POLIKLINIK','CELL THERAPHY','0','0','0','0','0'),(193,'6','2021','UKMSC','CLINIC CHARGES','204','436','40126.659999999996','126722.37','166849.03'),(194,'6','2021','UKMSC','DISPOSABLE','2023','919','244461.1899999997','30285.550000000032','274746.73999999976'),(195,'6','2021','UKMSC','PHARMACY','1605','1708','435727.41000000015','418997.10000000003','854724.5100000002'),(196,'6','2021','UKMSC','ROOM','149','0','183911.5','0','183911.5'),(197,'6','2021','UKMSC','RADIOLOGY','209','222','70803.42','97250.1','168053.52000000002'),(198,'6','2021','UKMSC','OT CHARGES','114','0','173682.7','0','173682.7'),(199,'6','2021','UKMSC','IMPLANT/CONSIGNMENT','271','0','578899.5','0','578899.5'),(200,'6','2021','UKMSC','DOCTOR FEES','896','742','1394966.4','314323','1709289.4'),(201,'6','2021','UKMSC','OT DISPOSABLE','1958','1','243538.66000000003','1','243539.66000000003'),(202,'6','2021','UKMSC','OT HOURS','130','0','145375','0','145375'),(203,'6','2021','UKMSC','PHYSIOTHERAPHY','74','18','19441.5','2325','21766.5'),(204,'6','2021','UKMSC','LABORATORY','719','828','164804.21999999997','99949.3','264753.51999999996'),(205,'6','2021','UKMSC','WARD CHARGES','658','9','262147.5','1603','263750.5'),(206,'6','2021','UKMSC','MAC Procedure','23','117','66070','230953','297023'),(207,'6','2021','UKMSC','K HEALTH','2','0','3740','0','3740'),(208,'6','2021','UKMSC','AUDIOLOGY','13','23','1400','3675','5075'),(209,'6','2021','UKMSC','INFANT CHARGES','63','0','4089.92','0','4089.92'),(210,'6','2021','UKMSC','ICU DISPOSABLE','363','0','21333.520000000008','0','21333.520000000008'),(211,'6','2021','UKMSC','EQUIPMENT/INSTRUMENT','55','26','38911','14579','53490'),(212,'6','2021','UKMSC','RESPIRATORY','6','0','4293','0','4293'),(213,'6','2021','UKMSC','NEUCLEAR','5','2','9495.509999999998','7783.2','17278.71'),(214,'6','2021','UKMSC','SPEECH THERAPY','0','4','0','425','425'),(215,'6','2021','UKMSC','OPHTHALMOLOGY','1','26','187.2','2480.3999999999996','2667.5999999999995'),(216,'6','2021','UKMSC','DERMATOLOGY','0','1','0','500','500'),(217,'6','2021','UKMSC','PHARMACY KL','0','0','0','0','0'),(218,'6','2021','UKMSC','OCCUPATIONAL THERAPY','0','0','0','0','0'),(219,'6','2021','UKMSC','POLIKLINIK','0','0','0','0','0'),(220,'6','2021','UKMSC','RADIOTERAPHY','12','8','10130','11000','21130'),(221,'6','2021','UKMSC','MAXILOFACIAL','0','0','0','0','0'),(222,'6','2021','UKMSC','GAMMA KNIFE CENTRE','70','0','112631.14','0','112631.14'),(223,'6','2021','UKMSC',NULL,'0','0','0','0','0'),(224,'6','2021','UKMSC','CELL THERAPHY','0','0','0','0','0'),(225,'6','2021','DENTAL','CLINIC CHARGES','0','8','0','760','760'),(226,'6','2021','DENTAL','DISPOSABLE','0','0','0','0','0'),(227,'6','2021','DENTAL','PHARMACY','0','0','0','0','0'),(228,'6','2021','DENTAL','ROOM','0','0','0','0','0'),(229,'6','2021','DENTAL','RADIOLOGY','0','0','0','0','0'),(230,'6','2021','DENTAL','OT CHARGES','0','0','0','0','0'),(231,'6','2021','DENTAL','IMPLANT/CONSIGNMENT','0','0','0','0','0'),(232,'6','2021','DENTAL','DOCTOR FEES','0','22','0','23067.75','23067.75'),(233,'6','2021','DENTAL','OT DISPOSABLE','0','0','0','0','0'),(234,'6','2021','DENTAL','OT HOURS','0','0','0','0','0'),(235,'6','2021','DENTAL','PHYSIOTHERAPHY','0','0','0','0','0'),(236,'6','2021','DENTAL','LABORATORY','0','0','0','0','0'),(237,'6','2021','DENTAL','WARD CHARGES','0','0','0','0','0'),(238,'6','2021','DENTAL','MAC Procedure','0','0','0','0','0'),(239,'6','2021','DENTAL','K HEALTH','0','0','0','0','0'),(240,'6','2021','DENTAL','AUDIOLOGY','0','0','0','0','0'),(241,'6','2021','DENTAL','INFANT CHARGES','0','0','0','0','0'),(242,'6','2021','DENTAL','ICU DISPOSABLE','0','0','0','0','0'),(243,'6','2021','DENTAL','EQUIPMENT/INSTRUMENT','0','0','0','0','0'),(244,'6','2021','DENTAL','RESPIRATORY','0','0','0','0','0'),(245,'6','2021','DENTAL','NEUCLEAR','0','0','0','0','0'),(246,'6','2021','DENTAL','SPEECH THERAPY','0','0','0','0','0'),(247,'6','2021','DENTAL','OPHTHALMOLOGY','0','0','0','0','0'),(248,'6','2021','DENTAL','DERMATOLOGY','0','0','0','0','0'),(249,'6','2021','DENTAL','PHARMACY KL','0','0','0','0','0'),(250,'6','2021','DENTAL','OCCUPATIONAL THERAPY','0','0','0','0','0'),(251,'6','2021','DENTAL','POLIKLINIK','0','0','0','0','0'),(252,'6','2021','DENTAL','RADIOTERAPHY','0','0','0','0','0'),(253,'6','2021','DENTAL','MAXILOFACIAL','0','0','0','0','0'),(254,'6','2021','DENTAL','GAMMA KNIFE CENTRE','0','0','0','0','0'),(255,'6','2021','DENTAL',NULL,'0','0','0','0','0'),(256,'6','2021','DENTAL','CELL THERAPHY','0','0','0','0','0'),(257,'6','2021','FKL','CLINIC CHARGES','0','5','0','0.01','0.01'),(258,'6','2021','FKL','DISPOSABLE','0','0','0','0','0'),(259,'6','2021','FKL','PHARMACY','0','0','0','0','0'),(260,'6','2021','FKL','ROOM','0','0','0','0','0'),(261,'6','2021','FKL','RADIOLOGY','0','0','0','0','0'),(262,'6','2021','FKL','OT CHARGES','0','0','0','0','0'),(263,'6','2021','FKL','IMPLANT/CONSIGNMENT','0','0','0','0','0'),(264,'6','2021','FKL','DOCTOR FEES','0','0','0','0','0'),(265,'6','2021','FKL','OT DISPOSABLE','0','0','0','0','0'),(266,'6','2021','FKL','OT HOURS','0','0','0','0','0'),(267,'6','2021','FKL','PHYSIOTHERAPHY','0','0','0','0','0'),(268,'6','2021','FKL','LABORATORY','0','0','0','0','0'),(269,'6','2021','FKL','WARD CHARGES','0','0','0','0','0'),(270,'6','2021','FKL','MAC Procedure','0','0','0','0','0'),(271,'6','2021','FKL','K HEALTH','0','7','0','837.3000000000001','837.3000000000001'),(272,'6','2021','FKL','AUDIOLOGY','0','0','0','0','0'),(273,'6','2021','FKL','INFANT CHARGES','0','0','0','0','0'),(274,'6','2021','FKL','ICU DISPOSABLE','0','0','0','0','0'),(275,'6','2021','FKL','EQUIPMENT/INSTRUMENT','0','0','0','0','0'),(276,'6','2021','FKL','RESPIRATORY','0','0','0','0','0'),(277,'6','2021','FKL','NEUCLEAR','0','0','0','0','0'),(278,'6','2021','FKL','SPEECH THERAPY','0','0','0','0','0'),(279,'6','2021','FKL','OPHTHALMOLOGY','0','0','0','0','0'),(280,'6','2021','FKL','DERMATOLOGY','0','0','0','0','0'),(281,'6','2021','FKL','PHARMACY KL','0','289','0','54524.49000000004','54524.49000000004'),(282,'6','2021','FKL','OCCUPATIONAL THERAPY','0','0','0','0','0'),(283,'6','2021','FKL','POLIKLINIK','0','0','0','0','0'),(284,'6','2021','FKL','RADIOTERAPHY','0','0','0','0','0'),(285,'6','2021','FKL','MAXILOFACIAL','0','0','0','0','0'),(286,'6','2021','FKL','GAMMA KNIFE CENTRE','0','0','0','0','0'),(287,'6','2021','FKL',NULL,'0','0','0','0','0'),(288,'6','2021','FKL','CELL THERAPHY','0','0','0','0','0'),(289,'6','2021','IMP','CLINIC CHARGES','0','0','0','0','0'),(290,'6','2021','IMP','DISPOSABLE','0','0','0','0','0'),(291,'6','2021','IMP','PHARMACY','0','0','0','0','0'),(292,'6','2021','IMP','ROOM','0','0','0','0','0'),(293,'6','2021','IMP','RADIOLOGY','0','0','0','0','0'),(294,'6','2021','IMP','OT CHARGES','0','0','0','0','0'),(295,'6','2021','IMP','IMPLANT/CONSIGNMENT','0','202','0','123118','123118'),(296,'6','2021','IMP','DOCTOR FEES','0','0','0','0','0'),(297,'6','2021','IMP','OT DISPOSABLE','0','0','0','0','0'),(298,'6','2021','IMP','OT HOURS','0','0','0','0','0'),(299,'6','2021','IMP','PHYSIOTHERAPHY','0','0','0','0','0'),(300,'6','2021','IMP','LABORATORY','0','0','0','0','0'),(301,'6','2021','IMP','WARD CHARGES','0','0','0','0','0'),(302,'6','2021','IMP','MAC Procedure','0','0','0','0','0'),(303,'6','2021','IMP','K HEALTH','0','0','0','0','0'),(304,'6','2021','IMP','AUDIOLOGY','0','0','0','0','0'),(305,'6','2021','IMP','INFANT CHARGES','0','0','0','0','0'),(306,'6','2021','IMP','ICU DISPOSABLE','0','0','0','0','0'),(307,'6','2021','IMP','EQUIPMENT/INSTRUMENT','0','0','0','0','0'),(308,'6','2021','IMP','RESPIRATORY','0','0','0','0','0'),(309,'6','2021','IMP','NEUCLEAR','0','0','0','0','0'),(310,'6','2021','IMP','SPEECH THERAPY','0','0','0','0','0'),(311,'6','2021','IMP','OPHTHALMOLOGY','0','0','0','0','0'),(312,'6','2021','IMP','DERMATOLOGY','0','0','0','0','0'),(313,'6','2021','IMP','PHARMACY KL','0','0','0','0','0'),(314,'6','2021','IMP','OCCUPATIONAL THERAPY','0','0','0','0','0'),(315,'6','2021','IMP','POLIKLINIK','0','0','0','0','0'),(316,'6','2021','IMP','RADIOTERAPHY','0','0','0','0','0'),(317,'6','2021','IMP','MAXILOFACIAL','0','0','0','0','0'),(318,'6','2021','IMP','GAMMA KNIFE CENTRE','0','0','0','0','0'),(319,'6','2021','IMP',NULL,'0','0','0','0','0'),(320,'6','2021','IMP','CELL THERAPHY','0','0','0','0','0'),(321,'6','2021','KH','CLINIC CHARGES','0','20','0','-0.39','-0.39'),(322,'6','2021','KH','DISPOSABLE','0','0','0','0','0'),(323,'6','2021','KH','PHARMACY','0','0','0','0','0'),(324,'6','2021','KH','ROOM','0','0','0','0','0'),(325,'6','2021','KH','RADIOLOGY','0','0','0','0','0'),(326,'6','2021','KH','OT CHARGES','0','0','0','0','0'),(327,'6','2021','KH','IMPLANT/CONSIGNMENT','0','0','0','0','0'),(328,'6','2021','KH','DOCTOR FEES','0','0','0','0','0'),(329,'6','2021','KH','OT DISPOSABLE','0','0','0','0','0'),(330,'6','2021','KH','OT HOURS','0','0','0','0','0'),(331,'6','2021','KH','PHYSIOTHERAPHY','0','0','0','0','0'),(332,'6','2021','KH','LABORATORY','0','0','0','0','0'),(333,'6','2021','KH','WARD CHARGES','0','0','0','0','0'),(334,'6','2021','KH','MAC Procedure','0','0','0','0','0'),(335,'6','2021','KH','K HEALTH','0','1172','0','65549.7900000001','65549.7900000001'),(336,'6','2021','KH','AUDIOLOGY','0','0','0','0','0'),(337,'6','2021','KH','INFANT CHARGES','0','0','0','0','0'),(338,'6','2021','KH','ICU DISPOSABLE','0','0','0','0','0'),(339,'6','2021','KH','EQUIPMENT/INSTRUMENT','0','0','0','0','0'),(340,'6','2021','KH','RESPIRATORY','0','0','0','0','0'),(341,'6','2021','KH','NEUCLEAR','0','0','0','0','0'),(342,'6','2021','KH','SPEECH THERAPY','0','0','0','0','0'),(343,'6','2021','KH','OPHTHALMOLOGY','0','0','0','0','0'),(344,'6','2021','KH','DERMATOLOGY','0','0','0','0','0'),(345,'6','2021','KH','PHARMACY KL','0','0','0','0','0'),(346,'6','2021','KH','OCCUPATIONAL THERAPY','0','0','0','0','0'),(347,'6','2021','KH','POLIKLINIK','0','0','0','0','0'),(348,'6','2021','KH','RADIOTERAPHY','0','0','0','0','0'),(349,'6','2021','KH','MAXILOFACIAL','0','0','0','0','0'),(350,'6','2021','KH','GAMMA KNIFE CENTRE','0','0','0','0','0'),(351,'6','2021','KH',NULL,'0','0','0','0','0'),(352,'6','2021','KH','CELL THERAPHY','0','0','0','0','0'),(353,'6','2021','POLIKLINIK','CLINIC CHARGES','0','2','0','0.02','0.02'),(354,'6','2021','POLIKLINIK','DISPOSABLE','0','18','0','685.0500000000001','685.0500000000001'),(355,'6','2021','POLIKLINIK','PHARMACY','0','127','0','10359.180000000002','10359.180000000002'),(356,'6','2021','POLIKLINIK','ROOM','0','0','0','0','0'),(357,'6','2021','POLIKLINIK','RADIOLOGY','0','0','0','0','0'),(358,'6','2021','POLIKLINIK','OT CHARGES','0','0','0','0','0'),(359,'6','2021','POLIKLINIK','IMPLANT/CONSIGNMENT','0','0','0','0','0'),(360,'6','2021','POLIKLINIK','DOCTOR FEES','0','0','0','0','0'),(361,'6','2021','POLIKLINIK','OT DISPOSABLE','0','0','0','0','0'),(362,'6','2021','POLIKLINIK','OT HOURS','0','0','0','0','0'),(363,'6','2021','POLIKLINIK','PHYSIOTHERAPHY','0','0','0','0','0'),(364,'6','2021','POLIKLINIK','LABORATORY','0','0','0','0','0'),(365,'6','2021','POLIKLINIK','WARD CHARGES','0','0','0','0','0'),(366,'6','2021','POLIKLINIK','MAC Procedure','0','0','0','0','0'),(367,'6','2021','POLIKLINIK','K HEALTH','0','0','0','0','0'),(368,'6','2021','POLIKLINIK','AUDIOLOGY','0','0','0','0','0'),(369,'6','2021','POLIKLINIK','INFANT CHARGES','0','0','0','0','0'),(370,'6','2021','POLIKLINIK','ICU DISPOSABLE','0','0','0','0','0'),(371,'6','2021','POLIKLINIK','EQUIPMENT/INSTRUMENT','0','0','0','0','0'),(372,'6','2021','POLIKLINIK','RESPIRATORY','0','0','0','0','0'),(373,'6','2021','POLIKLINIK','NEUCLEAR','0','0','0','0','0'),(374,'6','2021','POLIKLINIK','SPEECH THERAPY','0','0','0','0','0'),(375,'6','2021','POLIKLINIK','OPHTHALMOLOGY','0','0','0','0','0'),(376,'6','2021','POLIKLINIK','DERMATOLOGY','0','0','0','0','0'),(377,'6','2021','POLIKLINIK','PHARMACY KL','0','0','0','0','0'),(378,'6','2021','POLIKLINIK','OCCUPATIONAL THERAPY','0','0','0','0','0'),(379,'6','2021','POLIKLINIK','POLIKLINIK','0','41','0','7696.049999999999','7696.049999999999'),(380,'6','2021','POLIKLINIK','RADIOTERAPHY','0','0','0','0','0'),(381,'6','2021','POLIKLINIK','MAXILOFACIAL','0','0','0','0','0'),(382,'6','2021','POLIKLINIK','GAMMA KNIFE CENTRE','0','0','0','0','0'),(383,'6','2021','POLIKLINIK',NULL,'0','0','0','0','0'),(384,'6','2021','POLIKLINIK','CELL THERAPHY','0','0','0','0','0'),(385,'5','2021','UKMSC','CLINIC CHARGES','187','316','37487.83999999999','88329.25','125817.09'),(386,'5','2021','UKMSC','DISPOSABLE','1850','610','225910.53000000026','18839.070000000007','244749.60000000027'),(387,'5','2021','UKMSC','PHARMACY','1567','1319','631361.4400000003','323531.7599999994','954893.1999999997'),(388,'5','2021','UKMSC','ROOM','144','0','181867.75','0','181867.75'),(389,'5','2021','UKMSC','RADIOLOGY','181','145','65140.36','67182','132322.36'),(390,'5','2021','UKMSC','OT CHARGES','113','0','182638.3','0','182638.3'),(391,'5','2021','UKMSC','IMPLANT/CONSIGNMENT','228','1','556890','250','557140'),(392,'5','2021','UKMSC','DOCTOR FEES','820','618','1457655.39','248613','1706268.39'),(393,'5','2021','UKMSC','OT DISPOSABLE','1852','3','252036.69999999984','2','252038.69999999984'),(394,'5','2021','UKMSC','OT HOURS','152','0','171814','0','171814'),(395,'5','2021','UKMSC','PHYSIOTHERAPHY','44','21','11840','2930','14770'),(396,'5','2021','UKMSC','LABORATORY','742','663','159862.11','65572.91','225435.02'),(397,'5','2021','UKMSC','WARD CHARGES','597','4','240311.9','606','240917.9'),(398,'5','2021','UKMSC','MAC Procedure','15','68','52590','121675','174265'),(399,'5','2021','UKMSC','K HEALTH','0','0','0','0','0'),(400,'5','2021','UKMSC','AUDIOLOGY','13','19','1608','2945','4553'),(401,'5','2021','UKMSC','INFANT CHARGES','68','0','5575.0199999999995','0','5575.0199999999995'),(402,'5','2021','UKMSC','ICU DISPOSABLE','311','0','23446.619999999995','0','23446.619999999995'),(403,'5','2021','UKMSC','EQUIPMENT/INSTRUMENT','50','22','37903.2','12774','50677.2'),(404,'5','2021','UKMSC','RESPIRATORY','6','0','4231','0','4231'),(405,'5','2021','UKMSC','NEUCLEAR','5','3','7316.219999999999','5623.36','12939.579999999998'),(406,'5','2021','UKMSC','SPEECH THERAPY','2','6','220','603.5','823.5'),(407,'5','2021','UKMSC','OPHTHALMOLOGY','1','28','46.8','2269.7999999999997','2316.6'),(408,'5','2021','UKMSC','DERMATOLOGY','0','0','0','0','0'),(409,'5','2021','UKMSC','PHARMACY KL','0','0','0','0','0'),(410,'5','2021','UKMSC','OCCUPATIONAL THERAPY','1','2','65','130','195'),(411,'5','2021','UKMSC','POLIKLINIK','0','0','0','0','0'),(412,'5','2021','UKMSC','RADIOTERAPHY','12','5','8593','13430','22023'),(413,'5','2021','UKMSC','MAXILOFACIAL','0','1','0','312','312'),(414,'5','2021','UKMSC','GAMMA KNIFE CENTRE','51','0','79662.22','0','79662.22'),(415,'5','2021','UKMSC',NULL,'0','0','0','0','0'),(416,'5','2021','UKMSC','CELL THERAPHY','0','0','0','0','0'),(417,'5','2021','DENTAL','CLINIC CHARGES','0','15','0','1100','1100'),(418,'5','2021','DENTAL','DISPOSABLE','0','0','0','0','0'),(419,'5','2021','DENTAL','PHARMACY','0','0','0','0','0'),(420,'5','2021','DENTAL','ROOM','0','0','0','0','0'),(421,'5','2021','DENTAL','RADIOLOGY','0','0','0','0','0'),(422,'5','2021','DENTAL','OT CHARGES','0','0','0','0','0'),(423,'5','2021','DENTAL','IMPLANT/CONSIGNMENT','0','0','0','0','0'),(424,'5','2021','DENTAL','DOCTOR FEES','0','29','0','22724','22724'),(425,'5','2021','DENTAL','OT DISPOSABLE','0','0','0','0','0'),(426,'5','2021','DENTAL','OT HOURS','0','0','0','0','0'),(427,'5','2021','DENTAL','PHYSIOTHERAPHY','0','0','0','0','0'),(428,'5','2021','DENTAL','LABORATORY','0','0','0','0','0'),(429,'5','2021','DENTAL','WARD CHARGES','0','0','0','0','0'),(430,'5','2021','DENTAL','MAC Procedure','0','0','0','0','0'),(431,'5','2021','DENTAL','K HEALTH','0','0','0','0','0'),(432,'5','2021','DENTAL','AUDIOLOGY','0','0','0','0','0'),(433,'5','2021','DENTAL','INFANT CHARGES','0','0','0','0','0'),(434,'5','2021','DENTAL','ICU DISPOSABLE','0','0','0','0','0'),(435,'5','2021','DENTAL','EQUIPMENT/INSTRUMENT','0','0','0','0','0'),(436,'5','2021','DENTAL','RESPIRATORY','0','0','0','0','0'),(437,'5','2021','DENTAL','NEUCLEAR','0','0','0','0','0'),(438,'5','2021','DENTAL','SPEECH THERAPY','0','0','0','0','0'),(439,'5','2021','DENTAL','OPHTHALMOLOGY','0','0','0','0','0'),(440,'5','2021','DENTAL','DERMATOLOGY','0','0','0','0','0'),(441,'5','2021','DENTAL','PHARMACY KL','0','0','0','0','0'),(442,'5','2021','DENTAL','OCCUPATIONAL THERAPY','0','0','0','0','0'),(443,'5','2021','DENTAL','POLIKLINIK','0','0','0','0','0'),(444,'5','2021','DENTAL','RADIOTERAPHY','0','0','0','0','0'),(445,'5','2021','DENTAL','MAXILOFACIAL','0','0','0','0','0'),(446,'5','2021','DENTAL','GAMMA KNIFE CENTRE','0','0','0','0','0'),(447,'5','2021','DENTAL',NULL,'0','0','0','0','0'),(448,'5','2021','DENTAL','CELL THERAPHY','0','0','0','0','0'),(449,'5','2021','FKL','CLINIC CHARGES','0','7','0','24.66','24.66'),(450,'5','2021','FKL','DISPOSABLE','0','0','0','0','0'),(451,'5','2021','FKL','PHARMACY','0','0','0','0','0'),(452,'5','2021','FKL','ROOM','0','0','0','0','0'),(453,'5','2021','FKL','RADIOLOGY','0','0','0','0','0'),(454,'5','2021','FKL','OT CHARGES','0','0','0','0','0'),(455,'5','2021','FKL','IMPLANT/CONSIGNMENT','0','0','0','0','0'),(456,'5','2021','FKL','DOCTOR FEES','0','0','0','0','0'),(457,'5','2021','FKL','OT DISPOSABLE','0','0','0','0','0'),(458,'5','2021','FKL','OT HOURS','0','0','0','0','0'),(459,'5','2021','FKL','PHYSIOTHERAPHY','0','0','0','0','0'),(460,'5','2021','FKL','LABORATORY','0','0','0','0','0'),(461,'5','2021','FKL','WARD CHARGES','0','0','0','0','0'),(462,'5','2021','FKL','MAC Procedure','0','0','0','0','0'),(463,'5','2021','FKL','K HEALTH','0','8','0','1899.3999999999996','1899.3999999999996'),(464,'5','2021','FKL','AUDIOLOGY','0','0','0','0','0'),(465,'5','2021','FKL','INFANT CHARGES','0','0','0','0','0'),(466,'5','2021','FKL','ICU DISPOSABLE','0','0','0','0','0'),(467,'5','2021','FKL','EQUIPMENT/INSTRUMENT','0','0','0','0','0'),(468,'5','2021','FKL','RESPIRATORY','0','0','0','0','0'),(469,'5','2021','FKL','NEUCLEAR','0','0','0','0','0'),(470,'5','2021','FKL','SPEECH THERAPY','0','0','0','0','0'),(471,'5','2021','FKL','OPHTHALMOLOGY','0','0','0','0','0'),(472,'5','2021','FKL','DERMATOLOGY','0','0','0','0','0'),(473,'5','2021','FKL','PHARMACY KL','0','273','0','41133.14000000005','41133.14000000005'),(474,'5','2021','FKL','OCCUPATIONAL THERAPY','0','0','0','0','0'),(475,'5','2021','FKL','POLIKLINIK','0','0','0','0','0'),(476,'5','2021','FKL','RADIOTERAPHY','0','0','0','0','0'),(477,'5','2021','FKL','MAXILOFACIAL','0','0','0','0','0'),(478,'5','2021','FKL','GAMMA KNIFE CENTRE','0','0','0','0','0'),(479,'5','2021','FKL',NULL,'0','0','0','0','0'),(480,'5','2021','FKL','CELL THERAPHY','0','0','0','0','0'),(481,'5','2021','IMP','CLINIC CHARGES','0','0','0','0','0'),(482,'5','2021','IMP','DISPOSABLE','0','0','0','0','0'),(483,'5','2021','IMP','PHARMACY','0','0','0','0','0'),(484,'5','2021','IMP','ROOM','0','0','0','0','0'),(485,'5','2021','IMP','RADIOLOGY','0','0','0','0','0'),(486,'5','2021','IMP','OT CHARGES','0','0','0','0','0'),(487,'5','2021','IMP','IMPLANT/CONSIGNMENT','0','122','0','91215.5','91215.5'),(488,'5','2021','IMP','DOCTOR FEES','0','0','0','0','0'),(489,'5','2021','IMP','OT DISPOSABLE','0','0','0','0','0'),(490,'5','2021','IMP','OT HOURS','0','0','0','0','0'),(491,'5','2021','IMP','PHYSIOTHERAPHY','0','0','0','0','0'),(492,'5','2021','IMP','LABORATORY','0','0','0','0','0'),(493,'5','2021','IMP','WARD CHARGES','0','0','0','0','0'),(494,'5','2021','IMP','MAC Procedure','0','0','0','0','0'),(495,'5','2021','IMP','K HEALTH','0','0','0','0','0'),(496,'5','2021','IMP','AUDIOLOGY','0','0','0','0','0'),(497,'5','2021','IMP','INFANT CHARGES','0','0','0','0','0'),(498,'5','2021','IMP','ICU DISPOSABLE','0','0','0','0','0'),(499,'5','2021','IMP','EQUIPMENT/INSTRUMENT','0','0','0','0','0'),(500,'5','2021','IMP','RESPIRATORY','0','0','0','0','0'),(501,'5','2021','IMP','NEUCLEAR','0','0','0','0','0'),(502,'5','2021','IMP','SPEECH THERAPY','0','0','0','0','0'),(503,'5','2021','IMP','OPHTHALMOLOGY','0','0','0','0','0'),(504,'5','2021','IMP','DERMATOLOGY','0','0','0','0','0'),(505,'5','2021','IMP','PHARMACY KL','0','0','0','0','0'),(506,'5','2021','IMP','OCCUPATIONAL THERAPY','0','0','0','0','0'),(507,'5','2021','IMP','POLIKLINIK','0','0','0','0','0'),(508,'5','2021','IMP','RADIOTERAPHY','0','0','0','0','0'),(509,'5','2021','IMP','MAXILOFACIAL','0','0','0','0','0'),(510,'5','2021','IMP','GAMMA KNIFE CENTRE','0','0','0','0','0'),(511,'5','2021','IMP',NULL,'0','0','0','0','0'),(512,'5','2021','IMP','CELL THERAPHY','0','0','0','0','0'),(513,'5','2021','KH','CLINIC CHARGES','0','18','0','-0.4200000000000001','-0.4200000000000001'),(514,'5','2021','KH','DISPOSABLE','0','0','0','0','0'),(515,'5','2021','KH','PHARMACY','0','0','0','0','0'),(516,'5','2021','KH','ROOM','0','0','0','0','0'),(517,'5','2021','KH','RADIOLOGY','0','0','0','0','0'),(518,'5','2021','KH','OT CHARGES','0','0','0','0','0'),(519,'5','2021','KH','IMPLANT/CONSIGNMENT','0','0','0','0','0'),(520,'5','2021','KH','DOCTOR FEES','0','0','0','0','0'),(521,'5','2021','KH','OT DISPOSABLE','0','0','0','0','0'),(522,'5','2021','KH','OT HOURS','0','0','0','0','0'),(523,'5','2021','KH','PHYSIOTHERAPHY','0','0','0','0','0'),(524,'5','2021','KH','LABORATORY','0','0','0','0','0'),(525,'5','2021','KH','WARD CHARGES','0','0','0','0','0'),(526,'5','2021','KH','MAC Procedure','0','0','0','0','0'),(527,'5','2021','KH','K HEALTH','0','1139','0','65767.97000000015','65767.97000000015'),(528,'5','2021','KH','AUDIOLOGY','0','0','0','0','0'),(529,'5','2021','KH','INFANT CHARGES','0','0','0','0','0'),(530,'5','2021','KH','ICU DISPOSABLE','0','0','0','0','0'),(531,'5','2021','KH','EQUIPMENT/INSTRUMENT','0','0','0','0','0'),(532,'5','2021','KH','RESPIRATORY','0','0','0','0','0'),(533,'5','2021','KH','NEUCLEAR','0','0','0','0','0'),(534,'5','2021','KH','SPEECH THERAPY','0','0','0','0','0'),(535,'5','2021','KH','OPHTHALMOLOGY','0','0','0','0','0'),(536,'5','2021','KH','DERMATOLOGY','0','0','0','0','0'),(537,'5','2021','KH','PHARMACY KL','0','0','0','0','0'),(538,'5','2021','KH','OCCUPATIONAL THERAPY','0','0','0','0','0'),(539,'5','2021','KH','POLIKLINIK','0','0','0','0','0'),(540,'5','2021','KH','RADIOTERAPHY','0','0','0','0','0'),(541,'5','2021','KH','MAXILOFACIAL','0','0','0','0','0'),(542,'5','2021','KH','GAMMA KNIFE CENTRE','0','0','0','0','0'),(543,'5','2021','KH',NULL,'0','0','0','0','0'),(544,'5','2021','KH','CELL THERAPHY','0','0','0','0','0'),(545,'5','2021','POLIKLINIK','CLINIC CHARGES','0','3','0','0.010000000000000002','0.010000000000000002'),(546,'5','2021','POLIKLINIK','DISPOSABLE','0','19','0','806','806'),(547,'5','2021','POLIKLINIK','PHARMACY','0','144','0','12805.679999999998','12805.679999999998'),(548,'5','2021','POLIKLINIK','ROOM','0','0','0','0','0'),(549,'5','2021','POLIKLINIK','RADIOLOGY','0','0','0','0','0'),(550,'5','2021','POLIKLINIK','OT CHARGES','0','0','0','0','0'),(551,'5','2021','POLIKLINIK','IMPLANT/CONSIGNMENT','0','0','0','0','0'),(552,'5','2021','POLIKLINIK','DOCTOR FEES','0','0','0','0','0'),(553,'5','2021','POLIKLINIK','OT DISPOSABLE','0','0','0','0','0'),(554,'5','2021','POLIKLINIK','OT HOURS','0','0','0','0','0'),(555,'5','2021','POLIKLINIK','PHYSIOTHERAPHY','0','0','0','0','0'),(556,'5','2021','POLIKLINIK','LABORATORY','0','0','0','0','0'),(557,'5','2021','POLIKLINIK','WARD CHARGES','0','0','0','0','0'),(558,'5','2021','POLIKLINIK','MAC Procedure','0','0','0','0','0'),(559,'5','2021','POLIKLINIK','K HEALTH','0','0','0','0','0'),(560,'5','2021','POLIKLINIK','AUDIOLOGY','0','0','0','0','0'),(561,'5','2021','POLIKLINIK','INFANT CHARGES','0','0','0','0','0'),(562,'5','2021','POLIKLINIK','ICU DISPOSABLE','0','0','0','0','0'),(563,'5','2021','POLIKLINIK','EQUIPMENT/INSTRUMENT','0','0','0','0','0'),(564,'5','2021','POLIKLINIK','RESPIRATORY','0','0','0','0','0'),(565,'5','2021','POLIKLINIK','NEUCLEAR','0','0','0','0','0'),(566,'5','2021','POLIKLINIK','SPEECH THERAPY','0','0','0','0','0'),(567,'5','2021','POLIKLINIK','OPHTHALMOLOGY','0','0','0','0','0'),(568,'5','2021','POLIKLINIK','DERMATOLOGY','0','0','0','0','0'),(569,'5','2021','POLIKLINIK','PHARMACY KL','0','0','0','0','0'),(570,'5','2021','POLIKLINIK','OCCUPATIONAL THERAPY','0','0','0','0','0'),(571,'5','2021','POLIKLINIK','POLIKLINIK','0','63','0','8376.759999999998','8376.759999999998'),(572,'5','2021','POLIKLINIK','RADIOTERAPHY','0','0','0','0','0'),(573,'5','2021','POLIKLINIK','MAXILOFACIAL','0','0','0','0','0'),(574,'5','2021','POLIKLINIK','GAMMA KNIFE CENTRE','0','0','0','0','0'),(575,'5','2021','POLIKLINIK',NULL,'0','0','0','0','0'),(576,'5','2021','POLIKLINIK','CELL THERAPHY','0','0','0','0','0');
/*!40000 ALTER TABLE `patsumrev` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `paymode`
--

DROP TABLE IF EXISTS `paymode`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `paymode` (
  `compcode` varchar(2) NOT NULL DEFAULT '',
  `source` varchar(2) NOT NULL DEFAULT '',
  `paymode` varchar(30) NOT NULL,
  `paytype` varchar(15) DEFAULT NULL,
  `description` varchar(100) DEFAULT NULL,
  `ccode` varchar(10) DEFAULT NULL,
  `glaccno` varchar(30) NOT NULL,
  `cardflag` tinyint(4) DEFAULT NULL,
  `recstatus` varchar(10) DEFAULT NULL,
  `valexpdate` varchar(4) DEFAULT NULL,
  `comrate` decimal(4,2) DEFAULT NULL,
  `lastupdate` datetime DEFAULT NULL,
  `lastuser` varchar(30) DEFAULT NULL,
  `drcommrate` decimal(7,2) DEFAULT NULL,
  `drpayment` tinyint(4) DEFAULT NULL,
  `cardcent` varchar(30) DEFAULT NULL,
  `adduser` varchar(12) DEFAULT NULL,
  `adddate` datetime DEFAULT NULL,
  `upduser` varchar(12) DEFAULT NULL,
  `upddate` datetime DEFAULT NULL,
  `costcode` varchar(30) DEFAULT NULL,
  `idno` int(11) NOT NULL AUTO_INCREMENT,
  `computerid` varchar(20) DEFAULT NULL,
  `ipaddress` varchar(20) DEFAULT NULL,
  `lastcomputerid` varchar(20) DEFAULT NULL,
  `lastipaddress` varchar(20) DEFAULT NULL,
  `deluser` varchar(12) DEFAULT NULL,
  `deldate` datetime DEFAULT NULL,
  UNIQUE KEY `idno` (`idno`),
  UNIQUE KEY `compcode` (`compcode`,`source`,`paymode`)
) ENGINE=InnoDB AUTO_INCREMENT=224 DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `paymode`
--

LOCK TABLES `paymode` WRITE;
/*!40000 ALTER TABLE `paymode` DISABLE KEYS */;
INSERT INTO `paymode` VALUES ('9A','AP','BD','Bank Draft','BANK DRAFT','113','619560',1,'ACTIVE','0',0.00,'0000-00-00 00:00:00','tajul',0.00,1,'',NULL,NULL,NULL,NULL,NULL,1,NULL,NULL,NULL,NULL,NULL,NULL),('9A','AP','CASH','Cash','Petty Cash','113','619560',0,'ACTIVE','0',0.00,'2028-07-11 00:00:00','tajul',0.00,0,'\r',NULL,NULL,NULL,NULL,NULL,2,NULL,NULL,NULL,NULL,NULL,NULL),('9A','AP','CHEQUE','Cheque','Cheque','113','619560',0,'ACTIVE','0',0.00,'2028-07-11 00:00:00','tajul',0.00,0,'\r',NULL,NULL,NULL,NULL,NULL,3,NULL,NULL,NULL,NULL,NULL,NULL),('9A','AP','DISC','Credit Note','Dicsount','113','115850',0,'ACTIVE','0',0.00,'2028-07-11 00:00:00','tajul',0.00,0,'\r',NULL,NULL,NULL,NULL,NULL,4,NULL,NULL,NULL,NULL,NULL,NULL),('9A','AR','617410','Credit Note','Contra Account','113','617410',0,'ACTIVE','0',0.00,'2003-10-11 00:00:00','lim',0.00,0,'MBB\r',NULL,NULL,NULL,NULL,NULL,5,NULL,NULL,NULL,NULL,NULL,NULL),('9A','AR','CHEQUE','Cheque','PAYMENT BY CHEQUE','1001','619220',0,'ACTIVE','0',0.00,'2020-07-11 00:00:00','LEONG',0.00,0,'','',NULL,'farid','2016-08-30 10:40:19',NULL,6,NULL,NULL,NULL,NULL,NULL,NULL),('9A','AR','CN-DISC','Credit Note','DISCOUNT GIVEN TO PATIENT','113','513192',0,'ACTIVE','0',0.00,'2025-08-11 00:00:00','admin',0.00,0,'MBB\r',NULL,NULL,NULL,NULL,NULL,7,NULL,NULL,NULL,NULL,NULL,NULL),('9A','AR','DEBITMBB','Card','DEBIT CARD MBB','113','619230',0,'ACTIVE','0',0.00,'2025-08-11 00:00:00','admin',0.00,0,'MBB\r',NULL,NULL,NULL,NULL,NULL,8,NULL,NULL,NULL,NULL,NULL,NULL),('9A','AR','JCBMBB','Card','JCB CARDS MBB','113','619230',0,'ACTIVE','0',0.00,'2003-10-11 00:00:00','lim',0.00,0,'MBB\r',NULL,NULL,NULL,NULL,NULL,9,NULL,NULL,NULL,NULL,NULL,NULL),('9A','AR','MCMBB','Card','MASTER CARD MBB','113','619230',0,'ACTIVE','0',0.00,'2025-08-11 00:00:00','admin',0.00,0,'MBB\r',NULL,NULL,NULL,NULL,NULL,10,NULL,NULL,NULL,NULL,NULL,NULL),('9A','AR','MCMBF','Card','MASTER CARD MBF','113','619230',0,'ACTIVE','0',0.00,'2026-09-11 00:00:00','admin',0.00,0,'MBF\r',NULL,NULL,NULL,NULL,NULL,11,NULL,NULL,NULL,NULL,NULL,NULL),('9A','AR','VISAMBB','Card','VISA - MAYBANK','113','619230',0,'ACTIVE','0',0.00,'2030-06-11 00:00:00','tajul',0.00,0,'MBB\r',NULL,NULL,NULL,NULL,NULL,12,NULL,NULL,NULL,NULL,NULL,NULL),('9A','AR','VISAMBF','Card','VISA MBF','113','619230',0,'ACTIVE','0',0.00,'2026-09-11 00:00:00','admin',0.00,0,'MBF\r',NULL,NULL,NULL,NULL,NULL,13,NULL,NULL,NULL,NULL,NULL,NULL),('9A','CM','BD','Bank Draft','BANK DRAFT','1000','50021004',1,'ACTIVE','0',0.00,'0000-00-00 00:00:00','tajul',0.00,1,'','','0000-00-00 00:00:00','farid','2017-01-03 16:01:59',NULL,14,'','',NULL,NULL,NULL,NULL),('9A','CM','CASH','Cash','CASH','1000','50021100',0,'ACTIVE','0',0.00,'2028-07-11 00:00:00','tajul',0.00,0,'','','0000-00-00 00:00:00','farid','2017-01-03 16:01:24',NULL,15,'','',NULL,NULL,NULL,NULL),('9A','CM','CHEQUE','Cheque','CHEQUE','1000','50030508',0,'ACTIVE','0',0.00,'2028-07-11 00:00:00','tajul',0.00,0,'','','0000-00-00 00:00:00','farid','2017-01-03 16:02:34',NULL,16,'','',NULL,NULL,NULL,NULL),('9A','AP','100006','Credit Note','Furniture & Fittings - cost','006','100006',0,'ACTIVE','0',0.00,'2013-01-12 00:00:00','watie',0.00,0,'',NULL,NULL,NULL,NULL,NULL,17,NULL,NULL,NULL,NULL,NULL,NULL),('9A','AP','140002','Credit Note','Equipment under installation','1001','10010000',0,'ACTIVE','0',0.00,'2010-06-10 00:00:00','ong',0.00,0,'',NULL,NULL,'farid','2016-02-26 11:44:50',NULL,18,NULL,NULL,NULL,NULL,NULL,NULL),('9A','AP','140003','Credit Note','Renovation Work In Progress','006','140003',0,'ACTIVE','0',0.00,'2030-11-11 00:00:00','stlim',0.00,0,'',NULL,NULL,NULL,NULL,NULL,19,NULL,NULL,NULL,NULL,NULL,NULL),('9A','AP','150027','Credit Note','Stock - temp a/c','006','150027',0,'ACTIVE','0',0.00,'2024-08-07 00:00:00','ong',0.00,0,'',NULL,NULL,NULL,NULL,NULL,20,NULL,NULL,NULL,NULL,NULL,NULL),('9A','AP','170003','Credit Note','Other Debtors - Beacon GB Sdn Bhd','006','170003',0,'ACTIVE','0',0.00,'2023-06-15 00:00:00','samantha',0.00,0,'',NULL,NULL,NULL,NULL,NULL,21,NULL,NULL,NULL,NULL,NULL,NULL),('9A','AP','180004','Credit Note','Prepayment - Others','006','180004',0,'ACTIVE','0',0.00,'2031-10-07 00:00:00','ONG',0.00,0,'',NULL,NULL,NULL,NULL,NULL,22,NULL,NULL,NULL,NULL,NULL,NULL),('9A','AP','180004dn','Debit Note','Prepayment - others','006','180004',0,'ACTIVE','0',0.00,'2031-10-07 00:00:00','ONG',0.00,0,'',NULL,NULL,NULL,NULL,NULL,23,NULL,NULL,NULL,NULL,NULL,NULL),('9A','AP','200005','Credit Note','Accruals - Doctors fee','006','200005',0,'ACTIVE','0',0.00,'2014-11-08 00:00:00','ong',0.00,0,'',NULL,NULL,NULL,NULL,NULL,24,NULL,NULL,NULL,NULL,NULL,NULL),('9A','AP','200006','Credit Note','Accruals - Electricity','006','200006',0,'ACTIVE','0',0.00,'2026-01-11 00:00:00','syin',0.00,0,'',NULL,NULL,NULL,NULL,NULL,25,NULL,NULL,NULL,NULL,NULL,NULL),('9A','AP','200007','Credit Note','Accurals - Water','006','200007',0,'ACTIVE','0',0.00,'2026-01-11 00:00:00','syin',0.00,0,'',NULL,NULL,NULL,NULL,NULL,26,NULL,NULL,NULL,NULL,NULL,NULL),('9A','AP','200016','Credit Note','Accruals - others','006','200016',0,'ACTIVE','0',0.00,'2023-05-07 00:00:00','ong',0.00,0,'',NULL,NULL,NULL,NULL,NULL,27,NULL,NULL,NULL,NULL,NULL,NULL),('9A','AP','200022','Credit Note','Accrual-withholding tax','005','200022',0,'ACTIVE','0',0.00,'2021-01-08 00:00:00','ong',0.00,0,'',NULL,NULL,NULL,NULL,NULL,28,NULL,NULL,NULL,NULL,NULL,NULL),('9A','AP','240001','Credit Note','Amount due to Wijaya Baru Global Bhd','006','240001',0,'ACTIVE','0',0.00,'2007-09-07 00:00:00','ong',0.00,0,'',NULL,NULL,NULL,NULL,NULL,29,NULL,NULL,NULL,NULL,NULL,NULL),('9A','AP','250001','Debit Note','Amount due to/(by) directors-Dato\'Seri','006','250001',0,'ACTIVE','0',0.00,'2007-01-08 00:00:00','ong',0.00,0,'',NULL,NULL,NULL,NULL,NULL,30,NULL,NULL,NULL,NULL,NULL,NULL),('9A','AP','411030','Credit Note','Four Beded Room','006','411030',0,'ACTIVE','0',0.00,'2012-04-12 00:00:00','watie',0.00,0,'',NULL,NULL,NULL,NULL,NULL,33,NULL,NULL,NULL,NULL,NULL,NULL),('9A','AP','510001','Credit Note','COS - Consumables','011','510001',0,'ACTIVE','0',0.00,'2024-09-07 00:00:00','ong',0.00,0,'',NULL,NULL,NULL,NULL,NULL,34,NULL,NULL,NULL,NULL,NULL,NULL),('9A','AP','510002','Credit Note','COS - Medicines','109','510002',0,'ACTIVE','0',0.00,'2024-09-07 00:00:00','ong',0.00,0,'',NULL,NULL,NULL,NULL,NULL,35,NULL,NULL,NULL,NULL,NULL,NULL),('9A','AP','510003','Debit Note','COS - Medical gas','103','510003',0,'ACTIVE','0',0.00,'2023-08-07 00:00:00','ong',0.00,0,'',NULL,NULL,NULL,NULL,NULL,36,NULL,NULL,NULL,NULL,NULL,NULL),('9A','AP','510003CN','Credit Note','COS - Medical gas','107','510003',0,'ACTIVE','0',0.00,'2030-01-09 00:00:00','ong',0.00,0,'',NULL,NULL,NULL,NULL,NULL,37,NULL,NULL,NULL,NULL,NULL,NULL),('9A','AP','510004','Credit Note','COS - External Laboratory Tests','106','510004',0,'ACTIVE','0',0.00,'2017-09-07 00:00:00','ong',0.00,0,'',NULL,NULL,NULL,NULL,NULL,38,NULL,NULL,NULL,NULL,NULL,NULL),('9A','AP','510006CN','Credit Note','COS - Consumable component/tools','103','510006',0,'ACTIVE','0',0.00,'2011-02-10 00:00:00','ong',0.00,0,'',NULL,NULL,NULL,NULL,NULL,42,NULL,NULL,NULL,NULL,NULL,NULL),('9A','AP','510007','Debit Note','COS- Food & Beverage','103','510007',0,'ACTIVE','0',0.00,'2015-11-11 00:00:00','stlim',0.00,0,'',NULL,NULL,NULL,NULL,NULL,43,NULL,NULL,NULL,NULL,NULL,NULL),('9A','AP','510009','Credit Note','COS - Cyclotron Consumable','006','510009',0,'ACTIVE','0',0.00,'2008-11-12 00:00:00','watie',0.00,0,'',NULL,NULL,NULL,NULL,NULL,44,NULL,NULL,NULL,NULL,NULL,NULL),('9A','AP','510014','Credit Note','COS - Others','109','510014',0,'ACTIVE','0',0.00,'2024-06-08 00:00:00','ong',0.00,0,'',NULL,NULL,NULL,NULL,NULL,45,NULL,NULL,NULL,NULL,NULL,NULL),('9A','AP','600009','Credit Note','Staff refreshment','006','600009',0,'ACTIVE','0',0.00,'2003-03-14 00:00:00','watie',0.00,0,'',NULL,NULL,NULL,NULL,NULL,46,NULL,NULL,NULL,NULL,NULL,NULL),('9A','AP','600013','Credit Note','Staff insurances expenses','006','600013',0,'ACTIVE','0',0.00,'2022-05-07 00:00:00','ong',0.00,0,'',NULL,NULL,NULL,NULL,NULL,49,NULL,NULL,NULL,NULL,NULL,NULL),('9A','AP','600015','Credit Note','Workers uniform','006','600015',0,'ACTIVE','0',0.00,'2030-07-10 00:00:00','ong',0.00,0,'',NULL,NULL,NULL,NULL,NULL,50,NULL,NULL,NULL,NULL,NULL,NULL),('9A','AP','600018','Credit Note','Staff Recruitment costs','006','600018',0,'ACTIVE','0',0.00,'2011-08-10 00:00:00','ong',0.00,0,'',NULL,NULL,NULL,NULL,NULL,51,NULL,NULL,NULL,NULL,NULL,NULL),('9A','AP','600021','Credit Note','Rewards','006','600021',0,'ACTIVE','0',0.00,'2027-01-14 00:00:00','watie',0.00,0,'',NULL,NULL,NULL,NULL,NULL,52,NULL,NULL,NULL,NULL,NULL,NULL),('9A','AP','630005','Credit Note','Bank charges','005','630005',0,'ACTIVE','0',0.00,'2012-05-09 00:00:00','ong',0.00,0,'',NULL,NULL,NULL,NULL,NULL,53,NULL,NULL,NULL,NULL,NULL,NULL),('9A','AP','630009','Credit Note','GST','006','630009',0,'ACTIVE','0',0.00,'2003-06-15 00:00:00','samantha',0.00,0,'',NULL,NULL,NULL,NULL,NULL,54,NULL,NULL,NULL,NULL,NULL,NULL),('9A','AP','640003','Credit Note','Tax agent fee-under/(over)in prior year','005','640003',0,'ACTIVE','0',0.00,'2018-12-07 00:00:00','ong',0.00,0,'',NULL,NULL,NULL,NULL,NULL,55,NULL,NULL,NULL,NULL,NULL,NULL),('9A','AP','640005','Credit Note','Audit fee-under/(over)in prior year','005','640005',0,'ACTIVE','0',0.00,'2018-12-07 00:00:00','ong',0.00,0,'',NULL,NULL,NULL,NULL,NULL,56,NULL,NULL,NULL,NULL,NULL,NULL),('9A','AP','640009','Credit Note','Consultancy fee','110','640009',0,'ACTIVE','0',0.00,'2022-06-07 00:00:00','ong',0.00,0,'',NULL,NULL,NULL,NULL,NULL,57,NULL,NULL,NULL,NULL,NULL,NULL),('9A','AP','640015','Credit Note','Service tax','006','640015',0,'ACTIVE','0',0.00,'2023-05-07 00:00:00','ong',0.00,0,'',NULL,NULL,NULL,NULL,NULL,58,NULL,NULL,NULL,NULL,NULL,NULL),('9A','AP','660001','Credit Note','Upkeep of Motor Vehicles','006','660001',0,'ACTIVE','0',0.00,'2001-09-09 00:00:00','ong',0.00,0,'',NULL,NULL,NULL,NULL,NULL,59,NULL,NULL,NULL,NULL,NULL,NULL),('9A','AP','660002','Credit Note','Upkeep of Office equipment','006','660002',0,'ACTIVE','0',0.00,'2003-03-08 00:00:00','ong',0.00,0,'',NULL,NULL,NULL,NULL,NULL,60,NULL,NULL,NULL,NULL,NULL,NULL),('9A','AP','660003','Credit Note','Upkeep of premises','006','660003',0,'ACTIVE','0',0.00,'2023-05-07 00:00:00','ong',0.00,0,'',NULL,NULL,NULL,NULL,NULL,61,NULL,NULL,NULL,NULL,NULL,NULL),('9A','AP','660004','Credit Note','Upkeep of other FA','006','660004',0,'ACTIVE','0',0.00,'2012-04-12 00:00:00','watie',0.00,0,'',NULL,NULL,NULL,NULL,NULL,62,NULL,NULL,NULL,NULL,NULL,NULL),('9A','AP','660005','Credit Note','Repair medical equipment','110','660005',0,'ACTIVE','0',0.00,'2016-07-11 00:00:00','hew',0.00,0,'',NULL,NULL,NULL,NULL,NULL,63,NULL,NULL,NULL,NULL,NULL,NULL),('9A','AP','660006','Credit Note','Hardware and software maintenance','006','660006',0,'ACTIVE','0',0.00,'2027-01-12 00:00:00','watie',0.00,0,'',NULL,NULL,NULL,NULL,NULL,64,NULL,NULL,NULL,NULL,NULL,NULL),('9A','AP','660009','Credit Note','Upkeep of Air Conditioners','006','660009',0,'ACTIVE','0',0.00,'2005-01-12 00:00:00','watie',0.00,0,'',NULL,NULL,NULL,NULL,NULL,65,NULL,NULL,NULL,NULL,NULL,NULL),('9A','AP','660011','Credit Note','Service medical equipment','006','660011',0,'ACTIVE','0',0.00,'2019-03-13 00:00:00','WATIE',0.00,0,'',NULL,NULL,NULL,NULL,NULL,66,NULL,NULL,NULL,NULL,NULL,NULL),('9A','AP','660013','Credit Note','Upkeep of electrical fittings','006','660013',0,'ACTIVE','0',0.00,'2012-04-12 00:00:00','watie',0.00,0,'',NULL,NULL,NULL,NULL,NULL,67,NULL,NULL,NULL,NULL,NULL,NULL),('9A','AP','670001','Credit Note','Telephone and telecommunication','006','670001',0,'ACTIVE','0',0.00,'2009-12-11 00:00:00','stlim',0.00,0,'',NULL,NULL,NULL,NULL,NULL,68,NULL,NULL,NULL,NULL,NULL,NULL),('9A','AP','670002','Credit Note','Electricity','006','670002',0,'ACTIVE','0',0.00,'2009-01-14 00:00:00','watie',0.00,0,'',NULL,NULL,NULL,NULL,NULL,69,NULL,NULL,NULL,NULL,NULL,NULL),('9A','AP','670003','Credit Note','Sewerage/waste disposal fee','006','670003',0,'ACTIVE','0',0.00,'2026-11-12 00:00:00','watie',0.00,0,'',NULL,NULL,NULL,NULL,NULL,70,NULL,NULL,NULL,NULL,NULL,NULL),('9A','AP','670007','Credit Note','Water','006','670007',0,'ACTIVE','0',0.00,'2009-01-14 00:00:00','watie',0.00,0,'',NULL,NULL,NULL,NULL,NULL,71,NULL,NULL,NULL,NULL,NULL,NULL),('9A','AP','680001','Credit Note','Rental expenses','006','680001',0,'ACTIVE','0',0.00,'2003-03-08 00:00:00','ong',0.00,0,'',NULL,NULL,NULL,NULL,NULL,72,NULL,NULL,NULL,NULL,NULL,NULL),('9A','AP','680002','Credit Note','Printing & Stationery','006','680002',0,'ACTIVE','0',0.00,'2024-09-07 00:00:00','ong',0.00,0,'',NULL,NULL,NULL,NULL,NULL,73,NULL,NULL,NULL,NULL,NULL,NULL),('9A','AP','680003','Credit Note','Postage & courier','006','680003',0,'ACTIVE','0',0.00,'2005-08-10 00:00:00','ong',0.00,0,'',NULL,NULL,NULL,NULL,NULL,74,NULL,NULL,NULL,NULL,NULL,NULL),('9A','AP','680004','Credit Note','TLD assessment fee','006','680004',0,'ACTIVE','0',0.00,'2006-06-13 00:00:00','watie',0.00,0,'',NULL,NULL,NULL,NULL,NULL,75,NULL,NULL,NULL,NULL,NULL,NULL),('9A','AP','680007','Credit Note','Travelling expenses - business','006','680007',0,'ACTIVE','0',0.00,'2030-07-10 00:00:00','ong',0.00,0,'',NULL,NULL,NULL,NULL,NULL,76,NULL,NULL,NULL,NULL,NULL,NULL),('9A','AP','680008','Debit Note','Accomodation','110','680008',0,'ACTIVE','0',0.00,'2023-08-07 00:00:00','ong',0.00,0,'',NULL,NULL,NULL,NULL,NULL,77,NULL,NULL,NULL,NULL,NULL,NULL),('9A','AP','680008cn','Credit Note','Accomodation expenses','110','680008',0,'ACTIVE','0',0.00,'2003-10-07 00:00:00','ong',0.00,0,'',NULL,NULL,NULL,NULL,NULL,78,NULL,NULL,NULL,NULL,NULL,NULL),('9A','AP','680011','Credit Note','Transportation Fuel','006','680011',0,'ACTIVE','0',0.00,'2017-07-12 00:00:00','watie',0.00,0,'',NULL,NULL,NULL,NULL,NULL,79,NULL,NULL,NULL,NULL,NULL,NULL),('9A','AP','680014','Credit Note','Insurance - Buildings','006','680014',0,'ACTIVE','0',0.00,'2024-06-15 00:00:00','WATIE',0.00,0,'',NULL,NULL,NULL,NULL,NULL,80,NULL,NULL,NULL,NULL,NULL,NULL),('9A','AP','680015','Credit Note','Insurance - others','006','680015',0,'ACTIVE','0',0.00,'2013-02-08 00:00:00','ong',0.00,0,'',NULL,NULL,NULL,NULL,NULL,81,NULL,NULL,NULL,NULL,NULL,NULL),('9A','AP','680017','Credit Note','Membership subscription fee','006','680017',0,'ACTIVE','0',0.00,'2020-08-13 00:00:00','WATIE',0.00,0,'',NULL,NULL,NULL,NULL,NULL,82,NULL,NULL,NULL,NULL,NULL,NULL),('9A','AP','680022','Credit Note','Misc expenses','006','680022',0,'ACTIVE','0',0.00,'2008-11-12 00:00:00','watie',0.00,0,'',NULL,NULL,NULL,NULL,NULL,83,NULL,NULL,NULL,NULL,NULL,NULL),('9A','AP','680031','Credit Note','Laundry','006','680031',0,'ACTIVE','0',0.00,'2002-02-12 00:00:00','watie',0.00,0,'',NULL,NULL,NULL,NULL,NULL,84,NULL,NULL,NULL,NULL,NULL,NULL),('9A','AP','690001','Credit Note','Launching/Event expenses','006','690001',0,'ACTIVE','0',0.00,'2013-03-14 00:00:00','watie',0.00,0,'',NULL,NULL,NULL,NULL,NULL,85,NULL,NULL,NULL,NULL,NULL,NULL),('9A','AP','690004','Credit Note','Advertorials/Advertisements','006','690004',0,'ACTIVE','0',0.00,'2004-09-12 00:00:00','WATIE',0.00,0,'',NULL,NULL,NULL,NULL,NULL,86,NULL,NULL,NULL,NULL,NULL,NULL),('9A','AP','690008','Credit Note','Other marketing expenditure','006','690008',0,'ACTIVE','0',0.00,'2009-07-15 00:00:00','WATIE',0.00,0,'',NULL,NULL,NULL,NULL,NULL,87,NULL,NULL,NULL,NULL,NULL,NULL),('9A','AP','690009CN','Credit Note','Newspaper & Periodicals','006','690009',0,'ACTIVE','0',0.00,'2009-11-09 00:00:00','ong',0.00,0,'',NULL,NULL,NULL,NULL,NULL,88,NULL,NULL,NULL,NULL,NULL,NULL),('9A','AP','700005','Credit Note','Discount received','109','700005',0,'ACTIVE','0',0.00,'2018-03-08 00:00:00','ong',0.00,0,'',NULL,NULL,NULL,NULL,NULL,89,NULL,NULL,NULL,NULL,NULL,NULL),('9A','AP','700007','Credit Note','Gain on FOREX rate','005','700007',0,'ACTIVE','0',0.00,'2029-03-10 00:00:00','ong',0.00,0,'',NULL,NULL,NULL,NULL,NULL,90,NULL,NULL,NULL,NULL,NULL,NULL),('9A','AP','DRAFT','Bank Draft','BANK DRAFT','006','192005',0,'ACTIVE','0',0.00,'2010-05-07 00:00:00','tajul',0.00,0,'',NULL,NULL,NULL,NULL,NULL,92,NULL,NULL,NULL,NULL,NULL,NULL),('9A','AP','TT','Cash','TELE TRANSFER','006','630005',0,'ACTIVE','1',0.00,'0000-00-00 00:00:00','tajul',0.00,1,'',NULL,NULL,NULL,NULL,NULL,93,NULL,NULL,NULL,NULL,NULL,NULL),('9A','AR','160002','Credit Note','Provision for doubtful debts(AR)','100','10010001',0,'ACTIVE','0',0.00,'2013-05-15 00:00:00','samantha',0.00,0,'',NULL,NULL,'farid','2016-02-18 10:45:22',NULL,94,NULL,NULL,NULL,NULL,NULL,NULL),('9A','AR','170002','Debit Note','Other debtors - Beacon Health Sdn Bhd','006','170002',0,'ACTIVE','0',0.00,'2007-05-13 00:00:00','watie',0.00,0,'',NULL,NULL,NULL,NULL,NULL,95,NULL,NULL,NULL,NULL,NULL,NULL),('9A','AR','170004','Debit Note','Other Debtors - Marvellous Formula Sdn B','006','170004',0,'ACTIVE','0',0.00,'2007-03-12 00:00:00','watie',0.00,0,'',NULL,NULL,NULL,NULL,NULL,96,NULL,NULL,NULL,NULL,NULL,NULL),('9A','AR','170007','Debit Note','Staff Loan','006','170007',0,'ACTIVE','0',0.00,'2001-06-12 00:00:00','watie',0.00,0,'',NULL,NULL,NULL,NULL,NULL,97,NULL,NULL,NULL,NULL,NULL,NULL),('9A','AR','180004','Credit Note','Prepayment - Others','006','180004',0,'ACTIVE','0',0.00,'2003-10-07 00:00:00','ong',0.00,0,'',NULL,NULL,NULL,NULL,NULL,98,NULL,NULL,NULL,NULL,NULL,NULL),('9A','AR','180004DN','Debit Note','Prepayment - Others','006','180004',0,'ACTIVE','0',0.00,'2018-01-08 00:00:00','ong',0.00,0,'',NULL,NULL,NULL,NULL,NULL,99,NULL,NULL,NULL,NULL,NULL,NULL),('9A','AR','190002','Debit Note','Deposit Paid - Rental','006','190002',0,'ACTIVE','0',0.00,'2006-11-14 00:00:00','watie',0.00,0,'',NULL,NULL,NULL,NULL,NULL,100,NULL,NULL,NULL,NULL,NULL,NULL),('9A','AR','190003','Debit Note','Deposit Paid - Water & electricity','006','190003',0,'ACTIVE','0',0.00,'2001-04-14 00:00:00','WATIE',0.00,0,'',NULL,NULL,NULL,NULL,NULL,101,NULL,NULL,NULL,NULL,NULL,NULL),('9A','AR','192014','Debit Note','Cheque in Hand','006','192014',0,'ACTIVE','0',0.00,'2002-08-07 00:00:00','ong',0.00,0,'',NULL,NULL,NULL,NULL,NULL,102,NULL,NULL,NULL,NULL,NULL,NULL),('9A','AR','192015','Debit Note','Cash in Hand','002','192015',0,'ACTIVE','0',0.00,'2030-08-07 00:00:00','ONG',0.00,0,'',NULL,NULL,NULL,NULL,NULL,103,NULL,NULL,NULL,NULL,NULL,NULL),('9A','AR','200016','Credit Note','Accrual - others','006','200016',0,'ACTIVE','0',0.00,'2018-06-08 00:00:00','ong',0.00,0,'',NULL,NULL,NULL,NULL,NULL,104,NULL,NULL,NULL,NULL,NULL,NULL),('9A','AR','400015','Debit Note','Other business income','006','400015',0,'ACTIVE','0',0.00,'2031-03-11 00:00:00','SIANG',0.00,0,'',NULL,NULL,NULL,NULL,NULL,109,NULL,NULL,NULL,NULL,NULL,NULL),('9A','AR','410001','Credit Note','Revenue-Cyberknife','110','410001',0,'ACTIVE','0',0.00,'2022-05-07 00:00:00','ong',0.00,0,'',NULL,NULL,NULL,NULL,NULL,110,NULL,NULL,NULL,NULL,NULL,NULL),('9A','AR','410001DN','Debit Note','Revenue-Cyberknife','110','410001',0,'ACTIVE','0',0.00,'2019-07-08 00:00:00','ONG',0.00,0,'',NULL,NULL,NULL,NULL,NULL,111,NULL,NULL,NULL,NULL,NULL,NULL),('9A','AR','410002','Credit Note','Revenue-Linac','110','410002',0,'ACTIVE','0',0.00,'2022-05-07 00:00:00','ong',0.00,0,'',NULL,NULL,NULL,NULL,NULL,112,NULL,NULL,NULL,NULL,NULL,NULL),('9A','AR','410004','Debit Note','Revenue-PET CT','104','410004',0,'ACTIVE','0',0.00,'2005-05-08 00:00:00','ong',0.00,0,'',NULL,NULL,NULL,NULL,NULL,113,NULL,NULL,NULL,NULL,NULL,NULL),('9A','AR','410004CN','Credit Note','Revenue-PET CT','104','410004',0,'ACTIVE','0',0.00,'2017-06-08 00:00:00','ong',0.00,0,'',NULL,NULL,NULL,NULL,NULL,114,NULL,NULL,NULL,NULL,NULL,NULL),('9A','AR','410005','Debit Note','Revenue-Cyclotron','103','410005',0,'ACTIVE','0',0.00,'2005-05-08 00:00:00','ong',0.00,0,'',NULL,NULL,NULL,NULL,NULL,115,NULL,NULL,NULL,NULL,NULL,NULL),('9A','AR','410005CN','Credit Note','Revenue-Cyclotron','103','410005',0,'ACTIVE','0',0.00,'2020-01-09 00:00:00','ONG',0.00,0,'',NULL,NULL,NULL,NULL,NULL,116,NULL,NULL,NULL,NULL,NULL,NULL),('9A','AR','410006CN','Credit Note','Revenue-Magnetic Resonance Imaging','104','410006',0,'ACTIVE','0',0.00,'2004-11-08 00:00:00','ong',0.00,0,'',NULL,NULL,NULL,NULL,NULL,117,NULL,NULL,NULL,NULL,NULL,NULL),('9A','AR','410006DN','Debit Note','Revenue-magnetic Resonance Imaging','104','410006',0,'ACTIVE','0',0.00,'2004-11-08 00:00:00','ong',0.00,0,'',NULL,NULL,NULL,NULL,NULL,118,NULL,NULL,NULL,NULL,NULL,NULL),('9A','AR','410009','Debit Note','Revenue-General X-Ray','104','410009',0,'ACTIVE','0',0.00,'2027-04-09 00:00:00','ONG',0.00,0,'',NULL,NULL,NULL,NULL,NULL,119,NULL,NULL,NULL,NULL,NULL,NULL),('9A','AR','410012','Debit Note','Revenue-Medicines','002','410012',0,'ACTIVE','0',0.00,'2024-03-14 00:00:00','TAJUL',0.00,0,'',NULL,NULL,NULL,NULL,NULL,120,NULL,NULL,NULL,NULL,NULL,NULL),('9A','AR','410012CN','Credit Note','Revenue-Medicines','109','410012',0,'ACTIVE','0',0.00,'2002-12-09 00:00:00','ONG',0.00,0,'',NULL,NULL,NULL,NULL,NULL,121,NULL,NULL,NULL,NULL,NULL,NULL),('9A','AR','410013','Credit Note','Revenue-Lab','106','410013',0,'ACTIVE','0',0.00,'2003-10-07 00:00:00','ong',0.00,0,'AMEX',NULL,NULL,NULL,NULL,NULL,122,NULL,NULL,NULL,NULL,NULL,NULL),('9A','AR','410019','Debit Note','Medical Officer - Consultation fees','108','410019',0,'ACTIVE','0',0.00,'2011-03-09 00:00:00','ong',0.00,0,'',NULL,NULL,NULL,NULL,NULL,125,NULL,NULL,NULL,NULL,NULL,NULL),('9A','AR','410021','Credit Note','Revenue-Consumables','110','410021',0,'ACTIVE','0',0.00,'2025-10-08 00:00:00','ong',0.00,0,'',NULL,NULL,NULL,NULL,NULL,126,NULL,NULL,NULL,NULL,NULL,NULL),('9A','AR','410021DN','Debit Note','Revenue-Consumables','110','410021',0,'ACTIVE','0',0.00,'2029-10-08 00:00:00','ong',0.00,0,'',NULL,NULL,NULL,NULL,NULL,127,NULL,NULL,NULL,NULL,NULL,NULL),('9A','AR','410022','Debit Note','Medical Record Fees','012','410022',0,'ACTIVE','0',0.00,'2010-07-07 00:00:00','tajul',0.00,0,'',NULL,NULL,NULL,NULL,NULL,128,NULL,NULL,NULL,NULL,NULL,NULL),('9A','AR','410022CN','Credit Note','Medical Record Fees','012','410022',0,'ACTIVE','0',0.00,'2003-10-07 00:00:00','ong',0.00,0,'',NULL,NULL,NULL,NULL,NULL,129,NULL,NULL,NULL,NULL,NULL,NULL),('9A','AR','410023','Debit Note','Revenue-Ambulance charges','101','410023',0,'ACTIVE','0',0.00,'2013-11-07 00:00:00','ong',0.00,0,'',NULL,NULL,NULL,NULL,NULL,130,NULL,NULL,NULL,NULL,NULL,NULL),('9A','AR','410023CN','Credit Note','Revenue-Ambulance charges','101','410023',0,'ACTIVE','0',0.00,'2013-11-07 00:00:00','ong',0.00,0,'',NULL,NULL,NULL,NULL,NULL,131,NULL,NULL,NULL,NULL,NULL,NULL),('9A','AR','410027','Debit Note','Revenue-Cafetaria','006','410027',0,'ACTIVE','0',0.00,'2028-05-12 00:00:00','watie',0.00,0,'',NULL,NULL,NULL,NULL,NULL,134,NULL,NULL,NULL,NULL,NULL,NULL),('9A','AR','430001','Credit Note','Discount Medical','002','430001',0,'ACTIVE','0',0.00,'2003-10-07 00:00:00','ong',0.00,0,'',NULL,NULL,NULL,NULL,NULL,135,NULL,NULL,NULL,NULL,NULL,NULL),('9A','AR','430001DN','Debit Note','Discount Medical','002','430001',0,'ACTIVE','0',0.00,'2023-12-09 00:00:00','ONG',0.00,0,'',NULL,NULL,NULL,NULL,NULL,136,NULL,NULL,NULL,NULL,NULL,NULL),('9A','AR','430002','Credit Note','Discount Doctor','002','430002',0,'ACTIVE','0',0.00,'2005-06-07 00:00:00','ong',0.00,0,'',NULL,NULL,NULL,NULL,NULL,137,NULL,NULL,NULL,NULL,NULL,NULL),('9A','AR','430007','Credit Note','Discount Allowed','105','430007',0,'ACTIVE','0',0.00,'2011-03-15 00:00:00','samantha',0.00,0,'',NULL,NULL,NULL,NULL,NULL,138,NULL,NULL,NULL,NULL,NULL,NULL),('9A','AR','431003','Credit Note','Discount Medical - CSR','002','431003',0,'ACTIVE','0',0.00,'2013-06-11 00:00:00','limst',0.00,0,'',NULL,NULL,NULL,NULL,NULL,139,NULL,NULL,NULL,NULL,NULL,NULL),('9A','AR','510001','Debit Note','COS - Consumables','006','510001',0,'ACTIVE','0',0.00,'2007-09-12 00:00:00','watie',0.00,0,'',NULL,NULL,NULL,NULL,NULL,140,NULL,NULL,NULL,NULL,NULL,NULL),('9A','AR','510005','Debit Note','COS - Doctors Fee','006','510005',0,'ACTIVE','0',0.00,'2006-12-12 00:00:00','WATIE',0.00,0,'',NULL,NULL,NULL,NULL,NULL,141,NULL,NULL,NULL,NULL,NULL,NULL),('9A','AR','510005CN','Credit Note','COS - Doctors Fee','006','510005',0,'ACTIVE','0',0.00,'2026-06-15 00:00:00','SAMANTHA',0.00,0,'',NULL,NULL,NULL,NULL,NULL,142,NULL,NULL,NULL,NULL,NULL,NULL),('9A','AR','510007','Debit Note','COS-Food & Beverage','006','510007',0,'ACTIVE','0',0.00,'2015-11-11 00:00:00','stlim',0.00,0,'',NULL,NULL,NULL,NULL,NULL,143,NULL,NULL,NULL,NULL,NULL,NULL),('9A','AR','600002','Debit Note','Wages','006','600002',0,'ACTIVE','0',0.00,'2031-03-11 00:00:00','SIANG',0.00,0,'',NULL,NULL,NULL,NULL,NULL,144,NULL,NULL,NULL,NULL,NULL,NULL),('9A','AR','600012','Credit Note','Staff medical expenses','006','600012',0,'ACTIVE','0',0.00,'2022-05-07 00:00:00','ong',0.00,0,'',NULL,NULL,NULL,NULL,NULL,147,NULL,NULL,NULL,NULL,NULL,NULL),('9A','AR','600013','Debit Note','Staff insurances expenses','006','600013',0,'ACTIVE','0',0.00,'2026-04-12 00:00:00','WATIE',0.00,0,'',NULL,NULL,NULL,NULL,NULL,148,NULL,NULL,NULL,NULL,NULL,NULL),('9A','AR','630008','Credit Note','Loss on FOREX rate','005','630008',0,'ACTIVE','0',0.00,'2003-04-09 00:00:00','ong',0.00,0,'',NULL,NULL,NULL,NULL,NULL,151,NULL,NULL,NULL,NULL,NULL,NULL),('9A','AR','640018','Debit Note','Credit Card Charges','105','640018',0,'ACTIVE','0',0.00,'2025-06-15 00:00:00','samantha',0.00,0,'',NULL,NULL,NULL,NULL,NULL,152,NULL,NULL,NULL,NULL,NULL,NULL),('9A','AR','650001','Credit Note','Doubtful debts','005','650001',0,'ACTIVE','0',0.00,'2014-05-15 00:00:00','TONG',0.00,0,'',NULL,NULL,NULL,NULL,NULL,153,NULL,NULL,NULL,NULL,NULL,NULL),('9A','AR','650007','Credit Note','Bad debts written off - trade','005','650007',0,'ACTIVE','0',0.00,'2014-05-15 00:00:00','TONG',0.00,0,'',NULL,NULL,NULL,NULL,NULL,154,NULL,NULL,NULL,NULL,NULL,NULL),('9A','AR','660005','Debit Note','Repair Medical Equipment','006','660005',0,'ACTIVE','0',0.00,'2030-11-11 00:00:00','stlim',0.00,0,'',NULL,NULL,NULL,NULL,NULL,155,NULL,NULL,NULL,NULL,NULL,NULL),('9A','AR','670001','Debit Note','Telephone & Telecommunication','006','670001',0,'ACTIVE','0',0.00,'2025-03-11 00:00:00','SIANG',0.00,0,'',NULL,NULL,NULL,NULL,NULL,156,NULL,NULL,NULL,NULL,NULL,NULL),('9A','AR','670002','Debit Note','Electricity','006','670002',0,'ACTIVE','0',0.00,'2025-03-11 00:00:00','SIANG',0.00,0,'',NULL,NULL,NULL,NULL,NULL,157,NULL,NULL,NULL,NULL,NULL,NULL),('9A','AR','680002','Debit Note','Printing & Stationery','006','680002',0,'ACTIVE','0',0.00,'2026-04-12 00:00:00','WATIE',0.00,0,'',NULL,NULL,NULL,NULL,NULL,158,NULL,NULL,NULL,NULL,NULL,NULL),('9A','AR','680010','Debit Note','Advertisement','006','680010',0,'ACTIVE','0',0.00,'2030-11-11 00:00:00','stlim',0.00,0,'',NULL,NULL,NULL,NULL,NULL,163,NULL,NULL,NULL,NULL,NULL,NULL),('9A','AR','690001','Debit Note','Launching/Events expenses','105','690001',0,'ACTIVE','0',0.00,'2011-03-15 00:00:00','watie',0.00,0,'',NULL,NULL,NULL,NULL,NULL,164,NULL,NULL,NULL,NULL,NULL,NULL),('9A','AR','700007','Debit Note','Gain on FOREX rate','005','700007',0,'ACTIVE','0',0.00,'2003-04-09 00:00:00','ong',0.00,0,'',NULL,NULL,NULL,NULL,NULL,165,NULL,NULL,NULL,NULL,NULL,NULL),('9A','AR','ALLIANCE','Card','ALLIANCE BANK','002','160011',0,'ACTIVE','0',0.00,'2009-02-15 00:00:00','watie',0.00,0,'ALLIANCE',NULL,NULL,NULL,NULL,NULL,166,NULL,NULL,NULL,NULL,NULL,NULL),('9A','AR','AMBANK','Card','AM BANK','1000','50021200',1,'ACTIVE','1',0.00,'2028-08-14 00:00:00','WATIE',0.00,1,'MBB','',NULL,'farid','2016-09-09 17:02:01',NULL,167,NULL,NULL,NULL,NULL,NULL,NULL),('9A','AR','AMBDEBIT','Card','AMBANK-DEBIT CARD','002','160011',0,'ACTIVE','0',0.00,'2003-12-14 00:00:00','WATIE',0.00,0,'AMBDEBIT',NULL,NULL,NULL,NULL,NULL,168,NULL,NULL,NULL,NULL,NULL,NULL),('9A','AR','AMEX','Card','AMEX CARD','002','160011',0,'ACTIVE','0',3.95,'2002-05-07 00:00:00','tajul',0.00,0,'AMEX',NULL,NULL,NULL,NULL,NULL,169,NULL,NULL,NULL,NULL,NULL,NULL),('9A','AR','CASH','Cash','CASH IN HAND','1000','50021100',0,'ACTIVE','0',0.00,'2002-05-07 00:00:00','tajul',0.00,1,'','','0000-00-00 00:00:00','farid','2017-01-27 11:45:14',NULL,170,'','',NULL,NULL,NULL,NULL),('9A','AR','CITIBANK','Card','CITIBANK CARD CENTRE','006','160011',0,'ACTIVE','0',0.00,'2010-03-15 00:00:00','SAMANTHA',0.00,0,'CITIBANK',NULL,NULL,NULL,NULL,NULL,173,NULL,NULL,NULL,NULL,NULL,NULL),('9A','AR','DINERS','Card','DINERS CARD','002','160011',0,'ACTIVE','0',3.00,'2002-05-07 00:00:00','tajul',0.00,0,'DINERS',NULL,NULL,NULL,NULL,NULL,174,NULL,NULL,NULL,NULL,NULL,NULL),('9A','AR','HLBB','Card','HONG LEONG BANK','002','160011',0,'ACTIVE','0',0.00,'2009-02-15 00:00:00','watie',0.00,0,'HLBB',NULL,NULL,NULL,NULL,NULL,178,NULL,NULL,NULL,NULL,NULL,NULL),('9A','AR','HLBB-CC','Card','HONG LEONG BANK CARD','002','160011',0,'ACTIVE','0',0.00,'2023-02-09 00:00:00','ong',0.00,0,'HLBB-CC',NULL,NULL,NULL,NULL,NULL,179,NULL,NULL,NULL,NULL,NULL,NULL),('9A','AR','HSBC','Card','HSBC CARD','002','160011',0,'ACTIVE','0',1.60,'2002-05-07 00:00:00','tajul',0.00,0,'HSBC',NULL,NULL,NULL,NULL,NULL,180,NULL,NULL,NULL,NULL,NULL,NULL),('9A','AR','HSBC-12','Card','HSBC CARD-12','002','160011',0,'ACTIVE','0',5.50,'2004-06-07 00:00:00','ong',0.00,0,'HSBC',NULL,NULL,NULL,NULL,NULL,183,NULL,NULL,NULL,NULL,NULL,NULL),('9A','AR','HSBC-6','Card','HSBC CARD-6','006','160011',0,'ACTIVE','0',3.50,'2023-05-07 00:00:00','ong',0.00,0,'HSBC',NULL,NULL,NULL,NULL,NULL,184,NULL,NULL,NULL,NULL,NULL,NULL),('9A','AR','HSBC-INT','Card','HSBC INTERLINK','006','160011',0,'ACTIVE','0',1.50,'2023-05-07 00:00:00','ong',0.00,0,'HSBC',NULL,NULL,NULL,NULL,NULL,185,NULL,NULL,NULL,NULL,NULL,NULL),('9A','AR','HSBC-JCB','Card','HSBC CARD-JCB','002','160011',0,'ACTIVE','0',3.25,'2004-06-07 00:00:00','ong',0.00,0,'HSBC',NULL,NULL,NULL,NULL,NULL,186,NULL,NULL,NULL,NULL,NULL,NULL),('9A','AR','MBB','Card','MAYBANK CARD','002','160011',0,'ACTIVE','0',0.00,'2022-02-08 00:00:00','ong',0.00,0,'MBB',NULL,NULL,NULL,NULL,NULL,187,NULL,NULL,NULL,NULL,NULL,NULL),('9A','AR','MBB-12','Card','MAYBANK CARD-12','002','160011',0,'ACTIVE','0',0.00,'2022-02-08 00:00:00','ong',0.00,0,'MBB',NULL,NULL,NULL,NULL,NULL,188,NULL,NULL,NULL,NULL,NULL,NULL),('9A','AR','MBB-24','Card','MAYBANK CARD-24','002','160011',0,'ACTIVE','0',0.00,'2022-02-08 00:00:00','ong',0.00,0,'MBB',NULL,NULL,NULL,NULL,NULL,189,NULL,NULL,NULL,NULL,NULL,NULL),('9A','AR','MBB-36','Card','MAYBANK CARD-36','002','160011',0,'ACTIVE','0',0.00,'2022-02-08 00:00:00','ong',0.00,0,'MBB',NULL,NULL,NULL,NULL,NULL,190,NULL,NULL,NULL,NULL,NULL,NULL),('9A','AR','MBB-6','Card','MAYBANK CARD-6','002','160011',0,'ACTIVE','0',0.00,'2022-02-08 00:00:00','ong',0.00,0,'MBB',NULL,NULL,NULL,NULL,NULL,191,NULL,NULL,NULL,NULL,NULL,NULL),('9A','AR','MBB-EPOS','Card','MAYBANK CARD-EPOS','002','160011',0,'ACTIVE','0',0.00,'2022-02-08 00:00:00','ong',0.00,0,'MBB',NULL,NULL,NULL,NULL,NULL,192,NULL,NULL,NULL,NULL,NULL,NULL),('9A','AR','MBB-JCB','Card','MAYBANK CARD-JCB','002','160011',0,'ACTIVE','0',0.00,'2022-02-08 00:00:00','ong',0.00,0,'MBB',NULL,NULL,NULL,NULL,NULL,193,NULL,NULL,NULL,NULL,NULL,NULL),('9A','AR','MBBDEBIT','Card','MAYBANK DEBIT CARD','006','160011',0,'ACTIVE','0',0.00,'2019-08-14 00:00:00','WATIE',0.00,0,'MBB',NULL,NULL,NULL,NULL,NULL,194,NULL,NULL,NULL,NULL,NULL,NULL),('9A','AR','MBF','Card','MBF CARD','002','160011',0,'ACTIVE','0',1.60,'2002-05-07 00:00:00','tajul',0.00,0,'MBF',NULL,NULL,NULL,NULL,NULL,195,NULL,NULL,NULL,NULL,NULL,NULL),('9A','AR','PBBDEBIT','Card','PBB DEBIT CARD','002','160011',0,'ACTIVE','0',0.00,'2003-12-14 00:00:00','WATIE',0.00,0,'PBBDEBIT',NULL,NULL,NULL,NULL,NULL,196,NULL,NULL,NULL,NULL,NULL,NULL),('9A','AR','SCB','Card','SCB CARD','1000','50021100',1,'ACTIVE','1',1.90,'2014-12-07 00:00:00','ong',0.00,1,'SCB',NULL,NULL,'farid','2016-07-18 14:51:13',NULL,197,NULL,NULL,NULL,NULL,NULL,NULL),('9A','AR','UOB','Card','UOB BANK','002','160011',0,'ACTIVE','0',0.00,'2009-02-15 00:00:00','watie',0.00,0,'UOB',NULL,NULL,NULL,NULL,NULL,198,NULL,NULL,NULL,NULL,NULL,NULL),('9A','AR','VISAPBB','Card','VISA PUBLIC BANK','1000','10010000',0,'ACTIVE','0',0.00,'2002-12-14 00:00:00','watie',0.00,0,'PBB','','0000-00-00 00:00:00','farid','2017-07-18 15:45:57',NULL,199,'mira-PC','192.168.0.106',NULL,NULL,NULL,NULL),('9A','AP','bbb','Bank','nnn','101','10010002',1,'DEACTIVE','0',NULL,NULL,'mm',NULL,0,NULL,'farid','2016-02-15 16:21:28',NULL,NULL,NULL,212,NULL,NULL,NULL,NULL,'farid','2017-07-26 10:04:44'),('9A','AR','cimb','Card','CIMB ','1000','50021004',0,'ACTIVE','0',NULL,NULL,'',NULL,1,'MBB','farid','2016-05-30 14:57:03','farid','2016-07-22 10:25:48',NULL,217,NULL,NULL,NULL,NULL,NULL,NULL),('9A','AR','DN','Debit Note','Test DNS','1001','10010002',1,'ACTIVE','1',NULL,NULL,NULL,NULL,1,'','farid','2016-08-02 14:52:56','farid','2016-08-30 10:30:30',NULL,219,NULL,NULL,NULL,NULL,NULL,NULL),('9A','CM','TT','Tele Transfer','TELE TRANSFER','1000','50030508',1,'ACTIVE','1',NULL,NULL,NULL,NULL,1,'','farid','2017-01-03 16:07:58','','0000-00-00 00:00:00',NULL,221,'tajul-PC','192.168.0.119',NULL,NULL,NULL,NULL),('9A','AR','RAKYAT','Bank','BANK RAKYAT','1000','50030508',1,'ACTIVE','1',NULL,NULL,NULL,NULL,1,'RAKYAT','farid','2017-01-06 15:28:09','','0000-00-00 00:00:00',NULL,222,'tajul-PC','192.168.0.128',NULL,NULL,NULL,NULL),('9A','AR','TEST1','Bank Draft','Test12','1000','10010000',1,'DEACTIVE','1',NULL,NULL,NULL,NULL,1,'','farid','2017-07-18 15:50:21','farid','2017-07-26 09:58:45',NULL,223,'mira-PC','192.168.0.106','mira-PC','192.168.0.108','farid','2017-07-26 10:02:11');
/*!40000 ALTER TABLE `paymode` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `provbddt`
--

DROP TABLE IF EXISTS `provbddt`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `provbddt` (
  `compcode` varchar(2) DEFAULT NULL,
  `source` varchar(30) DEFAULT NULL,
  `trantype` varchar(30) DEFAULT NULL,
  `auditno` int(11) DEFAULT NULL,
  `lineno_` int(11) DEFAULT NULL,
  `refsource` varchar(2) NOT NULL,
  `reftrantype` varchar(2) NOT NULL,
  `refauditno` int(11) NOT NULL,
  `reflineno` int(11) DEFAULT NULL,
  `outamount` decimal(9,2) DEFAULT NULL,
  `entrydate` datetime DEFAULT NULL,
  `postdate` datetime DEFAULT NULL,
  `debtorcode` varchar(17) DEFAULT NULL,
  `upddate` datetime DEFAULT NULL,
  `upduser` varchar(10) DEFAULT NULL,
  `hdrsts` varchar(30) DEFAULT NULL,
  `adduser` varchar(30) DEFAULT NULL,
  `adddate` datetime DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `provbddt`
--

LOCK TABLES `provbddt` WRITE;
/*!40000 ALTER TABLE `provbddt` DISABLE KEYS */;
/*!40000 ALTER TABLE `provbddt` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `provbdhd`
--

DROP TABLE IF EXISTS `provbdhd`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `provbdhd` (
  `compcode` varchar(2) DEFAULT NULL,
  `source` varchar(2) DEFAULT NULL,
  `trantype` varchar(2) DEFAULT NULL,
  `auditno` int(11) DEFAULT NULL,
  `postdate` datetime DEFAULT NULL,
  `amount` decimal(10,2) DEFAULT NULL,
  `adduser` varchar(30) DEFAULT NULL,
  `adddate` datetime DEFAULT NULL,
  `upduser` varchar(30) DEFAULT NULL,
  `upddate` datetime DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `provbdhd`
--

LOCK TABLES `provbdhd` WRITE;
/*!40000 ALTER TABLE `provbdhd` DISABLE KEYS */;
/*!40000 ALTER TABLE `provbdhd` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `refferaldtl`
--

DROP TABLE IF EXISTS `refferaldtl`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `refferaldtl` (
  `compcode` varchar(2) DEFAULT NULL,
  `admsrccode` varchar(30) DEFAULT NULL,
  `effectdate` datetime DEFAULT NULL,
  `chggroup` varchar(30) DEFAULT NULL,
  `chgcode` varchar(15) DEFAULT NULL,
  `sharingpercentage` decimal(7,2) DEFAULT NULL,
  `sharingamt` decimal(7,2) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `refferaldtl`
--

LOCK TABLES `refferaldtl` WRITE;
/*!40000 ALTER TABLE `refferaldtl` DISABLE KEYS */;
/*!40000 ALTER TABLE `refferaldtl` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `refferalfees`
--

DROP TABLE IF EXISTS `refferalfees`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `refferalfees` (
  `compcode` varchar(2) DEFAULT NULL,
  `admsrccode` varchar(30) DEFAULT NULL,
  `effectdate` datetime DEFAULT NULL,
  `hospitalrev` varchar(30) DEFAULT NULL,
  `chggroup` varchar(30) DEFAULT NULL,
  `sharingpercentage` decimal(7,2) DEFAULT NULL,
  `sharingamt` decimal(7,2) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `refferalfees`
--

LOCK TABLES `refferalfees` WRITE;
/*!40000 ALTER TABLE `refferalfees` DISABLE KEYS */;
/*!40000 ALTER TABLE `refferalfees` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `stdagedd`
--

DROP TABLE IF EXISTS `stdagedd`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `stdagedd` (
  `compcode` varchar(30) DEFAULT NULL,
  `stddebtcode` varchar(20) DEFAULT NULL,
  `debtorcode` varchar(20) DEFAULT NULL,
  `debtorgroup` varchar(20) DEFAULT NULL,
  `recstatus` varchar(30) DEFAULT NULL,
  `ccgroup` varchar(20) DEFAULT NULL,
  `finclass` varchar(30) DEFAULT NULL,
  `fctype` varchar(30) DEFAULT NULL,
  `yy` int(11) DEFAULT NULL,
  `mm` int(11) DEFAULT NULL,
  `dd` datetime DEFAULT NULL,
  `age1` decimal(11,2) DEFAULT NULL,
  `age2` decimal(11,2) DEFAULT NULL,
  `age3` decimal(11,2) DEFAULT NULL,
  `age4` decimal(11,2) DEFAULT NULL,
  `age5` decimal(11,2) DEFAULT NULL,
  `age6` decimal(11,2) DEFAULT NULL,
  `age7` decimal(11,2) DEFAULT NULL,
  `age8` decimal(11,2) DEFAULT NULL,
  `age9` decimal(11,2) DEFAULT NULL,
  `age10` decimal(11,2) DEFAULT NULL,
  `age11` decimal(11,2) DEFAULT NULL,
  `age12` decimal(11,2) DEFAULT NULL,
  `procdate` datetime DEFAULT NULL,
  `proctime` varchar(30) DEFAULT NULL,
  `collectorgrp` varchar(20) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `stdagedd`
--

LOCK TABLES `stdagedd` WRITE;
/*!40000 ALTER TABLE `stdagedd` DISABLE KEYS */;
/*!40000 ALTER TABLE `stdagedd` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `stdagemm`
--

DROP TABLE IF EXISTS `stdagemm`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `stdagemm` (
  `compcode` varchar(30) DEFAULT NULL,
  `stddebtcode` varchar(20) DEFAULT NULL,
  `debtorcode` varchar(20) DEFAULT NULL,
  `debtorgroup` varchar(20) DEFAULT NULL,
  `recstatus` varchar(30) DEFAULT NULL,
  `ccgroup` varchar(20) DEFAULT NULL,
  `finclass` varchar(30) DEFAULT NULL,
  `fctype` varchar(30) DEFAULT NULL,
  `yy` int(11) DEFAULT NULL,
  `mm` int(11) DEFAULT NULL,
  `dd` datetime DEFAULT NULL,
  `age1` decimal(11,2) DEFAULT NULL,
  `age2` decimal(11,2) DEFAULT NULL,
  `age3` decimal(11,2) DEFAULT NULL,
  `age4` decimal(11,2) DEFAULT NULL,
  `age5` decimal(11,2) DEFAULT NULL,
  `age6` decimal(11,2) DEFAULT NULL,
  `age7` decimal(11,2) DEFAULT NULL,
  `age8` decimal(11,2) DEFAULT NULL,
  `age9` decimal(11,2) DEFAULT NULL,
  `age10` decimal(11,2) DEFAULT NULL,
  `age11` decimal(11,2) DEFAULT NULL,
  `age12` decimal(11,2) DEFAULT NULL,
  `procdate` datetime DEFAULT NULL,
  `proctime` varchar(30) DEFAULT NULL,
  `collectorgrp` varchar(20) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `stdagemm`
--

LOCK TABLES `stdagemm` WRITE;
/*!40000 ALTER TABLE `stdagemm` DISABLE KEYS */;
/*!40000 ALTER TABLE `stdagemm` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `stddebtorgrp`
--

DROP TABLE IF EXISTS `stddebtorgrp`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `stddebtorgrp` (
  `compcode` varchar(30) DEFAULT NULL,
  `stddebtorgrp` varchar(20) DEFAULT NULL,
  `description` varchar(50) DEFAULT NULL,
  `finclass` varchar(30) DEFAULT NULL,
  `recstatus` varchar(30) DEFAULT NULL,
  `adduser` varchar(30) DEFAULT NULL,
  `adddate` datetime DEFAULT NULL,
  `upduser` varchar(30) DEFAULT NULL,
  `upddate` datetime DEFAULT NULL,
  `field100` varchar(30) DEFAULT NULL,
  `field101` varchar(30) DEFAULT NULL,
  `field102` varchar(30) DEFAULT NULL,
  `field103` varchar(30) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `stddebtorgrp`
--

LOCK TABLES `stddebtorgrp` WRITE;
/*!40000 ALTER TABLE `stddebtorgrp` DISABLE KEYS */;
/*!40000 ALTER TABLE `stddebtorgrp` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `stddebtormast`
--

DROP TABLE IF EXISTS `stddebtormast`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `stddebtormast` (
  `compcode` varchar(30) DEFAULT NULL,
  `stddebtcode` varchar(20) DEFAULT NULL,
  `debtorcode` varchar(20) DEFAULT NULL,
  `debtorgroup` varchar(20) DEFAULT NULL,
  `recstatus` varchar(30) DEFAULT NULL,
  `ccgroup` varchar(20) DEFAULT NULL,
  `finclass` varchar(30) DEFAULT NULL,
  `fctype` varchar(30) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `stddebtormast`
--

LOCK TABLES `stddebtormast` WRITE;
/*!40000 ALTER TABLE `stddebtormast` DISABLE KEYS */;
/*!40000 ALTER TABLE `stddebtormast` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `taxalloc`
--

DROP TABLE IF EXISTS `taxalloc`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `taxalloc` (
  `compcode` varchar(2) DEFAULT NULL,
  `source` varchar(2) NOT NULL,
  `trantype` varchar(2) DEFAULT NULL,
  `auditno` int(11) NOT NULL,
  `lineno_` int(11) DEFAULT NULL,
  `billno` int(11) DEFAULT NULL,
  `billlineno` int(11) DEFAULT NULL,
  `allocinvamt` decimal(9,2) DEFAULT NULL,
  `allocdate` datetime DEFAULT NULL,
  `alloctaxablepaid` decimal(9,2) DEFAULT NULL,
  `alloctaxpaid` decimal(9,2) DEFAULT NULL,
  `lastuser` varchar(30) DEFAULT NULL,
  `lastupdate` datetime DEFAULT NULL,
  `day` int(11) DEFAULT NULL,
  `month` int(11) DEFAULT NULL,
  `year` int(11) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `taxalloc`
--

LOCK TABLES `taxalloc` WRITE;
/*!40000 ALTER TABLE `taxalloc` DISABLE KEYS */;
/*!40000 ALTER TABLE `taxalloc` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `taxallocos`
--

DROP TABLE IF EXISTS `taxallocos`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `taxallocos` (
  `compcode` varchar(2) DEFAULT NULL,
  `billno` int(11) DEFAULT NULL,
  `lineno_` int(11) DEFAULT NULL,
  `allocinvamt` decimal(9,2) DEFAULT NULL,
  `allocdate` datetime DEFAULT NULL,
  `alloctaxablepaid` decimal(9,2) DEFAULT NULL,
  `alloctaxpaid` decimal(9,2) DEFAULT NULL,
  `lastuser` varchar(30) DEFAULT NULL,
  `lastupdate` datetime DEFAULT NULL,
  `day` int(11) DEFAULT NULL,
  `month` int(11) DEFAULT NULL,
  `year` int(11) DEFAULT NULL,
  `mrn` int(11) DEFAULT NULL,
  `episno` int(11) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `taxallocos`
--

LOCK TABLES `taxallocos` WRITE;
/*!40000 ALTER TABLE `taxallocos` DISABLE KEYS */;
/*!40000 ALTER TABLE `taxallocos` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `taxitem`
--

DROP TABLE IF EXISTS `taxitem`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `taxitem` (
  `compcode` varchar(2) DEFAULT NULL,
  `billno` int(11) DEFAULT NULL,
  `lineno_` int(11) DEFAULT NULL,
  `invamt` decimal(9,2) DEFAULT NULL,
  `taxableamt` decimal(9,2) DEFAULT NULL,
  `taxamt` decimal(9,2) DEFAULT NULL,
  `invpaid` decimal(9,2) DEFAULT NULL,
  `taxablepaid` decimal(9,2) DEFAULT NULL,
  `taxpaid` decimal(9,2) DEFAULT NULL,
  `taxoutamt` decimal(9,2) DEFAULT NULL,
  `paidfull` tinyint(4) DEFAULT NULL,
  `invdate` datetime DEFAULT NULL,
  `day` int(11) DEFAULT NULL,
  `month` int(11) DEFAULT NULL,
  `year` int(11) DEFAULT NULL,
  `lastuser` varchar(30) DEFAULT NULL,
  `lastupdate` datetime DEFAULT NULL,
  `mrn` int(11) DEFAULT NULL,
  `episno` int(11) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `taxitem`
--

LOCK TABLES `taxitem` WRITE;
/*!40000 ALTER TABLE `taxitem` DISABLE KEYS */;
/*!40000 ALTER TABLE `taxitem` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `taxtable`
--

DROP TABLE IF EXISTS `taxtable`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `taxtable` (
  `compcode` varchar(2) DEFAULT NULL,
  `taxyear` int(11) DEFAULT NULL,
  `taxmonth` int(11) DEFAULT NULL,
  `taxday` int(11) DEFAULT NULL,
  `taxableamt` decimal(9,2) DEFAULT NULL,
  `taxablepaid` decimal(9,2) DEFAULT NULL,
  `taxpaid` decimal(9,2) DEFAULT NULL,
  `taxablepaidos` decimal(9,2) DEFAULT NULL,
  `taxpaidos` decimal(9,2) DEFAULT NULL,
  `lastuser` varchar(30) DEFAULT NULL,
  `lastupdate` datetime DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `taxtable`
--

LOCK TABLES `taxtable` WRITE;
/*!40000 ALTER TABLE `taxtable` DISABLE KEYS */;
/*!40000 ALTER TABLE `taxtable` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `till`
--

DROP TABLE IF EXISTS `till`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `till` (
  `compcode` varchar(2) DEFAULT NULL,
  `tillcode` varchar(30) NOT NULL,
  `description` varchar(40) DEFAULT NULL,
  `defopenamt` decimal(9,2) DEFAULT NULL,
  `dept` varchar(30) DEFAULT NULL,
  `effectdate` date DEFAULT NULL,
  `tillstatus` varchar(1) DEFAULT NULL,
  `upddate` datetime DEFAULT NULL,
  `upduser` varchar(30) DEFAULT NULL,
  `adddate` datetime DEFAULT NULL,
  `adduser` varchar(30) DEFAULT NULL,
  `deldate` datetime DEFAULT NULL,
  `deluser` varchar(30) DEFAULT NULL,
  `recstatus` varchar(55) DEFAULT NULL,
  `usrid` varchar(30) DEFAULT NULL,
  `lastuser` varchar(30) DEFAULT NULL,
  `lastrcnumber` int(11) DEFAULT NULL,
  `lastrefundno` int(11) DEFAULT NULL,
  `lastcrnoteno` int(11) DEFAULT NULL,
  `lastinnumber` int(30) NOT NULL,
  `computerid` varchar(20) DEFAULT NULL,
  `ipaddress` varchar(20) DEFAULT NULL,
  UNIQUE KEY `pkey` (`compcode`,`tillcode`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `till`
--

LOCK TABLES `till` WRITE;
/*!40000 ALTER TABLE `till` DISABLE KEYS */;
INSERT INTO `till` VALUES ('9A','CSH1','CASHIER 1',100.00,'PHAR','2016-09-01','O','2022-03-31 11:30:54','FARID2','2016-09-08 15:48:18','farid',NULL,NULL,'ACTIVE',NULL,NULL,1,1,1,1,NULL,NULL),('9A','CSH2','CASHIER 2',100.00,'PHAR','2016-09-01','C','2022-03-31 11:23:36','FARID2','2016-09-08 15:49:01','farid',NULL,NULL,'ACTIVE',NULL,NULL,23,1,1,1,NULL,NULL),('9A','CSH3','CASHIER 3',1.00,'4FL','2022-03-22','C',NULL,NULL,'2022-03-23 15:47:24','farid2',NULL,NULL,'ACTIVE',NULL,NULL,1,1,1,1,NULL,NULL);
/*!40000 ALTER TABLE `till` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `tilldetl`
--

DROP TABLE IF EXISTS `tilldetl`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `tilldetl` (
  `idno` int(11) NOT NULL AUTO_INCREMENT,
  `compcode` varchar(2) DEFAULT NULL,
  `tillcode` varchar(30) DEFAULT NULL,
  `tillno` int(11) DEFAULT NULL,
  `opendate` datetime DEFAULT NULL,
  `opentime` time DEFAULT NULL,
  `openamt` decimal(8,2) DEFAULT NULL,
  `closedate` datetime DEFAULT NULL,
  `closetime` time DEFAULT NULL,
  `cashamt` decimal(9,2) DEFAULT NULL,
  `cardamt` decimal(9,2) DEFAULT NULL,
  `cheqamt` decimal(9,2) DEFAULT NULL,
  `cnamt` decimal(9,2) DEFAULT NULL,
  `otheramt` decimal(9,2) DEFAULT NULL,
  `refcashamt` decimal(10,2) DEFAULT NULL,
  `refcardamt` decimal(9,2) DEFAULT NULL,
  `refchqamt` decimal(9,2) DEFAULT NULL,
  `actclosebal` decimal(9,2) DEFAULT NULL,
  `reason` varchar(40) DEFAULT NULL,
  `cashier` varchar(30) DEFAULT NULL,
  `upddate` datetime DEFAULT NULL,
  `upduser` varchar(33) DEFAULT NULL,
  `adddate` datetime DEFAULT NULL,
  `adduser` varchar(33) DEFAULT NULL,
  `deldate` datetime DEFAULT NULL,
  `deluser` varchar(33) DEFAULT NULL,
  `recstatus` varchar(5) DEFAULT NULL,
  PRIMARY KEY (`idno`),
  KEY `cashierclosed` (`compcode`,`closedate`,`cashier`),
  KEY `cashieropen` (`compcode`,`opendate`,`cashier`)
) ENGINE=InnoDB AUTO_INCREMENT=3 DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `tilldetl`
--

LOCK TABLES `tilldetl` WRITE;
/*!40000 ALTER TABLE `tilldetl` DISABLE KEYS */;
INSERT INTO `tilldetl` VALUES (1,'9A','CSH2',NULL,'2022-03-31 11:23:36','11:23:36',NULL,'2022-03-31 11:30:34',NULL,100.00,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'farid2',NULL,NULL,NULL,NULL,NULL,NULL,NULL),(2,'9A','CSH1',NULL,'2022-03-31 11:30:54','11:30:54',NULL,NULL,NULL,100.00,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'farid2',NULL,NULL,NULL,NULL,NULL,NULL,NULL);
/*!40000 ALTER TABLE `tilldetl` ENABLE KEYS */;
UNLOCK TABLES;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2022-10-13 22:51:36
