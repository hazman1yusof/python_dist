-- MySQL dump 10.13  Distrib 5.7.24, for Win64 (x86_64)
--
-- Host: localhost    Database: nursing
-- ------------------------------------------------------
-- Server version	5.7.24

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `antenatal`
--

DROP TABLE IF EXISTS `antenatal`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `antenatal` (
  `idno` int(10) NOT NULL AUTO_INCREMENT,
  `compcode` varchar(30) DEFAULT NULL,
  `mrn` int(11) DEFAULT NULL,
  `blood_grp` varchar(11) DEFAULT NULL,
  `height` decimal(7,2) DEFAULT NULL,
  `rhesus_factor` varchar(255) DEFAULT NULL,
  `rubella` decimal(7,2) DEFAULT NULL,
  `VDRL` decimal(7,2) DEFAULT NULL,
  `HIV` decimal(7,2) DEFAULT NULL,
  `hep_B_Ag` varchar(255) DEFAULT NULL,
  `hep_B_AB` varchar(255) DEFAULT NULL,
  `first_dose` date DEFAULT NULL,
  `second_dose` date DEFAULT NULL,
  `booster` date DEFAULT NULL,
  `blood_trans` varchar(255) DEFAULT NULL,
  `drug_allergy` text,
  `pgh_myomectomy` tinyint(4) DEFAULT NULL,
  `pgh_laparoscopy` tinyint(4) DEFAULT NULL,
  `pgh_endomet` tinyint(4) DEFAULT NULL,
  `pgh_lastpapsmear` date DEFAULT NULL,
  `pgh_others` text,
  `pmh_renal` tinyint(4) DEFAULT NULL,
  `pmh_hypertension` tinyint(4) DEFAULT NULL,
  `pmh_diabetes` tinyint(4) DEFAULT NULL,
  `pmh_heart` tinyint(4) DEFAULT NULL,
  `pmh_others` text,
  `psh_appendic` tinyint(4) DEFAULT NULL,
  `psh_hypertension` tinyint(4) DEFAULT NULL,
  `psh_laparotomy` tinyint(4) DEFAULT NULL,
  `psh_thyroid` tinyint(4) DEFAULT NULL,
  `psh_others` text,
  `fh_hypertension` tinyint(4) DEFAULT NULL,
  `fh_diabetes` tinyint(4) DEFAULT NULL,
  `fh_epilepsy` tinyint(4) DEFAULT NULL,
  `fh_multipregnan` tinyint(4) DEFAULT NULL,
  `fh_congenital` text,
  `sysexam_date` date DEFAULT NULL,
  `sysexam_varicose` varchar(255) DEFAULT NULL,
  `sysexam_pallor` varchar(255) DEFAULT NULL,
  `sysexam_jaundice` varchar(255) DEFAULT NULL,
  `sysexam_oral` varchar(255) DEFAULT NULL,
  `sysexam_thyroid` varchar(255) DEFAULT NULL,
  `sysexam_breastr` varchar(255) DEFAULT NULL,
  `sysexam_breastl` varchar(255) DEFAULT NULL,
  `sysexam_cvs` varchar(255) DEFAULT NULL,
  `sysexam_resp` varchar(255) DEFAULT NULL,
  `sysexam_abdomen` varchar(255) DEFAULT NULL,
  `sysexam_remark` text,
  `adduser` varchar(30) DEFAULT NULL,
  `adddate` date DEFAULT NULL,
  `lastuser` varchar(30) DEFAULT NULL,
  `lastupdate` datetime DEFAULT NULL,
  PRIMARY KEY (`idno`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `antenatal`
--

LOCK TABLES `antenatal` WRITE;
/*!40000 ALTER TABLE `antenatal` DISABLE KEYS */;
/*!40000 ALTER TABLE `antenatal` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `antenatal_history`
--

DROP TABLE IF EXISTS `antenatal_history`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `antenatal_history` (
  `idno` int(10) NOT NULL AUTO_INCREMENT,
  `compcode` varchar(90) DEFAULT NULL,
  `mrn` int(11) DEFAULT NULL,
  `year` int(4) DEFAULT NULL,
  `gestation` varchar(90) DEFAULT NULL,
  `placedeliver` varchar(765) DEFAULT NULL,
  `lab_del` varchar(90) DEFAULT NULL,
  `purperium` varchar(90) DEFAULT NULL,
  `weight` decimal(9,0) DEFAULT NULL,
  `sex` varchar(30) DEFAULT NULL,
  `breastfed` varchar(30) DEFAULT NULL,
  `comments` varchar(765) DEFAULT NULL,
  `adduser` varchar(90) DEFAULT NULL,
  `adddate` date DEFAULT NULL,
  `lastuser` varchar(90) DEFAULT NULL,
  `lastupdate` datetime DEFAULT NULL,
  PRIMARY KEY (`idno`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `antenatal_history`
--

LOCK TABLES `antenatal_history` WRITE;
/*!40000 ALTER TABLE `antenatal_history` DISABLE KEYS */;
/*!40000 ALTER TABLE `antenatal_history` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `antenatal_ultrasound`
--

DROP TABLE IF EXISTS `antenatal_ultrasound`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `antenatal_ultrasound` (
  `idno` int(10) NOT NULL AUTO_INCREMENT,
  `compcode` varchar(30) DEFAULT NULL,
  `pregnan_idno` int(11) DEFAULT NULL,
  `mrn` int(11) DEFAULT NULL,
  `date` date DEFAULT NULL,
  `poa` int(10) DEFAULT NULL,
  `pog` int(10) DEFAULT NULL,
  `crl` decimal(7,2) DEFAULT NULL,
  `crl_w` decimal(7,2) DEFAULT NULL,
  `crl_d` decimal(7,2) DEFAULT NULL,
  `bpd` decimal(7,2) DEFAULT NULL,
  `bpd_w` decimal(7,2) DEFAULT NULL,
  `bpd_d` decimal(7,2) DEFAULT NULL,
  `hc` decimal(7,2) DEFAULT NULL,
  `hc_w` decimal(7,2) DEFAULT NULL,
  `hc_d` decimal(7,2) DEFAULT NULL,
  `ac` decimal(7,2) DEFAULT NULL,
  `ac_w` decimal(7,2) DEFAULT NULL,
  `ac_d` decimal(7,2) DEFAULT NULL,
  `fl` decimal(7,2) DEFAULT NULL,
  `fl_w` decimal(7,2) DEFAULT NULL,
  `fl_d` decimal(7,2) DEFAULT NULL,
  `atd` decimal(7,2) DEFAULT NULL,
  `atd_w` decimal(7,2) DEFAULT NULL,
  `atd_d` decimal(7,2) DEFAULT NULL,
  `ald` decimal(7,2) DEFAULT NULL,
  `ald_w` decimal(7,2) DEFAULT NULL,
  `ald_d` decimal(7,2) DEFAULT NULL,
  `efbw` decimal(7,2) DEFAULT NULL,
  `afi` decimal(7,2) DEFAULT NULL,
  `pres` varchar(30) DEFAULT NULL,
  `placenta` varchar(30) DEFAULT NULL,
  `is_cerebrum_normal` tinyint(4) DEFAULT NULL,
  `cerebrum_hydran` tinyint(4) DEFAULT NULL,
  `cerebrum_holo` tinyint(4) DEFAULT NULL,
  `cerebrum_text` text,
  `pellucidum_normal` tinyint(4) DEFAULT NULL,
  `pellucidum_text` text,
  `falx_normal` tinyint(4) DEFAULT NULL,
  `falx_textCheck` tinyint(4) DEFAULT NULL,
  `falx_text` text,
  `cerebellum_normal` tinyint(4) DEFAULT NULL,
  `cerebellum_textCheck` tinyint(4) DEFAULT NULL,
  `cerebellum_text` text,
  `ventricles_normal` tinyint(4) DEFAULT NULL,
  `ventricles_hydro` tinyint(4) DEFAULT NULL,
  `ventricles_mild` tinyint(4) DEFAULT NULL,
  `ventricles_moderate` tinyint(4) DEFAULT NULL,
  `ventricles_severe` tinyint(4) DEFAULT NULL,
  `cerebrum_normal` tinyint(4) DEFAULT NULL,
  `cerebrum_anencephly` tinyint(4) DEFAULT NULL,
  `cerebrum_mening` tinyint(4) DEFAULT NULL,
  `upperlip_normal` tinyint(4) DEFAULT NULL,
  `upperlip_cleftlip` tinyint(4) DEFAULT NULL,
  `lowerlip_normal` tinyint(4) DEFAULT NULL,
  `lowerlip_text` text,
  `palate_normal` tinyint(4) DEFAULT NULL,
  `palate_cleft` tinyint(4) DEFAULT NULL,
  `nose_normal` tinyint(4) DEFAULT NULL,
  `nose_textCheck` tinyint(4) DEFAULT NULL,
  `nose_text` text,
  `righteyes_normal` tinyint(4) DEFAULT NULL,
  `righteyes_text` text,
  `lefteyes_normal` tinyint(4) DEFAULT NULL,
  `lefteyes_text` text,
  `mandible_normal` tinyint(4) DEFAULT NULL,
  `mandible_macro` tinyint(4) DEFAULT NULL,
  `mandible_micro` tinyint(4) DEFAULT NULL,
  `neck_normal` tinyint(4) DEFAULT NULL,
  `neck_cystic` tinyint(4) DEFAULT NULL,
  `chestwall_normal` tinyint(4) DEFAULT NULL,
  `chestwall_text` text,
  `heartsize_normal` tinyint(4) DEFAULT NULL,
  `heartsize_small` tinyint(4) DEFAULT NULL,
  `fourchamber_normal` tinyint(4) DEFAULT NULL,
  `fourchamber_text` text,
  `aorticarc_normal` tinyint(4) DEFAULT NULL,
  `aorticarc_coarctation` tinyint(4) DEFAULT NULL,
  `aortictrunk_normal` tinyint(4) DEFAULT NULL,
  `aortictrunk_stenosis` tinyint(4) DEFAULT NULL,
  `pulmonary_normal` tinyint(4) DEFAULT NULL,
  `pulmonary_stenosis` tinyint(4) DEFAULT NULL,
  `septum_normal` tinyint(4) DEFAULT NULL,
  `septum_vsd` tinyint(4) DEFAULT NULL,
  `septum_membraneous` tinyint(4) DEFAULT NULL,
  `septum_muscular` tinyint(4) DEFAULT NULL,
  `septum_combined` tinyint(4) DEFAULT NULL,
  `vsdsize` decimal(7,2) DEFAULT NULL,
  `pericardium_normal` tinyint(4) DEFAULT NULL,
  `pericardium_peri` tinyint(4) DEFAULT NULL,
  `otherDefects` varchar(30) DEFAULT NULL,
  `diaphragm_normal` tinyint(4) DEFAULT NULL,
  `diaphragm_hernia` tinyint(4) DEFAULT NULL,
  `lungs_normal` tinyint(4) DEFAULT NULL,
  `lungs_hypo` tinyint(4) DEFAULT NULL,
  `lungs_pleural` tinyint(4) DEFAULT NULL,
  `chestwall_intact` tinyint(4) DEFAULT NULL,
  `chestwall_ompha` tinyint(4) DEFAULT NULL,
  `chestwall_gastro` tinyint(4) DEFAULT NULL,
  `cordA` varchar(30) DEFAULT NULL,
  `cordV` varchar(30) DEFAULT NULL,
  `cordinsert_intact` tinyint(4) DEFAULT NULL,
  `cordinsert_text` text,
  `stomach_normal` tinyint(4) DEFAULT NULL,
  `stomach_double` tinyint(4) DEFAULT NULL,
  `stomach_absent` tinyint(4) DEFAULT NULL,
  `liver_normal` tinyint(4) DEFAULT NULL,
  `liver_hepa` tinyint(4) DEFAULT NULL,
  `liver_hypo` tinyint(4) DEFAULT NULL,
  `rightkidney_normal` tinyint(4) DEFAULT NULL,
  `rightkidney_absent` tinyint(4) DEFAULT NULL,
  `rightkidney_hydro` tinyint(4) DEFAULT NULL,
  `rightkidney_text` text,
  `leftkidney_normal` tinyint(4) DEFAULT NULL,
  `leftkidney_absent` tinyint(4) DEFAULT NULL,
  `leftkidney_hydro` tinyint(4) DEFAULT NULL,
  `leftkidney_text` text,
  `bladder_normal` tinyint(4) DEFAULT NULL,
  `bladder_absent` tinyint(4) DEFAULT NULL,
  `bladder_text` text,
  `ascites_distended` tinyint(4) DEFAULT NULL,
  `ascites_absent` tinyint(4) DEFAULT NULL,
  `ascites_present` tinyint(4) DEFAULT NULL,
  `upperlimbs_1R` int(5) DEFAULT NULL,
  `upperlimbs_2R` int(5) DEFAULT NULL,
  `upperlimbs_3R` int(5) DEFAULT NULL,
  `upperlimbs_1L` int(5) DEFAULT NULL,
  `upperlimbs_2L` int(5) DEFAULT NULL,
  `upperlimbs_3L` int(5) DEFAULT NULL,
  `lowerlimbs_1R` int(5) DEFAULT NULL,
  `lowerlimbs_2R` int(5) DEFAULT NULL,
  `lowerlimbs_3R` int(5) DEFAULT NULL,
  `lowerlimbs_1L` int(5) DEFAULT NULL,
  `lowerlimbs_2L` int(5) DEFAULT NULL,
  `lowerlimbs_3L` int(5) DEFAULT NULL,
  `report` text,
  `adduser` varchar(30) DEFAULT NULL,
  `adddate` date DEFAULT NULL,
  `lastuser` varchar(30) DEFAULT NULL,
  `lastupdate` datetime DEFAULT NULL,
  PRIMARY KEY (`idno`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `antenatal_ultrasound`
--

LOCK TABLES `antenatal_ultrasound` WRITE;
/*!40000 ALTER TABLE `antenatal_ultrasound` DISABLE KEYS */;
/*!40000 ALTER TABLE `antenatal_ultrasound` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `dietorder`
--

DROP TABLE IF EXISTS `dietorder`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `dietorder` (
  `idno` int(10) NOT NULL AUTO_INCREMENT,
  `compcode` varchar(30) DEFAULT NULL,
  `mrn` int(11) DEFAULT NULL,
  `episno` int(11) DEFAULT NULL,
  `lodgerflag` tinyint(4) DEFAULT NULL COMMENT 'additional meals 0 - false / 1 - true',
  `lodgervalue` int(11) DEFAULT NULL COMMENT 'no of lodger appear if lodgerflag -1',
  `nbm` tinyint(4) DEFAULT NULL COMMENT 'Nil by Mouth',
  `rtf` tinyint(4) DEFAULT NULL COMMENT 'Ryles Tube Feeding',
  `rof` tinyint(4) DEFAULT NULL COMMENT 'Restriction of Fluid',
  `tpn` tinyint(4) DEFAULT NULL COMMENT 'Total Parenteral Nutrition',
  `oral` tinyint(4) DEFAULT NULL COMMENT 'Oral',
  `regular_a` tinyint(4) DEFAULT NULL,
  `regular_b` tinyint(4) DEFAULT NULL,
  `soft` tinyint(4) DEFAULT NULL,
  `vegetarian_c` tinyint(4) DEFAULT NULL,
  `western_d` tinyint(4) DEFAULT NULL,
  `highprotein` tinyint(4) DEFAULT NULL,
  `highcalorie` tinyint(4) DEFAULT NULL,
  `highfiber` tinyint(4) DEFAULT NULL,
  `diabetic` tinyint(4) DEFAULT NULL,
  `lowprotein` tinyint(4) DEFAULT NULL,
  `lowfat` tinyint(4) DEFAULT NULL,
  `soft_lodger` tinyint(4) DEFAULT NULL,
  `red1200kcal` tinyint(4) DEFAULT NULL,
  `red1500kcal` tinyint(4) DEFAULT NULL,
  `paed6to12mth` tinyint(4) DEFAULT NULL,
  `paed1to3yr` tinyint(4) DEFAULT NULL,
  `paed4to9yr` tinyint(4) DEFAULT NULL,
  `paedgt10yr` tinyint(4) DEFAULT NULL,
  `disposable` tinyint(4) DEFAULT NULL COMMENT '0 - false / 1 - true',
  `remark` varchar(1000) DEFAULT NULL,
  `lastuser` varchar(30) DEFAULT NULL,
  `lastupdate` datetime DEFAULT NULL,
  `regular_a_lodger` tinyint(4) DEFAULT NULL,
  `regular_b_lodger` tinyint(4) DEFAULT NULL,
  `vegetarian_c_lodger` tinyint(4) DEFAULT NULL,
  `western_d_lodger` tinyint(4) DEFAULT NULL,
  `highprotein_lodger` tinyint(4) DEFAULT NULL,
  `highcalorie_lodger` tinyint(4) DEFAULT NULL,
  `highfiber_lodger` tinyint(4) DEFAULT NULL,
  `diabetic_lodger` tinyint(4) DEFAULT NULL,
  `lowprotein_lodger` tinyint(4) DEFAULT NULL,
  `lowfat_lodger` tinyint(4) DEFAULT NULL,
  `red1200kcal_lodger` tinyint(4) DEFAULT NULL,
  `red1500kcal_lodger` tinyint(4) DEFAULT NULL,
  `paed6to12mth_lodger` tinyint(4) DEFAULT NULL,
  `paed1to3yr_lodger` tinyint(4) DEFAULT NULL,
  `paed4to9yr_lodger` tinyint(4) DEFAULT NULL,
  `paedgt10yr_lodger` tinyint(4) DEFAULT NULL,
  `remarkkitchen` varchar(1000) DEFAULT NULL,
  `adduser` varchar(13) DEFAULT NULL,
  `adddate` date DEFAULT NULL,
  PRIMARY KEY (`idno`),
  KEY `dietorder_key1` (`compcode`,`mrn`,`episno`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `dietorder`
--

LOCK TABLES `dietorder` WRITE;
/*!40000 ALTER TABLE `dietorder` DISABLE KEYS */;
/*!40000 ALTER TABLE `dietorder` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `examination`
--

DROP TABLE IF EXISTS `examination`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `examination` (
  `idno` int(11) NOT NULL AUTO_INCREMENT,
  `compcode` varchar(10) DEFAULT NULL,
  `examcode` varchar(100) DEFAULT NULL,
  `description` varchar(200) DEFAULT NULL,
  `adduser` varchar(20) DEFAULT NULL,
  `adddate` datetime DEFAULT NULL,
  `upduser` varchar(20) DEFAULT NULL,
  `upddate` datetime DEFAULT NULL,
  `lastuser` varchar(20) DEFAULT NULL,
  `lastupdate` datetime DEFAULT NULL,
  PRIMARY KEY (`idno`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `examination`
--

LOCK TABLES `examination` WRITE;
/*!40000 ALTER TABLE `examination` DISABLE KEYS */;
/*!40000 ALTER TABLE `examination` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `gkcasses`
--

DROP TABLE IF EXISTS `gkcasses`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `gkcasses` (
  `compcode` varchar(50) DEFAULT NULL,
  `diagcode` varchar(50) DEFAULT NULL,
  `progress` varchar(100) DEFAULT NULL,
  `description` text,
  `questionnaire` text,
  `idno` int(11) NOT NULL,
  ```` date DEFAULT NULL,
  `last_visit_date` date DEFAULT NULL,
  `cb1` text,
  `cb2` text,
  `cb3` text,
  `cb4` text,
  `cb5` text,
  `cb6` text,
  `cb7` text,
  `cb8` text,
  `tf1` text,
  `tf2` text,
  `tf3` text,
  `tf4` text,
  `tf5` text,
  `tf6` text,
  `tf7` text,
  `tf8` text,
  `op1` text,
  `op2` text,
  `op3` text,
  `op4` text,
  `op5` text,
  `op6` text,
  `op7` text,
  `op8` text,
  `dd1` text,
  `dd2` text,
  `dd3` text,
  `dd4` text,
  `ta1` text,
  `ta2` text,
  `ta3` text,
  `ta4` text,
  PRIMARY KEY (`idno`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `gkcasses`
--

LOCK TABLES `gkcasses` WRITE;
/*!40000 ALTER TABLE `gkcasses` DISABLE KEYS */;
/*!40000 ALTER TABLE `gkcasses` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `gkcdiag`
--

DROP TABLE IF EXISTS `gkcdiag`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `gkcdiag` (
  `idno` int(11) NOT NULL AUTO_INCREMENT,
  `compcode` varchar(5) DEFAULT NULL,
  `diagcode` varchar(111) DEFAULT NULL,
  `Description` varchar(111) DEFAULT NULL,
  `category` varchar(40) DEFAULT NULL,
  PRIMARY KEY (`idno`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `gkcdiag`
--

LOCK TABLES `gkcdiag` WRITE;
/*!40000 ALTER TABLE `gkcdiag` DISABLE KEYS */;
/*!40000 ALTER TABLE `gkcdiag` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `nurassesexam`
--

DROP TABLE IF EXISTS `nurassesexam`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `nurassesexam` (
  `idno` int(10) NOT NULL AUTO_INCREMENT,
  `compcode` varchar(30) DEFAULT NULL,
  `mrn` int(11) DEFAULT NULL,
  `episno` int(11) DEFAULT NULL,
  `location` varchar(100) DEFAULT 'TRIAGE' COMMENT 'TRIAGE/WARD',
  `exam` text,
  `examnote` text,
  `adddate` datetime DEFAULT NULL,
  `adduser` varchar(100) DEFAULT NULL,
  PRIMARY KEY (`idno`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `nurassesexam`
--

LOCK TABLES `nurassesexam` WRITE;
/*!40000 ALTER TABLE `nurassesexam` DISABLE KEYS */;
/*!40000 ALTER TABLE `nurassesexam` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `nursassessgen`
--

DROP TABLE IF EXISTS `nursassessgen`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `nursassessgen` (
  `idno` int(10) NOT NULL AUTO_INCREMENT,
  `compcode` varchar(30) DEFAULT NULL,
  `nursrecid` int(11) DEFAULT NULL,
  `mrn` int(11) DEFAULT NULL,
  `episno` int(11) DEFAULT NULL,
  `br_breathing` tinyint(4) DEFAULT NULL,
  `br_breathingdesc` text,
  `br_cough` tinyint(4) DEFAULT NULL,
  `br_coughdesc` text,
  `br_smoke` tinyint(4) DEFAULT NULL,
  `br_smokedesc` text,
  `ed_eatdrink` tinyint(4) DEFAULT NULL,
  `ed_eatdrinkdesc` text,
  `eb_bowelhabit` tinyint(4) DEFAULT NULL,
  `eb_bowelmove` tinyint(4) DEFAULT NULL,
  `eb_bowelmovedesc` text,
  `bl_urine` tinyint(4) DEFAULT NULL,
  `bl_urinedesc` text,
  `bl_urinefreq` text,
  `sl_sleep` tinyint(4) DEFAULT NULL,
  `mobilityambulan` tinyint(4) DEFAULT NULL,
  `mobilityassistaid` tinyint(4) DEFAULT NULL,
  `mobilitybedridden` tinyint(4) DEFAULT NULL,
  `phygiene_self` tinyint(4) DEFAULT NULL,
  `phygiene_needassist` tinyint(4) DEFAULT NULL,
  `phygiene_dependant` tinyint(4) DEFAULT NULL,
  `safeenv_siderail` tinyint(4) DEFAULT NULL,
  `safeenv_restraint` tinyint(4) DEFAULT NULL,
  `cspeech_normal` tinyint(4) DEFAULT NULL,
  `cspeech_slurred` tinyint(4) DEFAULT NULL,
  `cspeech_impaired` tinyint(4) DEFAULT NULL,
  `cspeech_mute` tinyint(4) DEFAULT NULL,
  `cvision_normal` tinyint(4) DEFAULT NULL,
  `cvision_blurring` tinyint(4) DEFAULT NULL,
  `cvision_doublev` tinyint(4) DEFAULT NULL,
  `cvision_blind` tinyint(4) DEFAULT NULL,
  `cvision_visualaids` tinyint(4) DEFAULT NULL,
  `chearing_normal` tinyint(4) DEFAULT NULL,
  `chearing_deaf` tinyint(4) DEFAULT NULL,
  `chearing_hardhear` tinyint(4) DEFAULT NULL,
  `chearing_hearaids` tinyint(4) DEFAULT NULL,
  `pa_skindry` tinyint(4) DEFAULT NULL,
  `pa_skinodema` tinyint(4) DEFAULT NULL,
  `pa_skinjaundice` tinyint(4) DEFAULT NULL,
  `pa_skinnil` tinyint(4) DEFAULT NULL,
  `pa_othbruises` tinyint(4) DEFAULT NULL,
  `pa_othdeculcer` tinyint(4) DEFAULT NULL,
  `pa_othlaceration` tinyint(4) DEFAULT NULL,
  `pa_othdiscolor` tinyint(4) DEFAULT NULL,
  `pa_othnil` tinyint(4) DEFAULT NULL,
  `pa_notes` text,
  `adduser` varchar(100) DEFAULT NULL,
  `adddate` datetime DEFAULT NULL,
  `addtime` varchar(30) DEFAULT NULL,
  `lastuser` varchar(100) DEFAULT NULL,
  `lastupdate` datetime DEFAULT NULL,
  `lastupdtime` varchar(30) DEFAULT NULL,
  `location` varchar(15) DEFAULT 'TRIAGE' COMMENT 'TRIAGE/WARD',
  `pa_skinnormal` tinyint(4) DEFAULT NULL,
  `arrival_date` date DEFAULT NULL,
  PRIMARY KEY (`idno`),
  UNIQUE KEY `nursassessgen_mrnepislocation` (`compcode`,`mrn`,`episno`,`location`)
) ENGINE=InnoDB AUTO_INCREMENT=50 DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `nursassessgen`
--

LOCK TABLES `nursassessgen` WRITE;
/*!40000 ALTER TABLE `nursassessgen` DISABLE KEYS */;
INSERT INTO `nursassessgen` VALUES (1,'13A',NULL,117,1,0,NULL,0,NULL,0,NULL,0,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,1,0,0,0,1,0,0,0,0,1,0,0,0,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'fadhlina','2022-10-03 00:00:00',NULL,'fadhlina','2022-10-03 00:00:00',NULL,'TRIAGE',NULL,'2022-10-03'),(2,'13A',NULL,82,2,0,NULL,0,NULL,0,NULL,0,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,1,0,0,0,0,0,0,0,1,1,0,0,0,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'aiman.amin','2022-10-03 00:00:00',NULL,'aiman.amin','2022-10-03 00:00:00',NULL,'TRIAGE',NULL,'2022-10-03'),(3,'13A',NULL,115,2,0,NULL,0,NULL,0,NULL,0,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,1,0,0,0,1,0,0,0,0,1,0,0,0,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'muhammadarif','2022-10-03 00:00:00',NULL,'muhammadarif','2022-10-03 00:00:00',NULL,'TRIAGE',NULL,'2022-10-03'),(4,'13A',NULL,3,2,0,NULL,0,NULL,0,NULL,0,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,1,0,0,0,0,1,0,0,0,1,0,0,0,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'aiman.amin','2022-10-03 00:00:00',NULL,'aiman.amin','2022-10-03 00:00:00',NULL,'TRIAGE',NULL,'2022-10-03'),(5,'13A',NULL,87,2,0,NULL,0,NULL,0,NULL,0,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,1,0,0,0,1,0,0,0,0,1,0,0,0,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'muhammadarif','2022-10-03 00:00:00',NULL,'muhammadarif','2022-10-03 00:00:00',NULL,'TRIAGE',NULL,'2022-10-03'),(6,'13A',NULL,33,2,0,NULL,0,NULL,0,NULL,0,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,1,0,0,0,1,0,0,0,0,1,0,0,0,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'aiman.amin','2022-10-03 00:00:00',NULL,'aiman.amin','2022-10-03 00:00:00',NULL,'TRIAGE',NULL,'2022-10-03'),(7,'13A',NULL,71,2,0,NULL,0,NULL,0,NULL,0,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,1,0,0,0,1,0,0,0,0,1,0,0,0,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'fadhlina','2022-10-03 00:00:00',NULL,'fadhlina','2022-10-03 00:00:00',NULL,'TRIAGE',NULL,'2022-10-03'),(8,NULL,NULL,NULL,NULL,0,NULL,0,NULL,0,NULL,0,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,1,0,0,0,1,0,0,0,0,1,0,0,0,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'fadhlina','2022-10-03 00:00:00',NULL,'fadhlina','2022-10-03 00:00:00',NULL,'TRIAGE',NULL,NULL),(9,'13A',NULL,50,2,0,NULL,0,NULL,0,NULL,0,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,1,0,0,0,1,0,0,0,0,1,0,0,0,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'fadhlina','2022-10-03 00:00:00',NULL,'fadhlina','2022-10-03 00:00:00',NULL,'TRIAGE',NULL,'2022-10-03'),(10,NULL,NULL,NULL,NULL,0,NULL,0,NULL,0,NULL,0,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,1,0,0,0,1,0,0,0,0,1,0,0,0,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'fadhlina','2022-10-03 00:00:00',NULL,'fadhlina','2022-10-03 00:00:00',NULL,'TRIAGE',NULL,NULL),(11,'13A',NULL,70,2,0,NULL,0,NULL,0,NULL,0,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,1,0,0,0,1,0,0,0,0,1,0,0,0,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'fadhlina','2022-10-03 00:00:00',NULL,'fadhlina','2022-10-03 00:00:00',NULL,'TRIAGE',NULL,'2022-10-03'),(12,'13A',NULL,72,2,0,NULL,0,NULL,0,NULL,0,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,1,0,0,0,1,0,0,0,0,1,0,0,0,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'muhammadarif','2022-10-03 00:00:00',NULL,'muhammadarif','2022-10-03 00:00:00',NULL,'TRIAGE',NULL,'2022-10-03'),(13,'13A',NULL,77,2,0,NULL,0,NULL,1,NULL,0,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,1,0,0,0,0,1,0,0,0,1,0,0,0,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'muhammadarif','2022-10-03 00:00:00',NULL,'muhammadarif','2022-10-03 00:00:00',NULL,'TRIAGE',NULL,'2022-10-03'),(14,'13A',NULL,41,2,0,NULL,0,NULL,0,NULL,0,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,1,0,0,0,1,0,0,0,0,0,0,1,0,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'muhammadarif','2022-10-03 00:00:00',NULL,'muhammadarif','2022-10-03 00:00:00',NULL,'TRIAGE',NULL,'2022-10-03'),(15,'13A',NULL,96,2,0,NULL,0,NULL,0,NULL,0,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,1,0,0,0,0,1,0,0,0,1,0,0,0,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'muhammadarif','2022-10-03 00:00:00',NULL,'muhammadarif','2022-10-03 00:00:00',NULL,'TRIAGE',NULL,'2022-10-03'),(16,'13A',NULL,64,2,0,NULL,0,NULL,0,NULL,0,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,1,0,0,0,1,0,0,0,0,1,0,0,0,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'muhammadarif','2022-10-03 00:00:00',NULL,'muhammadarif','2022-10-03 00:00:00',NULL,'TRIAGE',NULL,'2022-10-03'),(17,'13A',NULL,112,2,0,NULL,0,NULL,0,NULL,0,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,1,0,0,0,1,0,0,0,0,1,0,0,0,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'muhammadarif','2022-10-03 00:00:00',NULL,'muhammadarif','2022-10-03 00:00:00',NULL,'TRIAGE',NULL,'2022-10-03'),(18,'13A',NULL,76,2,0,NULL,0,NULL,0,NULL,0,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,1,0,0,0,1,0,0,0,0,1,0,0,0,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'muhammadarif','2022-10-03 00:00:00',NULL,'muhammadarif','2022-10-03 00:00:00',NULL,'TRIAGE',NULL,'2022-10-03'),(19,'13A',NULL,29,2,0,NULL,0,NULL,0,NULL,0,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,1,0,0,0,0,1,0,0,0,1,0,0,0,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'AIMAN.AMIN','2022-10-03 00:00:00',NULL,'AIMAN.AMIN','2022-10-03 00:00:00',NULL,'TRIAGE',NULL,'2022-10-03'),(20,'13A',NULL,94,2,0,NULL,0,NULL,0,NULL,0,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,1,0,0,0,0,0,0,0,1,1,0,0,0,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'sitiaishah','2022-10-03 00:00:00',NULL,'sitiaishah','2022-10-03 00:00:00',NULL,'TRIAGE',NULL,'2022-10-03'),(21,'13A',NULL,22,2,0,NULL,0,NULL,0,NULL,0,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,1,0,0,0,1,0,0,0,0,1,0,0,0,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'sitiaishah','2022-10-03 00:00:00',NULL,'sitiaishah','2022-10-03 00:00:00',NULL,'TRIAGE',NULL,'2022-10-03'),(22,'13A',NULL,32,2,0,NULL,0,NULL,0,NULL,0,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,1,0,0,0,1,0,0,0,0,1,0,0,0,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'muhammadarif','2022-10-04 00:00:00',NULL,'muhammadarif','2022-10-04 00:00:00',NULL,'TRIAGE',NULL,'2022-10-04'),(23,'13A',NULL,101,2,0,NULL,0,NULL,0,NULL,0,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,1,0,0,0,0,1,0,0,0,1,0,0,0,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'fadhlina','2022-10-04 00:00:00',NULL,'fadhlina','2022-10-04 00:00:00',NULL,'TRIAGE',NULL,'2022-10-04'),(24,'13A',NULL,111,2,0,NULL,0,NULL,0,NULL,0,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,1,0,0,0,0,0,0,0,1,1,0,0,0,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'sitiaishah','2022-10-04 00:00:00',NULL,'sitiaishah','2022-10-04 00:00:00',NULL,'TRIAGE',NULL,'2022-10-04'),(25,'13A',NULL,118,1,0,NULL,0,NULL,0,NULL,0,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,1,0,0,0,1,0,0,0,0,1,0,0,0,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'muhammadarif','2022-10-04 00:00:00',NULL,'muhammadarif','2022-10-04 00:00:00',NULL,'TRIAGE',NULL,'2022-10-04'),(26,'13A',NULL,114,2,0,NULL,1,NULL,0,NULL,0,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,1,0,0,0,1,0,0,0,0,1,0,0,0,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'fadhlina','2022-10-04 00:00:00',NULL,'fadhlina','2022-10-04 00:00:00',NULL,'TRIAGE',NULL,'2022-10-04'),(27,'13A',NULL,68,2,0,NULL,0,NULL,0,NULL,0,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,1,0,0,0,1,0,0,0,0,1,0,0,0,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'fadhlina','2022-10-04 00:00:00',NULL,'fadhlina','2022-10-04 00:00:00',NULL,'TRIAGE',NULL,'2022-10-04'),(28,'13A',NULL,102,2,0,NULL,0,NULL,0,NULL,0,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,1,0,0,0,1,0,0,0,0,1,0,0,0,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'muhammadarif','2022-10-04 00:00:00',NULL,'muhammadarif','2022-10-04 00:00:00',NULL,'TRIAGE',NULL,'2022-10-04'),(29,'13A',NULL,20,2,0,NULL,0,NULL,0,NULL,0,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,1,0,0,0,0,0,0,0,1,1,0,0,0,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'sitiaishah','2022-10-04 00:00:00',NULL,'sitiaishah','2022-10-04 00:00:00',NULL,'TRIAGE',NULL,'2022-10-04'),(30,'13A',NULL,95,2,0,NULL,0,NULL,0,NULL,0,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,1,0,0,0,0,0,0,0,1,1,0,0,0,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'sitiaishah','2022-10-04 00:00:00',NULL,'sitiaishah','2022-10-04 00:00:00',NULL,'TRIAGE',NULL,'2022-10-04'),(31,'13A',NULL,59,2,0,NULL,0,NULL,0,NULL,0,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,1,0,0,0,0,0,0,0,1,1,0,0,0,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'sitiaishah','2022-10-04 00:00:00',NULL,'sitiaishah','2022-10-04 00:00:00',NULL,'TRIAGE',NULL,'2022-10-04'),(32,'13A',NULL,31,2,0,NULL,0,NULL,0,NULL,0,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,1,0,0,0,1,0,0,0,0,1,0,0,0,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'muhammadarif','2022-10-04 00:00:00',NULL,'muhammadarif','2022-10-04 00:00:00',NULL,'TRIAGE',NULL,'2022-10-04'),(33,'13A',NULL,90,2,0,NULL,0,NULL,0,NULL,0,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,1,0,0,0,0,0,0,0,1,1,0,0,0,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'sitiaishah','2022-10-04 00:00:00',NULL,'sitiaishah','2022-10-04 00:00:00',NULL,'TRIAGE',NULL,'2022-10-04'),(34,'13A',NULL,39,2,0,NULL,0,NULL,0,NULL,0,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,1,0,0,0,1,0,0,0,0,1,0,0,0,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'muhammadarif','2022-10-04 00:00:00',NULL,'muhammadarif','2022-10-04 00:00:00',NULL,'TRIAGE',NULL,'2022-10-04'),(35,'13A',NULL,11,2,0,NULL,0,NULL,0,NULL,0,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,1,0,0,0,0,1,0,0,0,1,0,0,0,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'AIMAN.AMIN','2022-10-04 00:00:00',NULL,'AIMAN.AMIN','2022-10-04 00:00:00',NULL,'TRIAGE',NULL,'2022-10-04'),(36,NULL,NULL,NULL,NULL,0,NULL,0,NULL,0,NULL,0,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,1,0,0,0,1,0,0,0,0,1,0,0,0,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'muhammadarif','2022-10-04 00:00:00',NULL,'muhammadarif','2022-10-04 00:00:00',NULL,'TRIAGE',NULL,NULL),(37,NULL,NULL,NULL,NULL,0,NULL,0,NULL,0,NULL,0,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,1,0,0,0,1,0,0,0,0,1,0,0,0,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'muhammadarif','2022-10-04 00:00:00',NULL,'muhammadarif','2022-10-04 00:00:00',NULL,'TRIAGE',NULL,NULL),(38,'13A',NULL,56,2,0,NULL,0,NULL,0,NULL,0,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,1,0,0,0,1,0,0,0,0,1,0,0,0,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'muhammadarif','2022-10-04 00:00:00',NULL,'muhammadarif','2022-10-04 00:00:00',NULL,'TRIAGE',NULL,'2022-10-04'),(39,'13A',NULL,16,2,0,NULL,0,NULL,0,NULL,0,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,1,0,0,0,0,1,0,0,0,1,0,0,0,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'AIMAN.AMIN','2022-10-04 00:00:00',NULL,'AIMAN.AMIN','2022-10-04 00:00:00',NULL,'TRIAGE',NULL,'2022-10-04'),(40,'13A',NULL,60,2,0,NULL,0,NULL,0,NULL,0,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,1,0,0,0,0,1,0,0,0,1,0,0,0,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'AIMAN.AMIN','2022-10-04 00:00:00',NULL,'AIMAN.AMIN','2022-10-04 00:00:00',NULL,'TRIAGE',NULL,'2022-10-04'),(41,'13A',NULL,58,2,0,NULL,0,NULL,0,NULL,0,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,1,0,0,0,0,1,0,0,0,1,0,0,0,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'AIMAN.AMIN','2022-10-04 00:00:00',NULL,'AIMAN.AMIN','2022-10-04 00:00:00',NULL,'TRIAGE',NULL,'2022-10-04'),(42,NULL,NULL,NULL,NULL,0,NULL,0,NULL,0,NULL,0,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,1,0,0,0,1,0,0,0,0,1,0,0,0,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'suhaiyl','2022-10-05 00:00:00',NULL,'suhaiyl','2022-10-05 00:00:00',NULL,'TRIAGE',NULL,NULL),(43,'13A',NULL,81,2,0,NULL,0,NULL,0,NULL,0,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,1,0,0,0,1,0,0,0,0,1,0,0,0,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'fadhlina','2022-10-05 00:00:00',NULL,'fadhlina','2022-10-05 00:00:00',NULL,'TRIAGE',NULL,'2022-10-05'),(44,'13A',NULL,27,2,0,NULL,0,NULL,0,NULL,0,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,1,0,0,0,1,0,0,0,0,1,0,0,0,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'fadhlina','2022-10-05 00:00:00',NULL,'fadhlina','2022-10-05 00:00:00',NULL,'TRIAGE',NULL,'2022-10-05'),(45,'13A',NULL,1,2,0,NULL,0,NULL,0,NULL,0,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,1,0,0,0,0,0,0,0,1,1,0,0,0,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'syawani','2022-10-06 00:00:00',NULL,'syawani','2022-10-06 00:00:00',NULL,'TRIAGE',NULL,'2022-10-06'),(46,'13A',NULL,65,2,0,NULL,0,NULL,0,NULL,0,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,1,0,0,0,1,0,0,0,0,1,0,0,0,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'sitiaishah','2022-10-06 00:00:00',NULL,'sitiaishah','2022-10-06 00:00:00',NULL,'TRIAGE',NULL,'2022-10-06'),(47,'13A',NULL,98,2,0,NULL,0,NULL,0,NULL,0,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,1,0,0,0,0,0,0,1,0,1,0,0,0,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'aiman.amin','2022-10-06 00:00:00',NULL,'aiman.amin','2022-10-06 00:00:00',NULL,'TRIAGE',NULL,'2022-10-06'),(48,'13A',NULL,106,2,0,NULL,0,NULL,0,NULL,0,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,1,0,0,0,0,1,0,0,0,1,0,0,0,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'aiman.amin','2022-10-06 00:00:00',NULL,'aiman.amin','2022-10-06 00:00:00',NULL,'TRIAGE',NULL,'2022-10-06'),(49,'13A',NULL,186,2,0,NULL,0,NULL,0,NULL,0,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,1,0,0,0,0,1,0,0,0,1,0,0,0,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'HAFIZAL','2022-10-12 00:00:00',NULL,'HAFIZAL','2022-10-12 00:00:00',NULL,'TRIAGE',NULL,'2022-10-12');
/*!40000 ALTER TABLE `nursassessgen` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `nursassessment`
--

DROP TABLE IF EXISTS `nursassessment`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `nursassessment` (
  `idno` int(10) NOT NULL AUTO_INCREMENT,
  `compcode` varchar(30) DEFAULT NULL,
  `mrn` int(11) DEFAULT NULL,
  `episno` int(11) DEFAULT NULL,
  `casecode` varchar(10) DEFAULT NULL,
  `doctorcode` varchar(10) DEFAULT NULL,
  `admwardtime` varchar(10) DEFAULT NULL,
  `admreason` text,
  `diagnosis` text,
  `languagespoken` text,
  `currentmedication` text,
  `moa_walkin` tinyint(4) DEFAULT NULL,
  `moa_wheelchair` tinyint(4) DEFAULT NULL,
  `moa_trolley` tinyint(4) DEFAULT NULL,
  `moa_others` tinyint(4) DEFAULT NULL,
  `es_calm` tinyint(4) DEFAULT NULL,
  `es_anxious` tinyint(4) DEFAULT NULL,
  `es_depressed` tinyint(4) DEFAULT NULL,
  `es_irritable` tinyint(4) DEFAULT NULL,
  `es_distress` tinyint(4) DEFAULT NULL,
  `loc_conscious` tinyint(4) DEFAULT NULL,
  `loc_semiconscious` tinyint(4) DEFAULT NULL,
  `loc_unconscious` tinyint(4) DEFAULT NULL,
  `ms_orientated` tinyint(4) DEFAULT NULL,
  `ms_confused` tinyint(4) DEFAULT NULL,
  `ms_restless` tinyint(4) DEFAULT NULL,
  `ms_aggressive` tinyint(4) DEFAULT NULL,
  `adduser` varchar(100) DEFAULT NULL,
  `adddate` datetime DEFAULT NULL,
  `addtime` varchar(30) DEFAULT NULL,
  `lastuser` varchar(100) DEFAULT NULL,
  `lastupdate` datetime DEFAULT NULL,
  `lastupdtime` varchar(30) DEFAULT NULL,
  `vs_temperature` varchar(11) DEFAULT NULL,
  `vs_pulse` varchar(11) DEFAULT NULL,
  `vs_respiration` varchar(11) DEFAULT NULL,
  `vs_bp_sys1` varchar(11) DEFAULT NULL,
  `vs_bp_dias2` varchar(11) DEFAULT NULL,
  `vs_weight` varchar(11) DEFAULT NULL,
  `vs_bpdiastolic` varchar(11) DEFAULT NULL,
  `vs_gxt` varchar(11) DEFAULT NULL,
  `vs_painscore` varchar(11) DEFAULT NULL,
  `vs_height` varchar(11) DEFAULT NULL,
  `location` varchar(15) DEFAULT 'TRIAGE' COMMENT 'TRIAGE/WARD',
  `triagecolor` varchar(20) DEFAULT NULL,
  `fra_prevfalls` tinyint(4) DEFAULT NULL,
  `fra_age` tinyint(4) DEFAULT NULL,
  `fra_physicalLimitation` tinyint(4) DEFAULT NULL,
  `fra_neurologicaldeficit` tinyint(4) DEFAULT NULL,
  `fra_dizziness` tinyint(4) DEFAULT NULL,
  `fra_cerebralaccident` tinyint(4) DEFAULT NULL,
  `fra_notatrisk` tinyint(4) DEFAULT NULL,
  `fra_atrisk` tinyint(4) DEFAULT NULL,
  `psra_incontinent` tinyint(4) DEFAULT NULL,
  `psra_immobility` tinyint(4) DEFAULT NULL,
  `psra_poorskintype` tinyint(4) DEFAULT NULL,
  `psra_notatrisk` tinyint(4) DEFAULT NULL,
  `psra_atrisk` tinyint(4) DEFAULT NULL,
  `arrival_date` date DEFAULT NULL,
  PRIMARY KEY (`idno`),
  UNIQUE KEY `nursassessment_mrnepislocation` (`compcode`,`mrn`,`episno`,`location`)
) ENGINE=InnoDB AUTO_INCREMENT=45 DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `nursassessment`
--

LOCK TABLES `nursassessment` WRITE;
/*!40000 ALTER TABLE `nursassessment` DISABLE KEYS */;
INSERT INTO `nursassessment` VALUES (1,'13A',117,1,NULL,NULL,'08:25',NULL,NULL,NULL,'caco3 1gram TDS\r\nZincofer 0.5 OD\r\nAmlodipine 10mg OD\r\nCalcitriol 1mcg OD',1,0,0,NULL,NULL,NULL,NULL,NULL,NULL,1,0,0,1,0,0,0,'fadhlina','2022-10-03 00:00:00',NULL,'fadhlina','2022-10-03 00:00:00',NULL,'36.7','82','16','144/85',NULL,'55.0',NULL,NULL,NULL,NULL,'TRIAGE',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'2022-10-03'),(2,'13A',82,2,NULL,NULL,'07:15',NULL,NULL,NULL,'actrapid, insulatard, zincofer, calcium carbonate, simvastatin, calcitriol,',1,0,0,NULL,NULL,NULL,NULL,NULL,NULL,1,0,0,1,0,0,0,'aiman.amin','2022-10-03 00:00:00',NULL,'aiman.amin','2022-10-03 00:00:00',NULL,'37.0','60','18','169','53','71.5',NULL,NULL,'0',NULL,'TRIAGE',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'2022-10-03'),(3,'13A',115,2,NULL,NULL,'06:50',NULL,NULL,NULL,NULL,1,0,0,NULL,NULL,NULL,NULL,NULL,NULL,1,0,0,1,0,0,0,'muhammadarif','2022-10-03 00:00:00',NULL,'muhammadarif','2022-10-03 00:00:00',NULL,'36.7','74','12','150/77','74','71.8',NULL,NULL,'0','143','TRIAGE',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'2022-10-03'),(4,'13A',3,2,NULL,NULL,'07:15',NULL,NULL,NULL,'amlodipine, calcium carbonate, folic acid, vit c, calcitriol, ESA, venofer',1,0,0,NULL,NULL,NULL,NULL,NULL,NULL,1,0,0,1,0,0,0,'aiman.amin','2022-10-03 00:00:00',NULL,'aiman.amin','2022-10-03 00:00:00',NULL,'37.0','74','18','168','62','61.3',NULL,NULL,'0',NULL,'TRIAGE',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'2022-10-03'),(5,'13A',87,2,NULL,NULL,'06:30',NULL,NULL,NULL,NULL,1,0,0,NULL,NULL,NULL,NULL,NULL,NULL,1,0,0,1,0,0,0,'muhammadarif','2022-10-03 00:00:00',NULL,'muhammadarif','2022-10-03 00:00:00',NULL,'36.7','73','12','114','53','52.2',NULL,NULL,'0','145','TRIAGE',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'2022-10-03'),(6,'13A',33,2,NULL,NULL,'07:30',NULL,NULL,NULL,'felodipine, perindopril, simvastatin, s/c actrapid, insulatard, calcium carbonate, zincofer, ESA, venofer,',1,0,0,NULL,NULL,NULL,NULL,NULL,NULL,1,0,0,1,0,0,0,'aiman.amin','2022-10-03 00:00:00',NULL,'aiman.amin','2022-10-03 00:00:00',NULL,'37.0','75','18','100','51','58.5',NULL,NULL,'0',NULL,'TRIAGE',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'2022-10-03'),(7,'13A',71,2,NULL,NULL,'08:54',NULL,NULL,NULL,'zincofer 0.5mg OD\r\nCalcium carbonate 1.5mg TDS\r\nSimvastatin 40mg ON\r\nFelodipine 10mg BD\r\nCalcitriol 0.25mg EOD\r\nFurosemide 40mg OD\r\nBisoprolol 5mg OD \r\nPrazosin 1mg TDS\r\nSc Actrapid 6u TDS\r\nSc Insulatard 6u ON\r\nEnalapril 10mg BD',0,1,0,NULL,NULL,NULL,NULL,NULL,NULL,1,0,0,1,0,0,0,'fadhlina','2022-10-03 00:00:00',NULL,'suhaiyl','2022-10-05 00:00:00',NULL,'36.7','75','18','152','57','50.5',NULL,NULL,NULL,NULL,'TRIAGE',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'2022-10-03'),(8,'13A',50,2,NULL,NULL,NULL,NULL,NULL,NULL,'Aspirin 150mg OD\r\nZincofer 0.5 OD\r\nSc Actrapid 6 unit\r\nCalcium Carbonate 2gram TDS\r\nCalcitriol 1mcg Od\r\nSimvastatin 20mg ON\r\nSlow K  600mg OD',1,0,0,NULL,NULL,NULL,NULL,NULL,NULL,1,0,0,1,0,0,0,'fadhlina','2022-10-03 00:00:00',NULL,'fadhlina','2022-10-03 00:00:00',NULL,'36.7','90','18','181','74','61.5',NULL,NULL,NULL,NULL,'TRIAGE',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'2022-10-03'),(9,'13A',70,2,NULL,NULL,'10:14',NULL,NULL,NULL,'Calcium carbonate 1.5mg TDS\r\nFelodipine 10mg BD\r\nCalcitriol 0.5mcg EOD\r\nPerindopril 4mg OD\r\nPrazosin 4mg OD\r\nGliclazide 30mg OD',1,0,0,NULL,NULL,NULL,NULL,NULL,NULL,1,0,0,1,0,0,0,'fadhlina','2022-10-03 00:00:00',NULL,'fadhlina','2022-10-03 00:00:00',NULL,'36.6','80','18','174','71','58.1',NULL,NULL,NULL,NULL,'TRIAGE',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'2022-10-03'),(10,'13A',72,2,NULL,NULL,'10:29',NULL,NULL,NULL,'1. Furrous Fumarate 400mg OD\r\n2. Perindopril 4mg OD\r\n3. Frusemide 80mg TDS\r\n4. Folic Acid 5mg OD\r\n5. Simvastatin 20mg ON\r\n6. Caco3 1g TDS\r\n7. Atenolol 100mg OD\r\n\r\nESA 2000iu / week\r\nVenofer 100mg / monthly',1,0,0,NULL,NULL,NULL,NULL,NULL,NULL,1,0,0,1,0,0,0,'muhammadarif','2022-10-03 00:00:00',NULL,'muhammadarif','2022-10-03 00:00:00',NULL,'36.0','88','19','132','42',NULL,NULL,NULL,'0','162','TRIAGE',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'2022-10-03'),(11,'13A',77,2,NULL,NULL,'10:40',NULL,NULL,NULL,'1. Cardiprin 100mg OD\r\n2. Zincofer 1/1 OD\r\n3. Caco3 1g TDS\r\n4. 1 alpha cacidol 5mg BD\r\n\r\nESA 2000iu / week\r\nVenofer 100mg monthly',1,0,0,NULL,NULL,NULL,NULL,NULL,NULL,1,0,0,1,0,0,0,'muhammadarif','2022-10-03 00:00:00',NULL,'muhammadarif','2022-10-03 00:00:00',NULL,'36.0','88','20','160','66','71.9',NULL,NULL,'0','175','TRIAGE',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'2022-10-03'),(12,'13A',41,2,NULL,NULL,'10:48',NULL,NULL,NULL,'1. Felodipine 10mg BD\r\n2. Losartan 100mg OD\r\n3. Simvastatin\r\n4. 1 alpha calcidol 8mcg EOD\r\n5. Zincofer 1/1 OD\r\n6. SC Actrapid 10u TDS\r\n7. Calcium Carbonate 1.5g TDS\r\n\r\nESA 2000iu 3x/week and alternate 2x/week\r\nVenofer 100mg monthly',1,0,0,NULL,NULL,NULL,NULL,NULL,NULL,1,0,0,1,0,0,0,'muhammadarif','2022-10-03 00:00:00',NULL,'muhammadarif','2022-10-03 00:00:00',NULL,'36.0','88','21','170/50','50','63',NULL,NULL,'0','155','TRIAGE',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'2022-10-03'),(13,'13A',96,2,NULL,NULL,'12:00',NULL,NULL,NULL,'1. 1 alpha calcicol 0.5mcd OD\r\n2. Calcium Carbonate 1.5g TDS\r\n3. Atorvastatin 40mg ON\r\n4. Zincofer 1/1 OD\r\n5. S/C actrapid 6u \r\n6. S/C Insulatard 8u ON\r\n\r\nESA 2000iu 3x/week alternate 2x/week\r\nVenofer 100mg 2/52',1,0,0,NULL,NULL,NULL,NULL,NULL,NULL,1,0,0,1,0,0,0,'muhammadarif','2022-10-03 00:00:00',NULL,'muhammadarif','2022-10-03 00:00:00',NULL,'36.0','88','20','160','74','58',NULL,NULL,'0','158','TRIAGE',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'2022-10-03'),(14,'13A',64,2,NULL,NULL,'12:09',NULL,NULL,NULL,'1. Ferrous fumarate 400mg OD\r\n2. Vit B Co 1/1 OD\r\n3. Amlodipine 10mg OD\r\n4. Folic Acid 5mg OD\r\n5. Calcium Carbonate 1g TDS\r\n6. Perindopril 4mg ON\r\n\r\nESA 2000iu 3x/week\r\nVenofer 100mg 2x/ week',1,0,0,NULL,NULL,NULL,NULL,NULL,NULL,1,0,0,1,0,0,0,'muhammadarif','2022-10-03 00:00:00',NULL,'muhammadarif','2022-10-03 00:00:00',NULL,'36.0','88','20','160','66','53',NULL,NULL,'0','163','TRIAGE',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'2022-10-03'),(15,'13A',112,2,NULL,NULL,'12:20',NULL,NULL,NULL,'1. Bisoprolol 5mg OD\r\n2. Simvastatin 40mg ON\r\n3. Calcium Carbonate 1.5g\r\n4. Frusemide 80mg BD\r\n5. Felodipine 10mg BD\r\n6. Cardiprin 100mg OD\r\n7. Ferrous Fumarate 200mg BD\r\n8. Vit B co 1/1 OD\r\n9. Folic Acid 5mg OD\r\n10. Calcitriol 0.5mcg OD\r\n11. S/C Actrapid 12u TDS\r\n\r\nESA 2000iu 3x/week\r\nVenofer 100mg every 2/52',1,0,0,NULL,NULL,NULL,NULL,NULL,NULL,1,0,0,1,0,0,0,'muhammadarif','2022-10-03 00:00:00',NULL,'muhammadarif','2022-10-03 00:00:00',NULL,'36.0','90','20','150','66','89',NULL,NULL,'0','175','TRIAGE',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'2022-10-03'),(16,'13A',76,2,NULL,NULL,NULL,NULL,NULL,NULL,NULL,0,1,0,NULL,NULL,NULL,NULL,NULL,NULL,1,0,0,1,0,0,0,'muhammadarif','2022-10-03 00:00:00',NULL,'muhammadarif','2022-10-03 00:00:00',NULL,'36.7','74','12','169','84','51.5',NULL,NULL,'0','158','TRIAGE',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'2022-10-03'),(17,'13A',29,2,NULL,NULL,'11:30',NULL,NULL,NULL,'1. Calcitriol\r\n2. Folic acid\r\n3. calcium carbonate\r\n4. simvastatin \r\n5. venofer\r\n6. ESA',1,0,0,NULL,NULL,NULL,NULL,NULL,NULL,1,0,0,1,0,0,0,'AIMAN.AMIN','2022-10-03 00:00:00',NULL,'AIMAN.AMIN','2022-10-03 00:00:00',NULL,'36.7','87','18','142','70','54.2',NULL,NULL,'0','170','TRIAGE',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'2022-10-03'),(18,'13A',94,2,NULL,NULL,'14:30',NULL,NULL,NULL,'furrous famurate, folic acid, vit B, vit C, calcium, caco3, s/c insulatad, s/c actrapid.',1,0,0,NULL,NULL,NULL,NULL,NULL,NULL,1,0,0,1,0,0,0,'sitiaishah','2022-10-03 00:00:00',NULL,'sitiaishah','2022-10-03 00:00:00',NULL,'37.0','78','22','146','78','68.2',NULL,NULL,'0','160','TRIAGE',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'2022-10-03'),(19,'13A',22,2,NULL,NULL,'14:30',NULL,NULL,NULL,NULL,0,1,0,NULL,NULL,NULL,NULL,NULL,NULL,1,0,0,1,0,0,0,'sitiaishah','2022-10-03 00:00:00',NULL,'sitiaishah','2022-10-03 00:00:00',NULL,'37.0','78','22','146','78','68.2',NULL,NULL,'0','165','TRIAGE',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'2022-10-03'),(20,'13A',32,2,NULL,NULL,'06:45',NULL,NULL,NULL,NULL,1,0,0,NULL,NULL,NULL,NULL,NULL,NULL,1,0,0,1,0,0,0,'muhammadarif','2022-10-04 00:00:00',NULL,'muhammadarif','2022-10-04 00:00:00',NULL,'36.7','82','18','135','70','104.5',NULL,NULL,'0','170','TRIAGE',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'2022-10-04'),(21,'13A',101,2,NULL,NULL,'07:15',NULL,NULL,NULL,'Amlodipine 10mg OD\r\nBisoprolol 1.25mg OD\r\nCalcitriol 1gm TDS\r\nSimvastatin 20mg ON\r\nFerrous Femurate 200mg OD\r\nVit B complax 0.5 OD\r\nFurosemide 80mg TDS',1,0,0,NULL,NULL,NULL,NULL,NULL,NULL,1,0,0,1,0,0,0,'fadhlina','2022-10-04 00:00:00',NULL,'fadhlina','2022-10-04 00:00:00',NULL,'36.7','60','16','163','80','64.0',NULL,NULL,NULL,NULL,'TRIAGE',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'2022-10-04'),(22,'13A',111,2,NULL,NULL,NULL,NULL,NULL,NULL,'bisoprolol, calcium, felodipine, vit B, folic acid, ferous fumarate, calcitrol, prazosin.',1,0,0,NULL,NULL,NULL,NULL,NULL,NULL,1,0,0,1,0,0,0,'sitiaishah','2022-10-04 00:00:00',NULL,'sitiaishah','2022-10-04 00:00:00',NULL,'36.8','93','22','194','103','64.4',NULL,NULL,'0','160','TRIAGE',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'2022-10-04'),(23,'13A',118,1,NULL,NULL,NULL,NULL,NULL,NULL,NULL,1,0,0,NULL,NULL,NULL,NULL,NULL,NULL,1,0,0,1,0,0,0,'muhammadarif','2022-10-04 00:00:00',NULL,'muhammadarif','2022-10-04 00:00:00',NULL,'36.7','82',NULL,'194','92','90.9',NULL,NULL,'0','177','TRIAGE',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'2022-10-04'),(24,'13A',114,2,NULL,NULL,'08:45',NULL,NULL,NULL,NULL,1,0,0,NULL,NULL,NULL,NULL,NULL,NULL,1,0,0,1,0,0,0,'fadhlina','2022-10-04 00:00:00',NULL,'fadhlina','2022-10-04 00:00:00',NULL,'36.8','92','16','187','108','67.0',NULL,NULL,NULL,NULL,'TRIAGE',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'2022-10-04'),(25,'13A',68,2,NULL,NULL,'06:50',NULL,NULL,NULL,'Simvastatin 40mg ON\r\nPrazosin 1mg BD\r\nAspirin 150mg OD\r\nFelodipine 10mg BD\r\nZincofer 0.5 mg BD\r\nCalcium carbontae 1.5gm TDS\r\nCalcitriol 0.5mcg OD\r\nBisoprolol 1.25mg OD',1,0,0,NULL,NULL,NULL,NULL,NULL,NULL,1,0,0,1,0,0,0,'fadhlina','2022-10-04 00:00:00',NULL,'fadhlina','2022-10-04 00:00:00',NULL,'36.6','72','16','199','79','55.6',NULL,NULL,NULL,NULL,'TRIAGE',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'2022-10-04'),(26,'13A',102,2,NULL,NULL,'09:26',NULL,NULL,NULL,'1) simvastatin 20mg on\r\n2) metoprolol 100mg bd\r\n3) calcitriol 1mg od\r\n4) vit Bcomplex 1/1 od\r\n5) calciumCo 1gm tds\r\n6) amlodipine 10mg on\r\n7) vit c 100mg od\r\n8) folic acid 5mg od\r\n9) mecobalamine 1/1 od\r\n10) pentoprazole  40mg ed/pen\r\n11) ferrous fememurate 200mg od',1,0,0,NULL,NULL,NULL,NULL,NULL,NULL,1,0,0,1,0,0,0,'muhammadarif','2022-10-04 00:00:00',NULL,'muhammadarif','2022-10-04 00:00:00',NULL,'36.7','84','18','138','79','48.8',NULL,NULL,'0','153','TRIAGE',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'2022-10-04'),(27,'13A',20,2,NULL,NULL,NULL,NULL,NULL,NULL,'calcium lactate, calcium carbonate, zinofer, calcidol',1,0,0,NULL,NULL,NULL,NULL,NULL,NULL,1,0,0,1,0,0,0,'sitiaishah','2022-10-04 00:00:00',NULL,'sitiaishah','2022-10-04 00:00:00',NULL,'36.8','75','22','138','78','59.1',NULL,NULL,'0','153','TRIAGE',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'2022-10-04'),(28,'13A',95,2,NULL,NULL,NULL,NULL,NULL,NULL,'glicazide, felodipine, ferous femorate, folic acid, vit B, furosemide, calcium, perindopril, colcicin, mycobalamine, glucosamine, prazosin.',1,0,0,NULL,NULL,NULL,NULL,NULL,NULL,1,0,0,1,0,0,0,'sitiaishah','2022-10-04 00:00:00',NULL,'sitiaishah','2022-10-04 00:00:00',NULL,'36.8','72','22','174','120','68.95',NULL,NULL,'0','153','TRIAGE',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'2022-10-04'),(29,'13A',59,2,NULL,NULL,'06:45',NULL,NULL,NULL,'folic acid, calcium, vit B, ferrous femorate, simvastatin, s/c mixtard',0,1,0,NULL,NULL,NULL,NULL,NULL,NULL,1,0,0,1,0,0,0,'sitiaishah','2022-10-04 00:00:00',NULL,'sitiaishah','2022-10-04 00:00:00',NULL,'37.0','74','22','142','52',NULL,NULL,NULL,NULL,NULL,'TRIAGE',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'2022-10-04'),(30,'13A',31,2,NULL,NULL,'10:50',NULL,NULL,NULL,'1. ferrous fememurate 200mg od\r\n2. Folic acid 5mg od\r\n3. calcidol 3mg bd\r\n4. amlodipine 10mg od\r\n5. cardipine 100mg eod\r\n6.',1,0,0,NULL,NULL,NULL,NULL,NULL,NULL,1,0,0,1,0,0,0,'muhammadarif','2022-10-04 00:00:00',NULL,'muhammadarif','2022-10-04 00:00:00',NULL,'36.7','70','18','169','85','71.9',NULL,NULL,'0','175','TRIAGE',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'2022-10-04'),(31,'13A',90,2,NULL,NULL,'10:45',NULL,NULL,NULL,'furosemide, bisoprolol, simvastatin, felodipine, prazosin, calcitrol, calcium carbonate,',1,0,0,NULL,NULL,NULL,NULL,NULL,NULL,1,0,0,0,0,0,0,'sitiaishah','2022-10-04 00:00:00',NULL,'sitiaishah','2022-10-04 00:00:00',NULL,'36.8','62','22','149','76','73.3',NULL,NULL,'0','165','TRIAGE',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'2022-10-04'),(32,'13A',39,2,NULL,NULL,'14:16',NULL,NULL,NULL,'1. vitamin Bcx 1/1 od\r\n2.  caltriol 0.25mcg ed\r\n3.  atrovastatin 20mg on\r\n4. amlodipine 10mg od\r\n5. ferrous fememurate 200mg od\r\n6. folic acid 5mg od\r\n7 sc insurgen N\r\n8. sc insurgen R',1,0,0,NULL,NULL,NULL,NULL,NULL,NULL,1,0,0,1,0,0,0,'muhammadarif','2022-10-04 00:00:00',NULL,'muhammadarif','2022-10-04 00:00:00',NULL,NULL,NULL,NULL,NULL,NULL,'83.1',NULL,NULL,'0','158','TRIAGE',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'2022-10-04'),(33,'13A',11,2,NULL,NULL,'14:05',NULL,NULL,NULL,'AMLODIPINE, ZINCOFER, CALCIUM CARBONATE, SC ATRAPID, SC INSULATARD, PERINDOPRIL, CALCITRIOL, ESA, VENOFER',1,0,0,NULL,NULL,NULL,NULL,NULL,NULL,1,0,0,1,0,0,0,'AIMAN.AMIN','2022-10-04 00:00:00',NULL,'AIMAN.AMIN','2022-10-04 00:00:00',NULL,'37.0','78','18','150','60','73.1',NULL,NULL,'0','165','TRIAGE',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'2022-10-04'),(34,'13A',56,2,NULL,NULL,'15:25',NULL,NULL,NULL,'1. calcium co3 2mg tds\r\n2. amlodipine 10mg od\r\n3. caldipine 100mg od\r\n4. bisoprolol 5mg od\r\n5. vit Bx 1/1 od\r\n6. folic acid 5mg od\r\n7. simvastatin 20mg on\r\n8. calcidol 2mg eod',1,0,0,NULL,NULL,NULL,NULL,NULL,NULL,1,0,0,1,0,0,0,'muhammadarif','2022-10-04 00:00:00',NULL,'muhammadarif','2022-10-04 00:00:00',NULL,'36.7','73','18','139','73','67.3',NULL,NULL,'0','173','TRIAGE',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'2022-10-04'),(35,'13A',16,2,NULL,NULL,'15:00',NULL,NULL,NULL,'lorsatan, simvastatin, fursemide calcium carbonate, cardipine',1,0,0,NULL,NULL,NULL,NULL,NULL,NULL,1,0,0,1,0,0,0,'AIMAN.AMIN','2022-10-04 00:00:00',NULL,'AIMAN.AMIN','2022-10-04 00:00:00',NULL,'37.0','96','18','156','72','82.1',NULL,NULL,'0','165','TRIAGE',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'2022-10-04'),(36,'13A',60,2,NULL,NULL,'14:40',NULL,NULL,NULL,'lorsatan, simvastatin, zincofer, calcium carbonate, calcitriol, felodipine, ESA, venofer,',0,1,0,NULL,NULL,NULL,NULL,NULL,NULL,1,0,0,1,0,0,0,'AIMAN.AMIN','2022-10-04 00:00:00',NULL,'AIMAN.AMIN','2022-10-04 00:00:00',NULL,'37.0','68','18','206','91','52.6',NULL,NULL,'0','170','TRIAGE',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'2022-10-04'),(37,'13A',58,2,NULL,NULL,'14:00',NULL,NULL,NULL,'amlodipine, zincofer, simvastatin, calcitriol, calcium carbonate, perindopril, bisoprolol, sc actrapid, venofer, ESA',1,0,0,NULL,NULL,NULL,NULL,NULL,NULL,1,0,0,1,0,0,0,'AIMAN.AMIN','2022-10-04 00:00:00',NULL,'AIMAN.AMIN','2022-10-04 00:00:00',NULL,'37.0','63','18','173','61','112.5',NULL,NULL,'0','165','TRIAGE',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'2022-10-04'),(38,'13A',81,2,NULL,NULL,'12:50',NULL,NULL,NULL,NULL,1,0,0,NULL,NULL,NULL,NULL,NULL,NULL,1,0,0,1,0,0,0,'fadhlina','2022-10-05 00:00:00',NULL,'fadhlina','2022-10-05 00:00:00',NULL,'36.5','60','16','118','48','47.5',NULL,NULL,NULL,NULL,'TRIAGE',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'2022-10-05'),(39,'13A',27,2,NULL,NULL,'13:00',NULL,NULL,NULL,'vitamin c 100mg OD\r\nVitamn B complax 1mg OD\r\nFolic acid 5mg OD\r\nCACO3 1GM TDS\r\nCardipine  100mg OD\r\nFerrous Femurate 4003g OD',1,0,0,NULL,NULL,NULL,NULL,NULL,NULL,1,0,0,1,0,0,0,'fadhlina','2022-10-05 00:00:00',NULL,'fadhlina','2022-10-05 00:00:00',NULL,'36.7','60','16','160','80','55.4',NULL,NULL,NULL,NULL,'TRIAGE',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'2022-10-05'),(40,'13A',1,2,NULL,NULL,'08:00',NULL,NULL,NULL,'calcitrol, zinofer, calcium co3, cardiprin, simvastatin, pregabalin, amlodipine, tramadol, PCM',1,0,0,NULL,NULL,NULL,NULL,NULL,NULL,1,0,0,1,0,0,0,'syawani','2022-10-06 00:00:00',NULL,'syawani','2022-10-06 00:00:00',NULL,'37.0','87','24','167','91','82.3',NULL,NULL,'0','165','TRIAGE',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'2022-10-06'),(41,'13A',65,2,NULL,NULL,NULL,NULL,NULL,NULL,'zinofer, felodipine, calcium co3, calcitrol, perindopril, pantoprazole.',1,0,0,NULL,NULL,NULL,NULL,NULL,NULL,1,0,0,1,0,0,0,'sitiaishah','2022-10-06 00:00:00',NULL,'sitiaishah','2022-10-06 00:00:00',NULL,'37.0','74','24','140','85','58.4',NULL,NULL,'0','168','TRIAGE',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'2022-10-06'),(42,'13A',98,2,NULL,NULL,'11:00',NULL,NULL,NULL,'calcium carbonate, perindopril, simvastatin, ferusemide, ferrous fumarrate, folic acid, calcitriol, ESA, venofer',0,1,0,NULL,NULL,NULL,NULL,NULL,NULL,1,0,0,1,0,0,0,'aiman.amin','2022-10-06 00:00:00',NULL,'aiman.amin','2022-10-06 00:00:00',NULL,'36.7','85','18','179/91',NULL,'56.9',NULL,NULL,'0','166','TRIAGE',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'2022-10-06'),(43,'13A',106,2,NULL,NULL,'10:40',NULL,NULL,NULL,'1)folic acid 5mg od\r\n2)calcium carbonate 1.5g  tds\r\n3)vitamin b complex 1/1 od\r\n4)sc actrapid  8iu bd\r\n5)calcitriol 0.25mcg od\r\n6)simvastatin 40mg on',1,0,0,NULL,NULL,NULL,NULL,NULL,NULL,1,0,0,1,0,0,0,'aiman.amin','2022-10-06 00:00:00',NULL,'aiman.amin','2022-10-06 00:00:00',NULL,'37.0','88','18','148','66','57.9',NULL,NULL,'0','160','TRIAGE',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'2022-10-06'),(44,'13A',186,2,NULL,NULL,'16:15',NULL,NULL,NULL,'1-TAB. ATORVASTATIN 40 MG ON\r\n2-TAB. BISOPROLOL 1.25 MG OD\r\n3-TAB. FERROUS FUMARATE 200 MG OD\r\n4-TAB. CALCITRIOL 0.75 MG OD\r\n5-TAB. CARDIPRIN 100 MG OD\r\n6-TAB. CALCIUM CARBONATE  500 MG TDS\r\n7-TAB . FOLIC ACID 5MG OD\r\n8-TAB. VITAMIN B 1/1 OD\r\n9-TAB. VITAMIN C 1/1 OD\r\n10-TAB. ISOSORBIDE DINITRATE 10 MG BD\r\n11-SUBCUTE MIXTARD 18iu/16iu BD',1,0,0,NULL,NULL,NULL,NULL,NULL,NULL,1,0,0,1,0,0,0,'HAFIZAL','2022-10-12 00:00:00',NULL,'HAFIZAL','2022-10-12 00:00:00',NULL,'37.0','69','14','165','69','51.0',NULL,NULL,'0','156','TRIAGE',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'2022-10-12');
/*!40000 ALTER TABLE `nursassessment` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `nurshistory`
--

DROP TABLE IF EXISTS `nurshistory`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `nurshistory` (
  `idno` int(10) NOT NULL AUTO_INCREMENT,
  `compcode` varchar(30) DEFAULT NULL,
  `mrn` int(11) DEFAULT NULL,
  `medicalhistory` text,
  `surgicalhistory` text,
  `familymedicalhist` text,
  `allergydrugs` tinyint(4) DEFAULT NULL,
  `drugs_remarks` text,
  `allergyplaster` tinyint(4) DEFAULT NULL,
  `plaster_remarks` text,
  `allergyfood` tinyint(4) DEFAULT NULL,
  `food_remarks` text,
  `allergyenvironment` tinyint(4) DEFAULT NULL,
  `environment_remarks` text,
  `allergyothers` tinyint(4) DEFAULT NULL,
  `others_remarks` text,
  `allergyunknown` tinyint(4) DEFAULT NULL,
  `unknown_remarks` text,
  `allergynone` tinyint(4) DEFAULT NULL,
  `none_remarks` text,
  `adduser` varchar(100) DEFAULT NULL,
  `adddate` datetime DEFAULT NULL,
  `lastuser` varchar(100) DEFAULT NULL,
  `lastupdate` datetime DEFAULT NULL,
  PRIMARY KEY (`idno`)
) ENGINE=InnoDB AUTO_INCREMENT=45 DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `nurshistory`
--

LOCK TABLES `nurshistory` WRITE;
/*!40000 ALTER TABLE `nurshistory` DISABLE KEYS */;
INSERT INTO `nurshistory` VALUES (1,'13A',117,'1. Glomerulonephritis(FSGS)\r\n2. Hypertension',NULL,NULL,0,NULL,NULL,NULL,0,NULL,NULL,NULL,0,NULL,NULL,NULL,NULL,NULL,'fadhlina','2022-10-03 00:00:00','fadhlina','2022-10-03 00:00:00'),(2,'13A',82,'HPT , DM','-',NULL,0,NULL,NULL,NULL,0,NULL,NULL,NULL,0,NULL,NULL,NULL,NULL,NULL,'aiman.amin','2022-10-03 00:00:00','aiman.amin','2022-10-03 00:00:00'),(3,'13A',115,NULL,NULL,NULL,0,NULL,NULL,NULL,0,NULL,NULL,NULL,0,NULL,NULL,NULL,NULL,NULL,'muhammadarif','2022-10-03 00:00:00','muhammadarif','2022-10-03 00:00:00'),(4,'13A',3,'DM, HPT,',NULL,NULL,0,NULL,NULL,NULL,0,NULL,NULL,NULL,0,NULL,NULL,NULL,NULL,NULL,'aiman.amin','2022-10-03 00:00:00','aiman.amin','2022-10-03 00:00:00'),(5,'13A',87,NULL,NULL,NULL,0,NULL,NULL,NULL,0,NULL,NULL,NULL,0,NULL,NULL,NULL,NULL,NULL,'muhammadarif','2022-10-03 00:00:00','muhammadarif','2022-10-03 00:00:00'),(6,'13A',33,'DM, HPT',NULL,NULL,0,NULL,NULL,NULL,0,NULL,NULL,NULL,0,NULL,NULL,NULL,NULL,NULL,'aiman.amin','2022-10-03 00:00:00','aiman.amin','2022-10-03 00:00:00'),(7,'13A',71,'1. Hypertension',NULL,NULL,0,NULL,NULL,NULL,0,NULL,NULL,NULL,0,NULL,NULL,NULL,NULL,NULL,'suhaiyl','2022-10-05 00:00:00','suhaiyl','2022-10-05 00:00:00'),(8,'13A',50,'1. Diabetes Mellitus\r\n2. Hypertension\r\n3. ESRF',NULL,NULL,0,NULL,NULL,NULL,0,NULL,NULL,NULL,0,NULL,NULL,NULL,NULL,NULL,'fadhlina','2022-10-03 00:00:00','fadhlina','2022-10-03 00:00:00'),(9,'13A',70,'1. DM\r\n2. HPT\r\n3. ESRF',NULL,NULL,0,NULL,NULL,NULL,0,NULL,NULL,NULL,0,NULL,NULL,NULL,NULL,NULL,'fadhlina','2022-10-03 00:00:00','fadhlina','2022-10-03 00:00:00'),(10,'13A',72,'ESRD secondary to DM/HPT.','N/A',NULL,0,NULL,NULL,NULL,0,NULL,NULL,NULL,0,NULL,NULL,NULL,NULL,NULL,'muhammadarif','2022-10-03 00:00:00','muhammadarif','2022-10-03 00:00:00'),(11,'13A',77,'ESRD secondary to DM',NULL,NULL,0,NULL,NULL,NULL,0,NULL,NULL,NULL,0,NULL,NULL,NULL,NULL,NULL,'muhammadarif','2022-10-03 00:00:00','muhammadarif','2022-10-03 00:00:00'),(12,'13A',41,'ESRD secondary to DM/HPT.',NULL,NULL,0,NULL,NULL,NULL,0,NULL,NULL,NULL,0,NULL,NULL,NULL,NULL,NULL,'muhammadarif','2022-10-03 00:00:00','muhammadarif','2022-10-03 00:00:00'),(13,'13A',96,'ESRD secondary to DM.',NULL,NULL,0,NULL,NULL,NULL,0,NULL,NULL,NULL,0,NULL,NULL,NULL,NULL,NULL,'muhammadarif','2022-10-03 00:00:00','muhammadarif','2022-10-03 00:00:00'),(14,'13A',64,'CRD',NULL,NULL,0,NULL,NULL,NULL,1,'seafood',NULL,NULL,0,NULL,NULL,NULL,NULL,NULL,'muhammadarif','2022-10-03 00:00:00','muhammadarif','2022-10-03 00:00:00'),(15,'13A',112,NULL,NULL,NULL,0,NULL,NULL,NULL,0,NULL,NULL,NULL,0,NULL,NULL,NULL,NULL,NULL,'muhammadarif','2022-10-03 00:00:00','muhammadarif','2022-10-03 00:00:00'),(16,'13A',76,NULL,NULL,NULL,0,NULL,NULL,NULL,0,NULL,NULL,NULL,0,NULL,NULL,NULL,NULL,NULL,'muhammadarif','2022-10-03 00:00:00','muhammadarif','2022-10-03 00:00:00'),(17,'13A',29,'1.ESRD\r\n2. PRIMARY GOUT\r\n3. HPT',NULL,NULL,0,NULL,NULL,NULL,0,NULL,NULL,NULL,0,NULL,NULL,NULL,NULL,NULL,'AIMAN.AMIN','2022-10-03 00:00:00','AIMAN.AMIN','2022-10-03 00:00:00'),(18,'13A',94,'hpt',NULL,NULL,0,NULL,NULL,NULL,0,NULL,NULL,NULL,0,NULL,NULL,NULL,NULL,NULL,'sitiaishah','2022-10-03 00:00:00','sitiaishah','2022-10-03 00:00:00'),(19,'13A',22,'DM, HPT',NULL,NULL,0,NULL,NULL,NULL,0,NULL,NULL,NULL,0,NULL,NULL,NULL,NULL,NULL,'sitiaishah','2022-10-03 00:00:00','sitiaishah','2022-10-03 00:00:00'),(20,'13A',32,NULL,NULL,NULL,0,NULL,NULL,NULL,0,NULL,NULL,NULL,0,NULL,NULL,NULL,NULL,NULL,'muhammadarif','2022-10-04 00:00:00','muhammadarif','2022-10-04 00:00:00'),(21,'13A',101,'1. Diabetic Nephropathy\r\n2. Diabetes\r\n3. Hypertension\r\n4. Ischemic heart disease',NULL,NULL,0,NULL,NULL,NULL,0,NULL,NULL,NULL,0,NULL,NULL,NULL,NULL,NULL,'fadhlina','2022-10-04 00:00:00','fadhlina','2022-10-04 00:00:00'),(22,'13A',111,'HPT',NULL,NULL,1,'metprolol',NULL,NULL,0,NULL,NULL,NULL,0,NULL,NULL,NULL,NULL,NULL,'sitiaishah','2022-10-04 00:00:00','sitiaishah','2022-10-04 00:00:00'),(23,'13A',118,NULL,NULL,NULL,0,NULL,NULL,NULL,0,NULL,NULL,NULL,0,NULL,NULL,NULL,NULL,NULL,'muhammadarif','2022-10-04 00:00:00','muhammadarif','2022-10-04 00:00:00'),(24,'13A',114,'1. HPT\r\n2. ESRF\r\n3. Hyperthyroidism',NULL,NULL,0,NULL,NULL,NULL,0,NULL,NULL,NULL,0,NULL,NULL,NULL,NULL,NULL,'fadhlina','2022-10-04 00:00:00','fadhlina','2022-10-04 00:00:00'),(25,'13A',68,'1.HPT\r\n2.DM',NULL,NULL,0,NULL,NULL,NULL,0,NULL,NULL,NULL,0,NULL,NULL,NULL,NULL,NULL,'fadhlina','2022-10-04 00:00:00','fadhlina','2022-10-04 00:00:00'),(26,'13A',102,'1) hypertensive nephrosclerosis',NULL,NULL,0,NULL,NULL,NULL,0,NULL,NULL,NULL,0,NULL,NULL,NULL,NULL,NULL,'muhammadarif','2022-10-04 00:00:00','muhammadarif','2022-10-04 00:00:00'),(27,'13A',20,'N/A',NULL,NULL,0,NULL,NULL,NULL,0,NULL,NULL,NULL,0,NULL,NULL,NULL,NULL,NULL,'sitiaishah','2022-10-04 00:00:00','sitiaishah','2022-10-04 00:00:00'),(28,'13A',95,'DM, HPT, CKD, GOUT',NULL,NULL,0,NULL,NULL,NULL,0,NULL,NULL,NULL,0,NULL,NULL,NULL,NULL,NULL,'sitiaishah','2022-10-04 00:00:00','sitiaishah','2022-10-04 00:00:00'),(29,'13A',59,'DM, CHOLESTROL, CKD',NULL,NULL,0,NULL,NULL,NULL,0,NULL,NULL,NULL,0,NULL,NULL,NULL,NULL,NULL,'sitiaishah','2022-10-04 00:00:00','sitiaishah','2022-10-04 00:00:00'),(30,'13A',31,'1. diabetes\r\n2. CKD Primary Unknown',NULL,NULL,0,NULL,NULL,NULL,0,NULL,NULL,NULL,0,NULL,NULL,NULL,NULL,NULL,'muhammadarif','2022-10-04 00:00:00','muhammadarif','2022-10-04 00:00:00'),(31,'13A',90,'HPT, CKD,',NULL,NULL,0,NULL,NULL,NULL,0,NULL,NULL,NULL,0,NULL,NULL,NULL,NULL,NULL,'sitiaishah','2022-10-04 00:00:00','sitiaishah','2022-10-04 00:00:00'),(32,'13A',39,'1) Diabetes\r\n2) Hypoglycemia\r\n3) hypertension',NULL,NULL,0,NULL,NULL,NULL,0,NULL,NULL,NULL,0,NULL,NULL,NULL,NULL,NULL,'muhammadarif','2022-10-04 00:00:00','muhammadarif','2022-10-04 00:00:00'),(33,'13A',11,'ESRD, HPT,',NULL,NULL,0,NULL,NULL,NULL,0,NULL,NULL,NULL,0,NULL,NULL,NULL,NULL,NULL,'AIMAN.AMIN','2022-10-04 00:00:00','AIMAN.AMIN','2022-10-04 00:00:00'),(34,'13A',56,'1. hypertensive nephrosclerosis\r\n2. hypertension\r\n3. hyperlipidaemia\r\n4. ischaemic heart disease\r\n5. internal hemorrhoids','1. colonoscopy 17/7/17 swollen and ulcerated ileocaecal valve.',NULL,0,NULL,NULL,NULL,0,NULL,NULL,NULL,0,NULL,NULL,NULL,NULL,NULL,'muhammadarif','2022-10-04 00:00:00','muhammadarif','2022-10-04 00:00:00'),(35,'13A',16,'hpt, dm,',NULL,NULL,0,NULL,NULL,NULL,0,NULL,NULL,NULL,0,NULL,NULL,NULL,NULL,NULL,'AIMAN.AMIN','2022-10-04 00:00:00','AIMAN.AMIN','2022-10-04 00:00:00'),(36,'13A',60,'hpt, dm','angiogram',NULL,0,NULL,NULL,NULL,0,NULL,NULL,NULL,0,NULL,NULL,NULL,NULL,NULL,'AIMAN.AMIN','2022-10-04 00:00:00','AIMAN.AMIN','2022-10-04 00:00:00'),(37,'13A',58,'hpt, dm','carbunkle',NULL,0,NULL,NULL,NULL,0,NULL,NULL,NULL,0,NULL,NULL,NULL,NULL,NULL,'AIMAN.AMIN','2022-10-04 00:00:00','AIMAN.AMIN','2022-10-04 00:00:00'),(38,'13A',81,'1. Glomerulonephritis',NULL,NULL,0,NULL,NULL,NULL,0,NULL,NULL,NULL,0,NULL,NULL,NULL,NULL,NULL,'fadhlina','2022-10-05 00:00:00','fadhlina','2022-10-05 00:00:00'),(39,'13A',27,'1. Glomerulonephritis',NULL,NULL,0,NULL,NULL,NULL,0,NULL,NULL,NULL,0,NULL,NULL,NULL,NULL,NULL,'fadhlina','2022-10-05 00:00:00','fadhlina','2022-10-05 00:00:00'),(40,'13A',1,'HPT, GOUT','NIL',NULL,0,NULL,NULL,NULL,0,NULL,NULL,NULL,0,NULL,NULL,NULL,NULL,NULL,'syawani','2022-10-06 00:00:00','syawani','2022-10-06 00:00:00'),(41,'13A',65,'HPT, CKD',NULL,NULL,0,NULL,NULL,NULL,0,NULL,NULL,NULL,0,NULL,NULL,NULL,NULL,NULL,'sitiaishah','2022-10-06 00:00:00','sitiaishah','2022-10-06 00:00:00'),(42,'13A',98,'DM, HPT,',NULL,NULL,0,NULL,NULL,NULL,0,NULL,NULL,NULL,0,NULL,NULL,NULL,NULL,NULL,'aiman.amin','2022-10-06 00:00:00','aiman.amin','2022-10-06 00:00:00'),(43,'13A',106,'DM',NULL,NULL,0,NULL,NULL,NULL,0,NULL,NULL,NULL,0,NULL,NULL,NULL,NULL,NULL,'aiman.amin','2022-10-06 00:00:00','aiman.amin','2022-10-06 00:00:00'),(44,'13A',186,'DM,HPT, ESRF','N/A',NULL,0,NULL,NULL,NULL,0,NULL,NULL,NULL,0,NULL,NULL,NULL,NULL,NULL,'HAFIZAL','2022-10-12 00:00:00','HAFIZAL','2022-10-12 00:00:00');
/*!40000 ALTER TABLE `nurshistory` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `patgkcasses`
--

DROP TABLE IF EXISTS `patgkcasses`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `patgkcasses` (
  `idno` int(11) NOT NULL AUTO_INCREMENT,
  `compcode` varchar(11) DEFAULT NULL,
  `mrn` varchar(11) DEFAULT NULL,
  `description` varchar(222) DEFAULT NULL,
  `diagcode` varchar(111) DEFAULT NULL,
  `questionnaire` varchar(111) DEFAULT NULL,
  `progress` varchar(111) DEFAULT NULL,
  `regdate` date DEFAULT NULL,
  `type` varchar(50) DEFAULT NULL,
  `transdate` datetime DEFAULT NULL,
  `cb1` text,
  `cb2` text,
  `cb3` text,
  `cb4` text,
  `cb5` text,
  `cb6` text,
  `cb7` text,
  `cb8` text,
  `tf1` text,
  `tf2` text,
  `tf3` text,
  `tf4` text,
  `tf5` text,
  `tf6` text,
  `tf7` text,
  `tf8` text,
  `op1` text,
  `op2` text,
  `op3` text,
  `op4` text,
  `op5` text,
  `op6` text,
  `op7` text,
  `op8` text,
  `dd1` text,
  `dd2` text,
  `dd3` text,
  `dd4` text,
  `ta1` text,
  `ta2` text,
  `ta3` text,
  `ta4` text,
  PRIMARY KEY (`idno`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `patgkcasses`
--

LOCK TABLES `patgkcasses` WRITE;
/*!40000 ALTER TABLE `patgkcasses` DISABLE KEYS */;
/*!40000 ALTER TABLE `patgkcasses` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `pregnancy`
--

DROP TABLE IF EXISTS `pregnancy`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `pregnancy` (
  `idno` int(10) NOT NULL AUTO_INCREMENT,
  `compcode` varchar(30) DEFAULT NULL,
  `mrn` int(11) DEFAULT NULL,
  `episno` int(11) DEFAULT NULL,
  `gravida` int(3) DEFAULT NULL,
  `para` int(3) DEFAULT NULL,
  `abortus` int(3) DEFAULT NULL,
  `lmp` date DEFAULT NULL,
  `edd` date DEFAULT NULL,
  `corrected_edd` date DEFAULT NULL,
  `deliverydate` date DEFAULT NULL,
  `recstatus` varchar(10) DEFAULT NULL,
  `adduser` varchar(30) DEFAULT NULL,
  `adddate` date DEFAULT NULL,
  `lastuser` varchar(30) DEFAULT NULL,
  `lastupdate` datetime DEFAULT NULL,
  PRIMARY KEY (`idno`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `pregnancy`
--

LOCK TABLES `pregnancy` WRITE;
/*!40000 ALTER TABLE `pregnancy` DISABLE KEYS */;
/*!40000 ALTER TABLE `pregnancy` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `pregnancy_episode`
--

DROP TABLE IF EXISTS `pregnancy_episode`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `pregnancy_episode` (
  `idno` int(10) NOT NULL AUTO_INCREMENT,
  `pregnan_idno` int(10) DEFAULT NULL,
  `compcode` varchar(30) DEFAULT NULL,
  `mrn` int(11) DEFAULT NULL,
  `episno` int(11) DEFAULT NULL,
  `date` date DEFAULT NULL,
  `report` text,
  `poa_pog` int(10) DEFAULT NULL,
  `uterinesize` decimal(7,2) DEFAULT NULL,
  `albumin` decimal(7,2) DEFAULT NULL,
  `sugar` decimal(7,2) DEFAULT NULL,
  `weight` decimal(7,2) DEFAULT NULL,
  `bp_sys1` decimal(7,2) DEFAULT NULL,
  `bp_dias2` decimal(7,2) DEFAULT NULL,
  `hb` decimal(7,2) DEFAULT NULL,
  `oedema` varchar(255) DEFAULT NULL,
  `lie` varchar(255) DEFAULT NULL,
  `pres` varchar(255) DEFAULT NULL,
  `fhr` decimal(7,2) DEFAULT NULL,
  `fm` varchar(255) DEFAULT NULL,
  `adduser` varchar(30) DEFAULT NULL,
  `adddate` date DEFAULT NULL,
  `lastuser` varchar(30) DEFAULT NULL,
  `lastupdate` datetime DEFAULT NULL,
  PRIMARY KEY (`idno`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `pregnancy_episode`
--

LOCK TABLES `pregnancy_episode` WRITE;
/*!40000 ALTER TABLE `pregnancy_episode` DISABLE KEYS */;
/*!40000 ALTER TABLE `pregnancy_episode` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `triage_addnotes`
--

DROP TABLE IF EXISTS `triage_addnotes`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `triage_addnotes` (
  `idno` int(11) NOT NULL AUTO_INCREMENT,
  `compcode` varchar(30) DEFAULT NULL,
  `mrn` int(11) DEFAULT NULL,
  `episno` int(11) DEFAULT NULL,
  `location` varchar(100) DEFAULT 'TRIAGE' COMMENT 'TRIAGE/WARD',
  `additionalnote` text,
  `adduser` varchar(30) DEFAULT NULL,
  `adddate` datetime DEFAULT NULL,
  PRIMARY KEY (`idno`)
) ENGINE=InnoDB AUTO_INCREMENT=3 DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `triage_addnotes`
--

LOCK TABLES `triage_addnotes` WRITE;
/*!40000 ALTER TABLE `triage_addnotes` DISABLE KEYS */;
INSERT INTO `triage_addnotes` VALUES (1,'13A',81,2,'TRIAGE','gfdgdfg','hayati','2022-10-05 09:54:34'),(2,'13A',81,2,'TRIAGE','asdsad','hayati','2022-10-05 09:54:41');
/*!40000 ALTER TABLE `triage_addnotes` ENABLE KEYS */;
UNLOCK TABLES;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2022-10-13 22:51:54
